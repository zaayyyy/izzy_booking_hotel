<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Reservations</title>
    <?php require('inc/links_izzy.php'); ?>
</head>
<?php

require_once('inc/header_izzy.php');

if (!isset($_SESSION['user_id_izzy'])) {
    echo "<script>
            alert('You need to log in first!');
            window.location.href='index_izzy.php?show_register=true';
          </script>";
    exit;
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reschedule'])) {
    $transaction_id = $_POST['id_transaction_izzy'];

    $reschedule_check = "SELECT reschedule_status_izzy FROM transaction_izzy WHERE id_transaction_izzy = ?";
    $stmt = $con->prepare($reschedule_check);
    $stmt->bind_param("i", $transaction_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if (!$row || $row['reschedule_status_izzy'] !== 'none') {
        echo "<script>alert('You can only reschedule once.'); window.location.href='reservation_izzy.php';</script>";
        exit;
    }
    $transaction_id = $_POST['id_transaction_izzy'];
    $new_checkin = $_POST['new_checkin'];
    $new_checkout = $_POST['new_checkout'];

    $current_checkin_query = "SELECT checkin_izzy, id_room_izzy, status_izzy 
                             FROM transaction_izzy 
                             WHERE id_transaction_izzy = ? AND status_izzy = 'upcoming'";
    $stmt = $con->prepare($current_checkin_query);
    $stmt->bind_param("i", $transaction_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $booking = $result->fetch_assoc();

    if (!$booking) {
        echo "<script>alert('Invalid transaction or status!');</script>";
        exit;
    }

    $current_checkin = new DateTime($booking['checkin_izzy']);
    $today = new DateTime();
    $interval = $today->diff($current_checkin);

    if ($interval->days < 1) {
        echo "<script>alert('Reschedule must be done at least 1 day before check-in.');</script>";
    } else {
        $room_id = $booking['id_room_izzy'];
        $check_available = "SELECT COUNT(*) as booked FROM transaction_izzy 
                          WHERE id_room_izzy = ? AND status_izzy = 'upcoming'
                          AND id_transaction_izzy != ?
                          AND ((checkin_izzy BETWEEN ? AND ?) 
                          OR (checkout_izzy BETWEEN ? AND ?))";
        
        $stmt = $con->prepare($check_available);
        $stmt->bind_param("iissss", $room_id, $transaction_id, $new_checkin, $new_checkout, $new_checkin, $new_checkout);
        $stmt->execute();
        $result = $stmt->get_result();
        $is_booked = $result->fetch_assoc()['booked'];

        if ($is_booked > 0) {
            echo "<script>alert('Room not available for selected dates!');</script>";
        } else {
            $update_query = "UPDATE transaction_izzy SET 
                           new_checkin_izzy = ?, 
                           new_checkout_izzy = ?,
                           reschedule_status_izzy = 'requested',
                           status_izzy = 'upcoming'
                           WHERE id_transaction_izzy = ?";
            
            $stmt = $con->prepare($update_query);
            $stmt->bind_param("ssi", $new_checkin, $new_checkout, $transaction_id);
            
            if ($stmt->execute()) {
                echo "<script>alert('Reschedule request submitted successfully!'); window.location.href='reservation_izzy.php';</script>";
            } else {
                echo "<script>alert('Failed to submit reschedule request.');</script>";
            }
        }
    }
}

$id_user_izzy = $_SESSION['user_id_izzy'];

$IzzyQuery = "SELECT t.id_transaction_izzy, r.name_izzy, y.type_izzy, t.checkin_izzy, t.checkout_izzy, t.status_izzy,t.status_payment_izzy, t.reschedule_status_izzy, t.total_price_izzy, t.person_q_izzy, u.email_izzy AS user_email_izzy, r.id_room_izzy AS room_id_izzy
              FROM transaction_izzy t
              INNER JOIN rooms_izzy r ON t.id_room_izzy = r.id_room_izzy
              INNER JOIN user_izzy u ON u.id_izzy = t.id_izzy
              INNER JOIN room_type_izzy y ON r.id_type_izzy = y.id_type_izzy
              WHERE t.id_izzy = ?
              ORDER BY t.checkin_izzy DESC";

$stmt = $con->prepare($IzzyQuery);
$stmt->bind_param("i", $id_user_izzy);
$stmt->execute();
$result = $stmt->get_result();
$reservations = $result->fetch_all(MYSQLI_ASSOC);

$upcoming = [];
$completed = [];
$canceled = [];

foreach ($reservations as $reservation) {
    switch ($reservation['status_izzy']) {
        case 'upcoming':
            $upcoming[] = $reservation;
            break;
        case 'completed':
            $completed[] = $reservation;
            break;
        case 'canceled':
            $canceled[] = $reservation;
            break;
    }
}

?>

<body>
    <div class="container mt-5 mb-5">
        <div class="card shadow-lg border-0">
            <div class="card-header text-white text-center py-4"
                style="background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);">
                <h2 class="fw-bold mb-0">My Reservations</h2>
                <p class="mb-0 mt-2">View and manage your booking history</p>
            </div>

            <div class="card-body p-4">
                <ul class="nav nav-tabs mb-4" id="reservationTabs">
                    <li class="nav-item">
                        <a class="nav-link active" data-bs-toggle="tab" href="#upcoming">
                            <i class="bi bi-calendar-check me-2"></i>Upcoming
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#completed">
                            <i class="bi bi-check-circle me-2"></i>Completed
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#canceled">
                            <i class="bi bi-x-circle me-2"></i>Canceled
                        </a>
                    </li>
                </ul>

                <div class="tab-content">
                    <div class="tab-pane fade show active" id="upcoming">
                        <?php if (empty($upcoming)): ?>
                        <div class="text-center p-5">
                            <i class="bi bi-calendar-x fs-1 text-muted"></i>
                            <p class="mt-3">No upcoming reservations.</p>
                        </div>
                        <?php else: ?>
                        <?php foreach ($upcoming as $res): ?>

                        <div class="modal fade" id="rescheduleModal<?= $res['id_transaction_izzy'] ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Reschedule Booking</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <form method="POST" id="rescheduleForm<?= $res['id_transaction_izzy'] ?>">
                                        <div class="modal-body">
                                            <input type="hidden" name="id_transaction_izzy"
                                                value="<?= $res['id_transaction_izzy'] ?>">
                                            <div class="mb-3">
                                                <label>New Check-in Date</label>
                                                <input type="date" class="form-control" name="new_checkin"
                                                    id="new_checkin<?= $res['id_transaction_izzy'] ?>"
                                                    value="<?= $res['checkin_izzy'] ?>" min="<?= date('Y-m-d') ?>"
                                                    required>
                                            </div>
                                            <div class="mb-3">
                                                <label>New Check-out Date</label>
                                                <input type="date" class="form-control" name="new_checkout"
                                                    id="new_checkout<?= $res['id_transaction_izzy'] ?>"
                                                    value="<?= $res['checkout_izzy'] ?>" required>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" name="reschedule" class="btn btn-primary">
                                                Confirm Reschedule
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="booking-card mb-3">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col-md-4">
                                        <h5 class="card-title mb-3">
                                            <i class="bi bi-house-door me-2"></i><?= $res['name_izzy'] ?>
                                        </h5>
                                        <span class="badge bg-warning text-dark">Upcoming</span>
                                    </div>
                                    <div class="col-md-4">
                                        <p class="mb-2">
                                            <i class="bi bi-calendar3 me-2"></i>Check-in:
                                            <strong><?= $res['checkin_izzy'] ?></strong>
                                        </p>
                                        <p class="mb-2">
                                            <i class="bi bi-calendar3 me-2"></i>Check-out:
                                            <strong><?= $res['checkout_izzy'] ?></strong>
                                        </p>
                                        <p class="mb-0">
                                            <i class="bi bi-currency-dollar me-2"></i>Total Price:
                                            <strong class="text-success">$<?= $res['total_price_izzy'] ?></strong>
                                        </p>
                                    </div>
                                    <div class="col-md-4 text-md-end mt-3 mt-md-0">
                                        <?php if ($res['reschedule_status_izzy'] === 'requested'): ?>
                                        <button class="btn btn-secondary" disabled>Reschedule
                                            <br> Requested</button>
                                        <?php elseif ($res['reschedule_status_izzy'] === 'approved'): ?>
                                        <button class="btn btn-success" disabled>Reschedule
                                            <br> Approved</button>
                                        <?php else: ?>
                                        <button class="btn btn-warning" data-bs-toggle="modal"
                                            data-bs-target="#rescheduleModal<?= $res['id_transaction_izzy'] ?>">
                                            Reschedule
                                        </button>
                                        <?php endif; ?>



                                        <script>
                                        document.addEventListener("DOMContentLoaded", function() {
                                            document.querySelectorAll('form[id^="rescheduleForm"]').forEach(
                                                function(form) {
                                                    const transactionId = form.querySelector(
                                                        'input[name="id_transaction_izzy"]').value;

                                                    const checkinInput = document.getElementById(
                                                        'new_checkin' + transactionId);
                                                    const checkoutInput = document.getElementById(
                                                        'new_checkout' + transactionId);
                                                    checkinInput.addEventListener('change', function() {
                                                        checkoutInput.min = checkinInput.value;
                                                        if (checkoutInput.value < checkinInput
                                                            .value) {
                                                            checkoutInput.value = '';
                                                        }
                                                    });
                                                    checkinInput.addEventListener("change", function() {
                                                        let checkinDate = this.value;
                                                        if (!checkinDate) {
                                                            checkoutInput.disabled = true;
                                                            checkoutInput.value = "";
                                                            return;
                                                        }
                                                        checkoutInput.disabled = false;
                                                        let minCheckout = new Date(checkinDate);
                                                        minCheckout.setDate(minCheckout.getDate() +
                                                            1);
                                                        checkoutInput.min = minCheckout
                                                            .toISOString().split('T')[0];
                                                        checkoutInput.value = "";

                                                    });

                                                    checkoutInput.addEventListener("change", function() {
                                                        if (this.value <= checkinInput.value) {
                                                            alert(
                                                                "Check-out date must be after check-in date!"
                                                            );
                                                            this.value = "";
                                                            return;
                                                        }
                                                    });
                                                });
                                        });

                                        document.getElementById('rescheduleForm<?= $res['id_transaction_izzy'] ?>')
                                            .addEventListener('submit', function(e) {
                                                const confirmReschedule = confirm(
                                                    "Are you sure you want to reschedule this booking?");
                                                if (!confirmReschedule) {
                                                    e.preventDefault();
                                                }
                                            });
                                        </script>
                                        <form action="transaction_receipt_izzy.php" method="get"
                                            style="display:inline;">
                                            <input type="hidden" name="id" value="<?= $res['id_transaction_izzy'] ?>">
                                            <button type="submit"
                                                class="btn btn-primary <?= ($res['status_payment_izzy'] != 'paid') ? 'disabled' : '' ?>">
                                                Transaction<br>Receipt
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </div>

                    <div class="tab-pane fade" id="completed">
                        <?php if (empty($completed)): ?>
                        <div class="text-center p-5">
                            <i class="bi bi-check2-circle fs-1 text-muted"></i>
                            <p class="mt-3">No completed reservations.</p>
                        </div>
                        <?php else: ?>
                        <?php foreach ($completed as $res): ?>
                        <div class="booking-card mb-3">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col-md-4">
                                        <h5 class="card-title mb-3">
                                            <i class="bi bi-house-door me-2"></i><?= $res['name_izzy'] ?>
                                        </h5>
                                        <span class="badge bg-success">Completed</span>
                                    </div>
                                    <div class="col-md-4">
                                        <p class="mb-2">
                                            <i class="bi bi-calendar3 me-2"></i>Check-in:
                                            <strong><?= $res['checkin_izzy'] ?></strong>
                                        </p>
                                        <p class="mb-2">
                                            <i class="bi bi-calendar3 me-2"></i>Check-out:
                                            <strong><?= $res['checkout_izzy'] ?></strong>
                                        </p>
                                        <p class="mb-0">
                                            <i class="bi bi-currency-dollar me-2"></i>Total Price:
                                            <strong class="text-success">$<?= $res['total_price_izzy'] ?></strong>
                                        </p>

                                    </div>
                                    <div class="col-md-4 text-md-end mt-3 mt-md-0">
                                        <form action="transaction_receipt_izzy.php" method="get"
                                            style="display:inline;">
                                            <input type="hidden" name="id" value="<?= $res['id_transaction_izzy'] ?>">
                                            <button type="submit"
                                                class="btn btn-primary <?= ($res['status_payment_izzy'] == 'paid')?>">
                                                Transaction<br>Receipt
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </div>

                    <div class="tab-pane fade" id="canceled">
                        <?php if (empty($canceled)): ?>
                        <div class="text-center p-5">
                            <i class="bi bi-x-circle fs-1 text-muted"></i>
                            <p class="mt-3">No canceled reservations.</p>
                        </div>
                        <?php else: ?>
                        <?php foreach ($canceled as $res): ?>
                        <div class="booking-card mb-3">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col-md-4">
                                        <h5 class="card-title mb-3">
                                            <i class="bi bi-house-door me-2"></i><?= $res['name_izzy'] ?>
                                        </h5>
                                        <span class="badge bg-danger">Canceled</span>
                                    </div>
                                    <div class="col-md-4">
                                        <p class="mb-2">
                                            <i class="bi bi-calendar3 me-2"></i>Check-in:
                                            <strong><?= $res['checkin_izzy'] ?></strong>
                                        </p>
                                        <p class="mb-2">
                                            <i class="bi bi-calendar3 me-2"></i>Check-out:
                                            <strong><?= $res['checkout_izzy'] ?></strong>
                                        </p>
                                        <p class="mb-0">
                                            <i class="bi bi-currency-dollar me-2"></i>Total Price:
                                            <strong class="text-danger">$<?= $res['total_price_izzy'] ?></strong>
                                        </p>
                                    </div>
                                    <div class="col-md-4 text-md-end mt-3 mt-md-0">
                                        <button
                                            onclick="window.location.href='booking_izzy.php?id=<?= $res['room_id_izzy'] ?>'"
                                            class="btn btn-outline-primary">
                                            <i class="bi bi-arrow-repeat me-2"></i>Book Again
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <style>
    .booking-card {
        border: 1px solid rgba(0, 0, 0, 0.1);
        border-radius: 15px;
        overflow: hidden;
        transition: all 0.3s ease;
        background: #fff;
        margin-bottom: 1rem;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    }

    .booking-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }

    .nav-tabs .nav-link {
        border: none;
        padding: 1rem 1.5rem;
        color: #6c757d;
        font-weight: 500;
        transition: all 0.3s ease;
    }

    .nav-tabs .nav-link.active {
        color: #1e3c72;
        border-bottom: 3px solid #1e3c72;
        background: transparent;
    }

    .btn {
        border-radius: 8px;
        padding: 0.6rem 1.5rem;
        transition: all 0.3s ease;
    }

    .card {
        border-radius: 15px;
        overflow: hidden;
    }

    .card-header {
        background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
        color: white;
    }

    .badge {
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-size: 0.875rem;
    }
    </style>

    <?php require('inc/footer_izzy.php'); ?>

</body>

</html>