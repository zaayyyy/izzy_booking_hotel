<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Room</title>
    <?php require('inc/links_izzy.php'); ?>
</head>
<?php
require('inc/header_izzy.php');

if (!isset($_SESSION['user_id_izzy'])) {
    echo "<script>
            alert('You need to log in first!');
            window.location.href='index_izzy.php?show_register=true';
          </script>";
    exit;
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<script>alert('Unauthorized access!'); window.location.href='index_izzy.php';</script>";
    exit;
}

$IzzyRoomId = $_GET['id'];
$IzzyUserId = $_SESSION['user_id_izzy'];

$IzzyQuery = "SELECT r.id_room_izzy, r.id_type_izzy, u.id_izzy, r.name_izzy, r.guest_capacity_izzy, r.price_izzy, u.name_izzy AS user_name_izzy, u.email_izzy as user_email_izzy, r.room_status_izzy, t.type_izzy
              FROM rooms_izzy r
              INNER JOIN room_type_izzy t ON r.id_type_izzy = t.id_type_izzy
              INNER JOIN user_izzy u ON u.id_izzy = ?
              WHERE r.id_room_izzy = ?";
$IzzyStmt = mysqli_prepare($con, $IzzyQuery);
mysqli_stmt_bind_param($IzzyStmt, "ii", $IzzyUserId, $IzzyRoomId);
mysqli_stmt_execute($IzzyStmt);
$IzzyResult = mysqli_stmt_get_result($IzzyStmt);

if (mysqli_num_rows($IzzyResult) == 0) {
    die("Room not found!");
}

$IzzyRoom = mysqli_fetch_assoc($IzzyResult);

$IzzyFacilitiesQuery = "SELECT * FROM add_facilities_izzy";
$IzzyFacilitiesResult = mysqli_query($con, $IzzyFacilitiesQuery);
$IzzyFacilities = [];
while ($facility = mysqli_fetch_assoc($IzzyFacilitiesResult)) {
    $IzzyFacilities[] = $facility;
}


function getRandomPrice($basePrice, $date, $roomId)
{
    $seed = crc32($date . $roomId);
    mt_srand($seed);


    $randomPercentage = mt_rand(-20, 20);
    $priceAdjustment = $basePrice * ($randomPercentage / 100);
    $finalPrice = $basePrice + $priceAdjustment;

    mt_srand();

    return number_format($finalPrice, 2, '.', '');
}


$today = date('Y-m-d');
$todayPrice = getRandomPrice($IzzyRoom['price_izzy'], $today, $IzzyRoomId);

$IzzyCheckReschedule = "SELECT COUNT(*) as reschedule_count 
                        FROM transaction_izzy 
                        WHERE id_room_izzy = ? AND status_izzy = 'upcoming'
                        AND ((checkin_izzy BETWEEN ? AND ?) 
                        OR (checkout_izzy BETWEEN ? AND ?))";

$stmt = mysqli_prepare($con, $IzzyCheckReschedule);
mysqli_stmt_bind_param($stmt, "issss", $IzzyRoomId, $checkin_date, $checkout_date, $checkin_date, $checkout_date);
mysqli_stmt_execute($stmt);
$reschedule_result = mysqli_stmt_get_result($stmt);
$reschedule_count = mysqli_fetch_assoc($reschedule_result)['reschedule_count'];

if ($reschedule_count > 0) {
    echo "<script>alert('Room not available for selected dates due to existing bookings!'); history.back();</script>";
    exit;
}
?>

<body class="bg-light">
    <div class="container mt-5 mb-5">
        <div class="card shadow-lg border-0">
            <div class="card-header text-white text-center py-4"
                style="background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);">
                <h2 class="fw-bold mb-0">Payment Confirmation</h2>
                <p class="mb-0 mt-2">Complete your payment within the time limit</p>
            </div>

            <div class="card-body p-4">
                <div class="booking-progress mb-4">
                    <div class="progress" style="height: 4px;">
                        <div class="progress-bar bg-success" role="progressbar" style="width: 33%"></div>
                    </div>
                    <div class="d-flex justify-content-between mt-2">
                        <span class="badge bg-success">Room Selected</span>
                        <span class="badge bg-secondary">Details</span>
                        <span class="badge bg-secondary">Payment</span>
                    </div>
                </div>

                <form method="POST" action="confirmation_izzy.php">
                    <input type="hidden" name="name_izzy" value="<?= htmlspecialchars($IzzyRoom['name_izzy']) ?>">
                    <input type="hidden" name="base_price_izzy" value="<?= $IzzyRoom['price_izzy'] ?>">
                    <input type="hidden" name="room_id_izzy" value="<?= $IzzyRoomId ?>">
                    <input type="hidden" name="per_night_rate_izzy" id="per_night_rate_izzy"
                        value="<?= $IzzyRoom['price_izzy'] ?>">
                    <input type="hidden" name="nights_count_izzy" id="nights_count_izzy" value="1">
                    <input type="hidden" name="room_rate_total_izzy" id="room_rate_total_izzy"
                        value="<?= $IzzyRoom['price_izzy'] ?>">
                    <input type="hidden" name="extra_bed_fee_izzy" id="extra_bed_fee_izzy" value="0">
                    <input type="hidden" name="service_fees_izzy" id="service_fees_izzy" value="">
                    <input type="hidden" name="subtotal_izzy" id="subtotal_izzy" value="<?= $IzzyRoom['price_izzy'] ?>">
                    <input type="hidden" name="tax_izzy" id="tax_izzy" value="<?= $IzzyRoom['price_izzy'] * 0.1 ?>">
                    <input type="hidden" name="discount_izzy" id="discount_izzy" value="0">
                    <input type="hidden" name="total_price_izzy" id="total_price_izzy"
                        value="<?= $IzzyRoom['price_izzy'] * 1.1 ?>">
                    <input type="hidden" name="user_name_izzy" value="<?= $IzzyRoom['user_name_izzy'] ?>">
                    <input type="hidden" name="user_email_izzy" value="<?= $IzzyRoom['user_email_izzy'] ?>">
                    <input type="hidden" name="type_izzy" value="<?= $IzzyRoom['type_izzy'] ?>">

                    <input type="hidden" name="selected_facilities_data" id="selected_facilities_data" value="">

                    <div class="row g-4">
                        <div class="col-md-6">
                            <div class="booking-card h-100">
                                <div class="card-header">
                                    <i class="bi bi-person-circle fs-4"></i>
                                    <h5>User Information</h5>
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <label class="form-label text-muted">Name</label>
                                        <input type="text" class="form-control bg-light" readonly
                                            value="<?php echo $IzzyRoom['user_name_izzy']; ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label text-muted">Email</label>
                                        <input type="email" class="form-control bg-light" readonly
                                            value="<?php echo $IzzyRoom['user_email_izzy']; ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label text-muted">Person Quantity</label>
                                        <select class="form-select" name="person_q_izzy" id="person_q_izzy">
                                            <?php
                                            $capacity = $IzzyRoom['guest_capacity_izzy'];
                                            for ($i = 1; $i <= $capacity; $i++) {
                                                echo "<option value='$i'>$i person</option>";
                                            }
                                            $extraPerson = $capacity + 1;
                                            echo "<option value='$extraPerson'>$extraPerson persons (extra bed)</option>";
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Room Details -->
                        <div class="col-md-6">
                            <div class="booking-card h-100">
                                <div class="card-header">
                                    <i class="bi bi-house-door fs-4"></i>
                                    <h5>Room Information</h5>
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <label class="form-label text-muted">Room Name</label>
                                        <input type="text" class="form-control bg-light" readonly
                                            value="<?php echo $IzzyRoom['name_izzy']; ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label text-muted">Room Type</label>
                                        <input type="text" class="form-control bg-light" readonly
                                            value="<?php echo $IzzyRoom['type_izzy']; ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label text-muted">Room Price</label>
                                        <input type="text" class="form-control bg-light" readonly
                                            id="daily_price_display"
                                            value="$<?php echo $IzzyRoom['price_izzy']; ?> per night">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Stay Details -->
                        <div class="col-md-12">
                            <div class="booking-card">
                                <div class="card-header">
                                    <i class="bi bi-calendar-check fs-4"></i>
                                    <h5>Stay Details</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row g-4">
                                        <div class="col-md-6">
                                            <label class="form-label text-muted">Check-in</label>
                                            <div class="input-group mb-3">
                                                <input type="date" name="checkin_izzy" id="checkin_izzy" value="<?php echo $_GET['check_in'] ?? ''; ?>"
                                                    class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label text-muted">Check-out</label>
                                            <div class="input-group mb-3">
                                                <input type="date" name="checkout_izzy" id="checkout_izzy" value="<?php echo $_GET['check_out'] ?? ''; ?>"
                                                    class="form-control" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Additional Services -->
                        <div class="col-12">
                            <div class="booking-card">
                                <div class="card-header">
                                    <i class="bi bi-plus-circle fs-4"></i>
                                    <h5>Additional Services</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row row-cols-1 row-cols-md-2 g-4">
                                        <?php if (empty($IzzyFacilities)): ?>
                                            <div class="col-12 text-center">
                                                <p class="text-muted">No additional services available at the moment.</p>
                                            </div>
                                        <?php else: ?>
                                            <?php foreach ($IzzyFacilities as $facility): ?>
                                                <div class="col">
                                                    <div class="facility-card">
                                                        <div class="form-check">
                                                            <input class="form-check-input facility-checkbox" type="checkbox"
                                                                name="selected_facilities[]"
                                                                id="facility<?= $facility['id_add_izzy']; ?>"
                                                                value="<?= $facility['id_add_izzy']; ?>"
                                                                data-name="<?= $facility['add_name_izzy']; ?>"
                                                                data-price="<?= $facility['add_price_izzy']; ?>">
                                                            <label class="form-check-label"
                                                                for="facility<?= $facility['id_add_izzy']; ?>">
                                                                <strong><?= $facility['add_name_izzy']; ?></strong>
                                                                <span
                                                                    class="badge bg-primary">$<?= $facility['add_price_izzy']; ?></span>
                                                                <small
                                                                    class="d-block text-muted mt-1"><?= $facility['add_desc_izzy']; ?></small>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mt-4 p-4 bg-light rounded-3">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h4 class="mb-0">Total Price</h4>
                                <input type="text" class="form-control-lg bg-transparent border-0 fw-bold text-success"
                                    readonly id="total_price" value="">
                            </div>
                            <div class="col-md-6 text-end">
                                <button type="submit" class="btn btn-primary btn-lg px-5" name="next" id="submit_btn"
                                    disabled>
                                    Continue to Book
                                    <i class="bi bi-arrow-right ms-2"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <style>
        .booking-card {
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: 15px;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .booking-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
        }

        .facility-card {
            padding: 1rem;
            border-radius: 10px;
            background: #f8f9fa;
            transition: all 0.3s ease;
        }

        .facility-card:hover {
            background: #fff;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .booking-progress {
            padding: 1rem;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            margin-bottom: 2rem;
        }

        .form-control,
        .form-select {
            border-radius: 8px;
            padding: 0.6rem 1rem;
        }

        .btn {
            border-radius: 8px;
            padding: 0.6rem 1.5rem;
        }
    </style>
    <?php require('inc/footer_izzy.php'); ?>

    <script>
        function getRandomPrice(date, roomId, basePrice) {
            let seed = date.split('-').join('') + roomId;
            let hash = 0;
            for (let i = 0; i < seed.length; i++) {
                hash = ((hash << 5) - hash) + seed.charCodeAt(i);
                hash = hash & hash;
            }
            let percentage = (hash % 41) - 20;
            let adjustment = basePrice * (percentage / 100);
            return (basePrice + adjustment).toFixed(2);
        }

        document.addEventListener("DOMContentLoaded", function() {
            let checkinInput = document.getElementById("checkin_izzy");
            let checkoutInput = document.getElementById("checkout_izzy");
            let personQtySelect = document.getElementById("person_q_izzy");
            let roomId = <?php echo $IzzyRoomId; ?>;
            let basePrice = <?php echo $IzzyRoom['price_izzy']; ?>;
            let roomCapacity = <?php echo $IzzyRoom['guest_capacity_izzy']; ?>;
            let submitBtn = document.getElementById("submit_btn");
            let facilityCheckboxes = document.querySelectorAll('.facility-checkbox');

            checkinInput.setAttribute("min", new Date().toISOString().split('T')[0]);
            console.log(checkinInput, checkoutInput);
            if (checkinInput.value.length <= 0) {
                checkoutInput.disabled = true;
            }

            function calculateTotalPrice() {
                const checkinDate = new Date(checkinInput.value);
                const checkoutDate = new Date(checkoutInput.value);
                let personQty = parseInt(personQtySelect.value) || 1;

                if (!isNaN(checkinDate.getTime()) && !isNaN(checkoutDate.getTime()) && checkoutDate > checkinDate) {
                    const nights = Math.floor((checkoutDate - checkinDate) / (1000 * 60 * 60 * 24));
                    let perNightRate = parseFloat(getRandomPrice(checkinDate.toISOString().split('T')[0], roomId,
                        basePrice));
                    let roomRateTotal = perNightRate * nights;
                    let subtotal = roomRateTotal;

                    document.getElementById('nights_count_izzy').value = nights;
                    document.getElementById('per_night_rate_izzy').value = perNightRate.toFixed(2);
                    document.getElementById('room_rate_total_izzy').value = roomRateTotal.toFixed(2);

                    let serviceFees = [];
                    facilityCheckboxes.forEach(checkbox => {
                        if (checkbox.checked) {
                            const facilityPrice = parseFloat(checkbox.dataset.price);
                            const totalServicePrice = facilityPrice * nights;
                            subtotal += totalServicePrice;
                            serviceFees.push({
                                id: checkbox.value,
                                name: checkbox.dataset.name,
                                price: facilityPrice,
                                total: totalServicePrice
                            });
                        }
                    });

                    document.getElementById('service_fees_izzy').value = JSON.stringify(serviceFees);

                    if (personQty > roomCapacity) {
                        subtotal += 25;
                        document.getElementById('extra_bed_fee_izzy').value = "25";
                    } else {
                        document.getElementById('extra_bed_fee_izzy').value = "0";
                    }

                    document.getElementById('subtotal_izzy').value = subtotal.toFixed(2);
                    const tax = subtotal * 0.1;
                    document.getElementById('tax_izzy').value = tax.toFixed(2);

                    // Apply discount logic
                    let discount = 0;
                    if (subtotal + tax > 150) {
                        discount = (subtotal + tax) * 0.1; // 10% discount
                    }
                    document.getElementById('discount_izzy').value = discount.toFixed(2);

                    const totalPrice = subtotal + tax - discount;
                    document.getElementById('total_price_izzy').value = totalPrice.toFixed(2);
                    document.getElementById('total_price').value = "$" + totalPrice.toFixed(2);
                    document.getElementById('daily_price_display').value = "$" + perNightRate.toFixed(2) +
                        " per night";

                    submitBtn.disabled = false;

                    console.log('Calculated values:', {
                        nights,
                        perNightRate,
                        roomRateTotal,
                        subtotal,
                        tax,
                        discount,
                        totalPrice
                    });
                }
            }

            checkinInput.addEventListener("change", function() {
                let checkinDate = this.value;

                if (!checkinDate) {
                    checkoutInput.disabled = true;
                    checkoutInput.value = "";
                    return;
                }

                // Enable checkout and set minimum date
                checkoutInput.disabled = false;
                let minCheckout = new Date(checkinDate);
                minCheckout.setDate(minCheckout.getDate() + 1);
                checkoutInput.min = minCheckout.toISOString().split('T')[0];
                checkoutInput.value = "";

                calculateTotalPrice();
            });

            checkoutInput.addEventListener("change", function() {
                if (this.value <= checkinInput.value) {
                    alert("Check-out date must be after check-in date!");
                    this.value = "";
                    return;
                }
                calculateTotalPrice();
            });

            personQtySelect.addEventListener("change", calculateTotalPrice);
            facilityCheckboxes.forEach(checkbox => {
                checkbox.addEventListener("change", calculateTotalPrice);
            });
        });
    </script>

</body>

</html>