<?php
require('admin/inc/essentials_izzy.php');
require('inc/koneksi_db_izzy.php');
session_start();
if (!isset($_SESSION['user_id_izzy'])) {
    echo "<script>
            alert('You need to log in first!');
            window.location.href='index_izzy.php?show_register=true';
          </script>";
    exit;
}
$transaction_id = $_GET['id'];

$query = "SELECT 
            t.*, 
            r.name_izzy as room_name_izzy, 
            u.name_izzy 
          FROM 
            transaction_izzy t
          JOIN 
            rooms_izzy r ON t.id_room_izzy = r.id_room_izzy
          JOIN 
            user_izzy u ON t.id_izzy = u.id_izzy
          WHERE 
            t.id_transaction_izzy = ?";

$stmt = $con->prepare($query);
$stmt->bind_param("i", $transaction_id);
$stmt->execute();
$data = $stmt->get_result();

if ($data->num_rows > 0) {
    $data = $data->fetch_assoc();
} else {
    echo "Transaction not found!";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Transaction Info</title>
    <?php require('inc/links_izzy.php') ?>
</head>

<body class="bg-light">
    <?php require('inc/header_izzy.php') ?>
    <style>
    .receipt {
        max-width: 210mm;
        margin: auto;
        font-family: 'Courier New', Courier, monospace;
        border: 1px dashed #000;
        background-color: #fff;
        padding: 20mm;
        border-radius: 10px;
        box-sizing: border-box;
    }

    .receipt h4,
    .receipt h5,
    .receipt h6 {
        margin: 0;
        text-align: center;
    }

    .receipt table {
        width: 100%;
        border-collapse: collapse;
    }

    .receipt table td {
        padding: 5px;
        vertical-align: top;
    }

    .receipt hr {
        border-top: 1px dashed #000;
        margin: 10px 0;
    }

    .section-title {
        font-weight: bold;
        background-color: #f9f9f9;
        padding: 5px;
        border-radius: 5px;
        margin-bottom: 5px;
    }

    .details-section {
        margin-bottom: 15px;
    }

    /* CSS tambahan untuk merapikan titik dua */
    .details-section table td:first-child {
        width: 35%;
    }

    .details-section table td:nth-child(2) {
        width: 5%;
        text-align: right;
    }

    .details-section table td:last-child {
        width: 60%;
    }
    </style>

    <div class="receipt p-4 mb-4 mt-4 bg-white" id="receipt-content">
        <div class="text-center mb-4">
            <h4 class="fw-bold">IZZY HOTEL</h4>
            <p class="mb-0">Jl. Gatot Subroto No. 23, Cimahi, Izzy Hotel</p>
            <p class="mb-0">Telp: 0889-7187-9592</p>
            <hr style="border-top: 2px dashed #000;">
        </div>

        <!-- Booking Receipt -->
        <div class="details-section">
            <div class="section-title">Booking Receipt</div>
            <table class="table table-borderless">
                <tr>
                    <td><strong>Transaction ID</strong></td>
                    <td>:</td>
                    <td>#<?= $data['id_transaction_izzy'] ?></td>
                </tr>
                <tr>
                    <td><strong>Transaction Date</strong></td>
                    <td>:</td>
                    <td><?= date('d M Y H:i', strtotime($data['create_at'])) ?></td>
                </tr>
            </table>
        </div>

        <!-- Guest Information -->
        <div class="details-section">
            <div class="section-title">Guest Information</div>
            <table class="table table-borderless">
                <tr>
                    <td>Username</td>
                    <td>:</td>
                    <td><?= htmlspecialchars($data['name_izzy']) ?></td>
                </tr>
                <tr>
                    <td>Number of Guests</td>
                    <td>:</td>
                    <td><?= $data['person_q_izzy'] ?> person(s)</td>
                </tr>
            </table>
        </div>

        <!-- Stay Details -->
        <div class="details-section">
            <div class="section-title">Stay Details</div>
            <table class="table table-borderless">
                <tr>
                    <td>Room Name</td>
                    <td>:</td>
                    <td><?= htmlspecialchars($data['room_name_izzy']) ?></td>
                </tr>
                <tr>
                    <td>Check-in</td>
                    <td>:</td>
                    <td><?= $data['checkin_izzy'] ?></td>
                </tr>
                <tr>
                    <td>Check-out</td>
                    <td>:</td>
                    <td><?= $data['checkout_izzy'] ?></td>
                </tr>
                <tr>
                    <td>Nights</td>
                    <td>:</td>
                    <td><?= $data['nights_count_izzy'] ?> night(s)</td>
                </tr>
            </table>
        </div>
        <div class="price-breakdown mb-4">
            <hr style="border-top: 2px dashed #000;">
            <h6 class="fw-bold">Price Breakdown</h6>
            <table class="table table-borderless">
                <?php if (!empty($data['service_fees_izzy'])):
                                    $services = json_decode($data['service_fees_izzy'], true);
                                    if ($services): ?>
                <tr>
                    <td colspan="2"><strong>Additional Services</strong></td>
                </tr>
                <?php foreach ($services as $s): ?>
                <tr>
                    <td class="ps-3">•<?=htmlspecialchars($s['name'])?></td>
                    <td class="text-end">$<?= number_format($s['total'], 2) ?></td>
                </tr>
                <?php endforeach; ?>
                <?php endif;
                                endif; ?>

                <tr>
                    <td>Extra Bed Fee</td>
                    <td class="text-end">$<?= number_format($data['extra_bed_fee_izzy'], 2) ?></td>
                </tr>
                <tr>
                    <td>Subtotal</td>
                    <td class="text-end">$<?= number_format($data['subtotal_izzy'], 2) ?></td>
                </tr>
                <tr>
                    <td>Tax</td>
                    <td class="text-end">$<?= number_format($data['tax_izzy'], 2) ?></td>
                </tr>
                <tr>
                    <td>Discount</td>
                    <td class="text-end text-danger">- $<?= number_format($data['discount_izzy'], 2) ?></td>
                </tr>
                <tr>
                    <td colspan="2">
                        <hr>
                    </td>
                </tr>
                <tr class="fw-bold">
                    <td>Total Amount</td>
                    <td class="text-end">$<?= number_format($data['total_price_izzy'], 2) ?></td>
                </tr>
            </table>
        </div>

        <hr style="border-top: 2px dashed #000;">
        <div class="text-center mt-4">
            <p class="mb-0">Thank you for choosing</p>
            <strong>IZZY HOTEL</strong>
        </div>
    </div>

    <div class="d-flex justify-content-center mt-3">
        <button onclick="window.location.href='index_izzy.php'" class="btn btn-secondary me-2">Home</button>
        <button onclick="window.location.href='reservation_izzy.php'" class="btn btn-primary me-2">My
            Reservation</button>
        <button onclick="printStruk()" class="btn btn-success">Print PDF</button>
    </div>

    <?php require('inc/footer_izzy.php'); ?>
    <style>
    @media print {
        body {
            background-color: white !important;
            font-family: 'Courier New', Courier, monospace;
        }

        .d-print-none {
            display: none !important;
        }

        .d-print-block {
            display: block !important;
        }

        .receipt {
            width: 100% !important;
            max-width: 100% !important;
            border: none !important;
            box-shadow: none !important;
            padding: 0 !important;
            margin: 0 !important;
        }

        .container,
        .container-fluid {
            width: 100% !important;
            max-width: 100% !important;
            padding: 0 !important;
            margin: 0 !important;
        }

        * {
            color: black !important;
            text-shadow: none !important;
        }

        .page-break {
            page-break-before: always;
        }

        #signature-section {
            margin-top: 3rem !important;
            padding-top: 2rem !important;
        }
    }
    </style>
    <script>
        function printStruk() {
        document.body.classList.add('printing');

        const footer = document.querySelector('footer');
        const header = document.querySelector('header');
        const buttons = document.querySelector('.d-flex.justify-content-center.mt-3');

        if (header) header.classList.add('d-print-none');
        if (footer) footer.classList.add('d-print-none');
        if (buttons) buttons.classList.add('d-print-none');

        let signatureSection = document.getElementById('signature-section');
        if (!signatureSection) {
            signatureSection = document.createElement('div');
            signatureSection.id = 'signature-section';
            signatureSection.className = 'row mt-5 d-print-block d-none';
            signatureSection.innerHTML = `
            <div class="col-md-6 offset-md-6">
                <div class="mb-5">
                    <p>Generated on: ${new Date().toLocaleString()}</p>
                </div>
            </div>
        `;

            const receiptContent = document.getElementById('receipt-content');
            if (receiptContent && receiptContent.parentNode) {
                receiptContent.parentNode.appendChild(signatureSection);
            }
        }

        window.print();

        setTimeout(function() {
            document.body.classList.remove('printing');
            if (header) header.classList.remove('d-print-none');
            if (footer) footer.classList.remove('d-print-none');
            if (buttons) buttons.classList.remove('d-print-none');

            // Remove the signature section if we created it
            if (signatureSection && !signatureSection.classList.contains('d-none')) {
                signatureSection.remove();
            }
        }, 100);
    }
    </script>