<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Payment</title>
    <?php require('inc/links_izzy.php'); ?>
</head>
<?php
date_default_timezone_set('Asia/Jakarta');
require('inc/header_izzy.php');

if (!isset($_SESSION['user_id_izzy'])) {
    echo "<script>
            alert('You need to log in first!');
            window.location.href='index_izzy.php?show_register=true';
          </script>";
    exit;   
}

$IzzyRoomId = $_REQUEST['room_id_izzy'] ?? '';
$IzzyCheckin = $_REQUEST['checkin_izzy'] ?? '';
$IzzyCheckout = $_REQUEST['checkout_izzy'] ?? '';
$IzzyPersonq = $_REQUEST['person_q_izzy'] ?? '';
$IzzyUserName = $_REQUEST['user_name_izzy'] ?? '';
$IzzyUserEmail = $_REQUEST['user_email_izzy'] ?? '';
$IzzyTotalPrice = $_REQUEST['total_price_izzy'] ?? '';
$IzzyType = $_REQUEST['type_izzy'] ?? '';
$IzzyStatus = $_REQUEST['status_izzy'] ?? '';
$IzzyPrice = $_REQUEST['price_izzy'] ?? '';
$IzzyBasePrice = $_REQUEST['base_price_izzy'] ?? '';
$IzzyTransactionId = $_REQUEST['id'] ?? '';

$IzzyTransactionId = $_GET['id_transaction_izzy'];
$IzzyUserId = $_SESSION['user_id_izzy'];

$IzzyQuery = "SELECT t.*, r.name_izzy as room_name, u.name_izzy as user_name
              FROM transaction_izzy t 
              JOIN rooms_izzy r ON t.id_room_izzy = r.id_room_izzy 
              JOIN user_izzy u ON t.id_izzy = u.id_izzy 
              WHERE t.id_transaction_izzy = ? AND t.id_izzy = ?";
$IzzyRoomId = isset($_POST['room_id_izzy']) ? $_POST['room_id_izzy'] : '';
$IzzyCheckin = isset($_POST['checkin_izzy']) ? $_POST['checkin_izzy'] : '';
$IzzyCheckout = isset($_POST['checkout_izzy']) ? $_POST['checkout_izzy'] : '';
$IzzyUserEmail = isset($_POST['user_email_izzy']) ? $_POST['user_email_izzy'] : '';
$IzzyType = isset($_POST['type_izzy']) ? $_POST['type_izzy'] : '';
$IzzyStmt = mysqli_prepare($con, $IzzyQuery);
mysqli_stmt_bind_param($IzzyStmt, "ii", $IzzyTransactionId, $IzzyUserId);
mysqli_stmt_execute($IzzyStmt);
$IzzyResult = mysqli_stmt_get_result($IzzyStmt);


if (!$IzzyData = mysqli_fetch_assoc($IzzyResult)) {
    header("Location: index_izzy.php");
    exit;
}

$IzzyData = array_merge($IzzyData, $_SESSION['transaction_data']);

$IzzyTotalPrice = number_format((float)$IzzyData['total_price_izzy'], 2, '.', '');
$IzzyCreatedAt = strtotime($IzzyData['create_at']);
$IzzyStatus = $IzzyData['status_izzy'];
$IzzyRoomName = $IzzyData['room_name'];
$IzzyUserName = $IzzyData['user_name'];
$IzzyBasePrice = isset($_SESSION['transaction_data']['base_price_izzy']) ? $_SESSION['transaction_data']['base_price_izzy'] : $IzzyData['price_izzy'];


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['next'])) {
    $IzzyBasePrice = $_POST['base_price_izzy'];  

    $_SESSION['transaction_data'] = array(
        'base_price_izzy' => $IzzyBasePrice,
        'per_night_rate_izzy' => $_POST['per_night_rate_izzy'],
        'nights_count_izzy' => $_POST['nights_count_izzy'],
        'room_rate_total_izzy' => $_POST['room_rate_total_izzy'],
        'extra_bed_fee_izzy' => $_POST['extra_bed_fee_izzy'],
        'service_fees_izzy' => $_POST['service_fees_izzy'],
        'subtotal_izzy' => $_POST['subtotal_izzy'],
        'tax_izzy' => $_POST['tax_izzy'],
        'discount_izzy' => $_POST['discount_izzy'],
        'total_price_izzy' => $_POST['total_price_izzy']
    );
    $IzzyCheckin = $_POST['checkin_izzy'];
    $IzzyCheckout = $_POST['checkout_izzy'];
    $IzzyPersonq = $_POST['person_q_izzy'];
    $IzzyTotalPrice = $_POST['total_price_izzy'];
    $IzzyUserName = $_SESSION['user_name_izzy'];
    $IzzyUserEmail = $_POST['user_email_izzy'];
    $IzzyUserId = $_SESSION['user_id_izzy'];
    $IzzyRoomId = $_POST['room_id_izzy'];
    $IzzyRoomName = $_POST['name_izzy'];
    $IzzyType = $_POST['type_izzy'];
    $IzzyCheckQuery = "SELECT * FROM transaction_izzy
        WHERE id_room_izzy = ?
        AND status_izzy != 'canceled'
        AND (
            (? BETWEEN checkin_izzy AND checkout_izzy)
            OR
            (? BETWEEN checkin_izzy AND checkout_izzy)
            OR
            (checkin_izzy BETWEEN ? AND ?)
        )";

    $IzzyCheckStmt = mysqli_prepare($con, $IzzyCheckQuery);
    mysqli_stmt_bind_param($IzzyCheckStmt, "issss",
        $IzzyRoomId,
        $IzzyCheckin,
        $IzzyCheckout,
        $IzzyCheckin,
        $IzzyCheckout
    );
    mysqli_stmt_execute($IzzyCheckStmt);
    $IzzyCheckResult = mysqli_stmt_get_result($IzzyCheckStmt);

    if (mysqli_num_rows($IzzyCheckResult) > 0) {
        echo "<script>
                alert('The selected dates are already booked. Please choose different dates.');
                window.location.href='booking_izzy.php?id=$IzzyRoomId';
              </script>";
        echo "tanggal sudah dibooking";
        exit;
    }

    $IzzyCapacityQuery = "SELECT guest_capacity_izzy FROM rooms_izzy WHERE id_room_izzy = ?";
    $IzzyCapacityStmt = mysqli_prepare($con, $IzzyCapacityQuery);
    mysqli_stmt_bind_param($IzzyCapacityStmt, "i", $IzzyRoomId);
    mysqli_stmt_execute($IzzyCapacityStmt);
    $IzzyCapacityResult = mysqli_stmt_get_result($IzzyCapacityStmt);
    $IzzyRoomCapacity = mysqli_fetch_assoc($IzzyCapacityResult)['guest_capacity_izzy'];
    $IzzyExtraBedRequired = $IzzyPersonq > $IzzyRoomCapacity;

    $hasServices = false;
    $selectedServices = array();

    if(isset($_POST['selected_facilities']) && is_array($_POST['selected_facilities'])) {
        $facilityIds = $_POST['selected_facilities'];
        
        if(!empty($facilityIds)) {
            $placeholders = str_repeat('?,', count($facilityIds) - 1) . '?';
            $servicesQuery = "SELECT * FROM add_facilities_izzy WHERE id_add_izzy IN ($placeholders)";
            $stmt = mysqli_prepare($con, $servicesQuery);
            
            $types = str_repeat('i', count($facilityIds));
            mysqli_stmt_bind_param($stmt, $types, ...$facilityIds);
            mysqli_stmt_execute($stmt);
            $servicesResult = mysqli_stmt_get_result($stmt);
            
            while($service = mysqli_fetch_assoc($servicesResult)) {
                $hasServices = true;
                $selectedServices[] = array(
                    'name' => $service['add_name_izzy'],
                    'price' => $service['add_price_izzy']
                );
            }
        }
    }
}


$IzzyExpiryTime = $IzzyCreatedAt + (15 * 60);

if (time() > $IzzyExpiryTime && $IzzyStatus !== 'completed') {
    $IzzyUpdate = "UPDATE transaction_izzy SET status_izzy = 'canceled' WHERE id_transaction_izzy = ?";
    $IzzyStmt = mysqli_prepare($con, $IzzyUpdate);
    mysqli_stmt_bind_param($IzzyStmt, "i", $IzzyTransactionId);
    mysqli_stmt_execute($IzzyStmt);

    $IzzyUpdate = "UPDATE rooms_izzy SET room_status_izzy = 'available' WHERE id_room_izzy = ?";
    $IzzyStmt = mysqli_prepare($con, $IzzyUpdate);
    mysqli_stmt_bind_param($IzzyStmt, "i", $IzzyRoomId);
    mysqli_stmt_execute($IzzyStmt);

    echo "<script>
            alert('Transaction expired and has been canceled.');
            window.location.href = 'reservation_izzy.php';
          </script>";
    exit;
}

if ($IzzyStatus === "upcoming") {

    $IzzyUpdate = "UPDATE transaction_izzy SET status_izzy = 'upcoming' WHERE id_transaction_izzy = ?";
    $IzzyStmt = mysqli_prepare($con, $IzzyUpdate);
    mysqli_stmt_bind_param($IzzyStmt, "i", $IzzyTransactionId);
    mysqli_stmt_execute($IzzyStmt);
}

$IzzyDetailsQuery = "SELECT t.person_q_izzy, r.guest_capacity_izzy
                     FROM transaction_izzy t
                     INNER JOIN rooms_izzy r ON t.id_room_izzy = r.id_room_izzy
                     WHERE t.id_transaction_izzy = ?";
$IzzyDetailsStmt = mysqli_prepare($con, $IzzyDetailsQuery);
mysqli_stmt_bind_param($IzzyDetailsStmt, "i", $IzzyTransactionId);
mysqli_stmt_execute($IzzyDetailsStmt);
$IzzyDetailsResult = mysqli_stmt_get_result($IzzyDetailsStmt);
if ($IzzyDetails = mysqli_fetch_assoc($IzzyDetailsResult)) {
    $IzzyPersonq = $IzzyDetails['person_q_izzy'];
    $IzzyRoomCapacity = $IzzyDetails['guest_capacity_izzy'];
    $IzzyExtraBedRequired = $IzzyPersonq > $IzzyRoomCapacity;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['confirm_payment'])) {
    $IzzyTransactionId = $_REQUEST['id'] ?? '';
    $IzzyUserName = $_REQUEST['user_name_izzy'] ?? '';
    $IzzyUserEmail = $_REQUEST['user_email_izzy'] ?? '';
    $IzzyCheckinDate = $_POST['checkin_izzy'];
    $IzzyCheckoutDate = $_POST['checkout_izzy'];
    $IzzyPersonq = $_POST['person_q_izzy'];
    $IzzyType = $_REQUEST['type_izzy'] ?? '';
    $IzzyTotalPrice = (float)$_POST['total_price_izzy']; 
    $IzzyStatus = $_REQUEST['status_izzy'] ?? '';
    $IzzyUserId = $_SESSION['user_id_izzy'];
    $IzzyPrice = $_REQUEST['price_izzy'] ?? '';
    $IzzyRoomId = $_POST['room_id_izzy'];
    $IzzyBasePrice = $_REQUEST['base_price_izzy'] ?? '';
    $getRoomQuery = "SELECT id_room_izzy, checkin_izzy FROM transaction_izzy WHERE id_transaction_izzy = ?";
    $stmt = mysqli_prepare($con, $getRoomQuery);
    mysqli_stmt_bind_param($stmt, "i", $IzzyTransactionId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $roomData = mysqli_fetch_assoc($result);
    $roomId = $roomData['id_room_izzy'];
    $checkinDate = $roomData['checkin_izzy'];

    $IzzyUpdate = "UPDATE transaction_izzy SET status_izzy = 'upcoming' WHERE id_transaction_izzy = ?";
    $IzzyStmt = mysqli_prepare($con, $IzzyUpdate);
    mysqli_stmt_bind_param($IzzyStmt, "i", $IzzyTransactionId);

    if (mysqli_stmt_execute($IzzyStmt)) {
        echo "<script>window.location.href='transaction_information_izzy.php?id=$IzzyTransactionId'</script>";
        exit;
    } else {
        echo "<script>alert('Payment failed! Please try again.');</script>";
    }
}
?>

<body class="bg-light">
    <div class="container mt-5 mb-5">
        <div class="card shadow-lg border-0">
            <div class="card-header text-white text-center py-4"
                style="background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);">
                <h2 class="fw-bold mb-0">Payment Confirmation</h2>
                <p class="mb-0 mt-2">Complete your payment within the time limit</p>
            </div>

            <div class="card-body p-4">
                <div class="booking-progress mb-4">
                    <div class="progress" style="height: 4px;">
                        <div class="progress-bar bg-success" role="progressbar" style="width: 100%"></div>
                    </div>
                    <div class="d-flex justify-content-between mt-2">
                        <span class="badge bg-success">Room Selected</span>
                        <span class="badge bg-success">Details Confirmed</span>
                        <span class="badge bg-success">Payment</span>
                    </div>
                </div>
                <div class="timer-card mb-4">
                    <div class="countdown-display">
                        <i class="bi bi-alarm fs-1"></i>
                        <div id="countdown" class="countdown"></div>
                        <p class="text-muted mb-0">Time remaining to complete payment</p>
                    </div>
                </div>
                <form action="transaction_information_izzy.php" method="GET">
                    <input type="hidden" name="room_id_izzy" value="<?php echo $IzzyRoomId; ?>">
                    <input type="hidden" name="checkin_izzy" value="<?php echo $IzzyCheckin; ?>">
                    <input type="hidden" name="checkout_izzy" value="<?php echo $IzzyCheckout; ?>">
                    <input type="hidden" name="person_q_izzy" value="<?php echo $IzzyPersonq; ?>">
                    <input type="hidden" name="user_name_izzy" value="<?php echo $IzzyUserName; ?>">
                    <input type="hidden" name="user_email_izzy" value="<?php echo $IzzyUserEmail; ?>">
                    <input type="hidden" name="total_price_izzy"
                        value="<?php echo number_format((float)$IzzyTotalPrice, 2, '.', ''); ?>">
                    <input type="hidden" name="type_izzy" value="<?php echo $IzzyType; ?>">
                    <input type="hidden" name="status_izzy" value="<?php echo $IzzyStatus; ?>">
                    <input type="hidden" name="price_izzy" value="<?php echo $IzzyBasePrice; ?>">
                    <input type="hidden" name="base_price_izzy" value="<?php echo $IzzyBasePrice; ?>">


                    <div class="payment-summary">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card border-0 bg-light mb-3">
                                    <div class="card-body">
                                        <h4 class="card-title mb-3">
                                            <i class="bi bi-info-circle"></i> Transaction Details
                                        </h4>
                                        <table class="table table-borderless">
                                            <tr>
                                                <th>Transaction ID</th>
                                                <td>: #<?php echo $IzzyTransactionId; ?></td>
                                            </tr>
                                            <tr>
                                                <th>Room Name</th>
                                                <td>: <?php echo htmlspecialchars($IzzyRoomName); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Username</th>
                                                <td>: <?php echo htmlspecialchars($IzzyUserName); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Transaction Date</th>
                                                <td>: <?php echo date('d M Y H:i', $IzzyCreatedAt); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Status</th>
                                                <td>: <span class="badge bg-warning">Pending Payment</span></td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="card border-0 bg-light mb-3">
                                    <div class="card-body">
                                        <h4 class="card-title mb-3">
                                            <i class="bi bi-receipt"></i> Payment Details
                                        </h4>
                                        <table class="table table-borderless">
                                            <tr>
                                                <td>Room Rate (per night)</td>
                                                <td class="text-end">
                                                    $<?= number_format($IzzyData['per_night_rate_izzy'], 2) ?></td>
                                            </tr>
                                            <?php 
                                        if(!empty($IzzyData['service_fees_izzy'])):
                                            $serviceFees = json_decode($IzzyData['service_fees_izzy'], true);
                                            if($serviceFees): 
                                        ?>
                                            <tr>
                                                <td colspan="2"><strong>Additional Services:</strong></td>
                                            </tr>
                                            <?php foreach($serviceFees as $service): ?>
                                            <tr>
                                                <td class="ps-3"><?= htmlspecialchars($service['name']) ?></td>
                                                <td class="text-end">$<?= number_format($service['total'], 2) ?></td>
                                            </tr>
                                            <?php 
                                            endforeach;
                                            endif;
                                        endif; 
                                        ?>

                                            <?php if($IzzyData['extra_bed_fee_izzy'] > 0): ?>
                                            <tr>
                                                <td>Extra Bed Fee</td>
                                                <td class="text-end">
                                                    $<?= number_format($IzzyData['extra_bed_fee_izzy'], 2) ?></td>
                                            </tr>
                                            <?php endif; ?>

                                            <tr>
                                                <td colspan="2">
                                                    <hr>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>Subtotal</td>
                                                <td class="text-end">
                                                    $<?= number_format($IzzyData['subtotal_izzy'], 2) ?></td>
                                            </tr>
                                            <tr>
                                                <td>Tax (10%)</td>
                                                <td class="text-end">$<?= number_format($IzzyData['tax_izzy'], 2) ?>
                                                </td>
                                            </tr>
                                            <?php if($IzzyData['discount_izzy'] > 0): ?>
                                            <tr class="text-success">
                                                <td>Discount (5%)</td>
                                                <td class="text-end text-danger">
                                                    -$<?= number_format($IzzyData['discount_izzy'], 2) ?></td>
                                            </tr>
                                            <?php endif; ?>
                                            <tr class="fw-bold">
                                                <td>Total Amount</td>
                                                <td class="text-end">
                                                    $<?= number_format($IzzyData['total_price_izzy'], 2) ?></td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" name="id" value="<?php echo $IzzyTransactionId; ?>">
                    <div class="payment-methods mb-4">
                        <h4 class="mb-3"><i class="bi bi-credit-card"></i> Select Payment Method</h4>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="payment-options">
                                    <div class="form-check payment-option-card mb-3">
                                        <input class="form-check-input" type="radio" name="payment_method"
                                            id="creditCard" value="credit_card" checked>
                                        <label class="form-check-label d-flex align-items-center" for="creditCard">
                                            <span class="payment-icon me-3">
                                                <i class="bi bi-credit-card-2-front fs-3"></i>
                                            </span>
                                            <div>
                                                <span class="d-block fw-bold">Credit/Debit Card</span>
                                                <small class="text-muted">Visa, Mastercard, American Express</small>
                                            </div>
                                            <div class="ms-auto">
                                                <i class="bi bi-credit-card-fill text-primary fs-4 me-2"></i>
                                                <i class="bi bi-credit-card-2-front-fill text-danger fs-4 me-2"></i>
                                                <i class="bi bi-credit-card-2-back-fill text-info fs-4"></i>
                                            </div>
                                        </label>
                                    </div>

                                    <div class="form-check payment-option-card mb-3">
                                        <input class="form-check-input" type="radio" name="payment_method" id="paypal"
                                            value="paypal">
                                        <label class="form-check-label d-flex align-items-center" for="paypal">
                                            <span class="payment-icon me-3">
                                                <i class="bi bi-paypal fs-3"></i>
                                            </span>
                                            <div>
                                                <span class="d-block fw-bold">PayPal</span>
                                                <small class="text-muted">Fast and secure payment</small>
                                            </div>
                                            <div class="ms-auto">
                                                <i class="bi bi-paypal text-primary fs-3"></i>
                                            </div>
                                        </label>
                                    </div>

                                    <div class="form-check payment-option-card mb-3">
                                        <input class="form-check-input" type="radio" name="payment_method"
                                            id="bankTransfer" value="bank_transfer">
                                        <label class="form-check-label d-flex align-items-center" for="bankTransfer">
                                            <span class="payment-icon me-3">
                                                <i class="bi bi-bank fs-3"></i>
                                            </span>
                                            <div>
                                                <span class="d-block fw-bold">Bank Transfer</span>
                                                <small class="text-muted">Make a transfer to our bank account</small>
                                            </div>
                                        </label>
                                    </div>

                                    <div class="form-check payment-option-card">
                                        <input class="form-check-input" type="radio" name="payment_method" id="wallet"
                                            value="e_wallet">
                                        <label class="form-check-label d-flex align-items-center" for="wallet">
                                            <span class="payment-icon me-3">
                                                <i class="bi bi-wallet2 fs-3"></i>
                                            </span>
                                            <div>
                                                <span class="d-block fw-bold">E-Wallet</span>
                                                <small class="text-muted">Google Pay, Apple Pay, and more</small>
                                            </div>
                                            <div class="ms-auto">
                                                <i class="bi bi-google text-danger fs-4 me-2"></i>
                                                <i class="bi bi-apple text-dark fs-4"></i>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button type="submit" name="confirm_payment" class="btn btn-success btn-lg w-100 py-3">
                        <i class="bi bi-credit-card-2-front me-2"></i>Process Payment
                    </button>
                </form>
                <div class="mt-4">
                    <div class="alert alert-info">
                        <h5 class="alert-heading"><i class="bi bi-lightbulb"></i> Payment Instructions:</h5>
                        <ol class="mb-0">
                            <li>Click "Confirm Payment" button to proceed with payment</li>
                            <li>You will be redirected to transaction information page</li>
                            <li>Complete the payment before the timer runs out</li>
                            <li>Your booking will be automatically cancelled if payment is not completed in time</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php require('inc/footer_izzy.php'); ?>
    <style>
    .card {
        border-radius: 15px;
        overflow: hidden;
    }

    .card-header {
        background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
        color: white;
    }

    .timer-card {
        background: #fff;
        border-radius: 15px;
        padding: 2rem;
        text-align: center;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
    }

    .countdown-display {
        color: #dc3545;
    }

    .countdown {
        font-size: 2.5rem;
        font-weight: bold;
        margin: 1rem 0;
    }

    .price-details {
        text-align: center;
        padding: 20px;
        background: rgba(25, 135, 84, 0.1);
        border-radius: 10px;
        font-weight: bold;
    }

    .booking-progress {
        margin-bottom: 2rem;
    }

    .btn-success {
        background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
        border: none;
        font-weight: 600;
    }

    .payment-option-card {
        border: 1px solid #e0e0e0;
        border-radius: 10px;
        padding: 15px;
        transition: all 0.3s ease;
        background-color: #fff;
    }

    .payment-option-card:hover {
        border-color: #4e73df;
        box-shadow: 0 0 10px rgba(78, 115, 223, 0.1);
    }

    .payment-option-card .form-check-input {
        margin-top: 1.2rem;
    }

    .payment-option-card .form-check-label {
        width: 100%;
        cursor: pointer;
    }

    .payment-icon {
        color: #4e73df;
        min-width: 40px;
        text-align: center;
    }

    .payment-option-card .form-check-input:checked~.form-check-label {
        font-weight: bold;
    }

    .payment-option-card .form-check-input:checked~.form-check-label .payment-icon {
        color: #28a745;
    }

    .payment-option-card:has(.form-check-input:checked) {
        border-color: #28a745;
        background-color: rgba(40, 167, 69, 0.05);
    }
    </style>

    <script>
    let expiryTime = <?php echo $IzzyExpiryTime * 1000; ?>;

    function updateCountdown() {
        let now = new Date().getTime();
        let distance = expiryTime - now;

        if (distance <= 0) {
            document.getElementById("countdown").innerHTML = "EXPIRED";
            setTimeout(() => {
                window.location.reload(); // 
            }, 1000);
        } else {
            let minutes = Math.floor((distance % (1000 * 15 * 60)) / (1000 * 60));
            let seconds = Math.floor((distance % (1000 * 60)) / 1000);
            document.getElementById("countdown").innerHTML = minutes + "m " + seconds + "s";
        }
    }

    setInterval(updateCountdown, 1000);
    updateCountdown();

    document.addEventListener("DOMContentLoaded", function() {
        const navigationLinks = document.querySelectorAll("a[data-navigate]");
        navigationLinks.forEach(link => {
            link.addEventListener("click", function(event) {
                event.preventDefault();
                const targetUrl = link.getAttribute("data-navigate");
                const userConfirmed = confirm(
                    "Are you sure you want to leave this page? Unsaved changes will be lost."
                );
                if (userConfirmed) {
                    window.location.href = targetUrl;
                }
            });
        });

        const logoutLink = document.getElementById("logout-link");
        if (logoutLink) {
            logoutLink.addEventListener("click", function(event) {
                event.preventDefault();
                const userConfirmed = confirm("Are you sure you want to logout?");
                if (userConfirmed) {
                    window.location.href = logoutLink.href;
                }
            });
        }
    });
    </script>

</body>

</html>