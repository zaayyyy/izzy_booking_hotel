<?php
require('inc/header_izzy.php');

if (!isset($_SESSION['user_id_izzy'])) {
    echo "<script>
            alert('You need to log in first!');
            window.location.href='index_izzy.php?show_register=true';
          </script>";
    exit;
}

$IzzyUserId = $_SESSION['user_id_izzy'];
$IzzyQuery = "SELECT * FROM user_izzy WHERE id_izzy = ?";
$IzzyStmt = mysqli_prepare($con, $IzzyQuery);
mysqli_stmt_bind_param($IzzyStmt, "i", $IzzyUserId);
mysqli_stmt_execute($IzzyStmt);
$IzzyResult = mysqli_stmt_get_result($IzzyStmt);

if (mysqli_num_rows($IzzyResult) == 0) {
    die("User not found!");
}

$IzzyUser = mysqli_fetch_assoc($IzzyResult);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <?php require('inc/links_izzy.php'); ?>
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #858796;
            --success-color: #1cc88a;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 0.15rem 1.75rem rgba(58, 59, 69, 0.15);
            transition: all 0.3s ease;
        }

        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 0.15rem 1.75rem rgba(58, 59, 69, 0.25);
        }

        h2 {
            color: var(--primary-color);
        }

        .btn-primary {
            background-color: var(--primary-color);
            border: none;
        }

        .btn-primary:hover {
            background-color: #2e59d9;
        }
    </style>
</head>

<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow p-4">
                    <h2 class="fw-bold text-center mb-4">Your Profile</h2>
                    <table class="table">
                        <tr>
                            <th>Full Name</th>
                            <td><?= htmlspecialchars($IzzyUser['name_izzy']) ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><?= htmlspecialchars($IzzyUser['email_izzy']) ?></td>
                        </tr>
                        <tr>
                            <th>Phone</th>
                            <td><?= htmlspecialchars($IzzyUser['phone_izzy']) ?></td>
                        </tr>
                        <tr>
                            <th>Pincode</th>
                            <td><?= htmlspecialchars($IzzyUser['pincode_izzy']) ?></td>
                        </tr>
                        <tr>
                            <th>Address</th>
                            <td><?= htmlspecialchars($IzzyUser['address_izzy']) ?></td>
                        </tr>
                        <tr>
                            <th>Password</th>
                            <td><?= htmlspecialchars($IzzyUser['password_izzy']) ?></td>
                        </tr>
                    </table>
                    <div class="text-end">
                        <button class="btn btn-primary mt-3" data-bs-toggle="modal" data-bs-target="#editProfileModal">Edit Profile</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Profile Modal -->
    <div class="modal fade" id="editProfileModal" tabindex="-1" aria-labelledby="editProfileModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" action="update_profile_izzy.php">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editProfileModalLabel">Edit Profile</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="edit-name" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="edit-name" name="name_izzy" value="<?= htmlspecialchars($IzzyUser['name_izzy']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit-email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="edit-email" name="email_izzy" value="<?= htmlspecialchars($IzzyUser['email_izzy']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit-phone" class="form-label">Phone</label>
                            <input type="text" class="form-control" id="edit-phone" name="phone_izzy" value="<?= htmlspecialchars($IzzyUser['phone_izzy']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit-pincode" class="form-label">Pincode</label>
                            <input type="text" class="form-control" id="edit-pincode" name="pincode_izzy" value="<?= htmlspecialchars($IzzyUser['pincode_izzy']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit-address" class="form-label">Address</label>
                            <textarea class="form-control" id="edit-address" name="address_izzy" rows="3" required><?= htmlspecialchars($IzzyUser['address_izzy']) ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="edit-password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="edit-password" name="password_izzy" value="<?= htmlspecialchars($IzzyUser['password_izzy']) ?>" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php require('inc/footer_izzy.php'); ?>
</body>

</html>
