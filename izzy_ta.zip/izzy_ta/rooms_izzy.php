<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">
    <?php require_once('inc/links_izzy.php'); ?>
    <title>Rooms - Izzy Hotel</title>
</head>

<body class="bg-light">
    <?php
    $IzzyUserLoggedIn = isset($_SESSION['user_id_izzy']);
    require('inc/header_izzy.php');

    $check_in = !empty($_GET['check_in'])
        ? mysqli_real_escape_string($con, $_GET['check_in'])
        : date('Y-m-d');

    $check_out = !empty($_GET['check_out'])
        ? mysqli_real_escape_string($con, $_GET['check_out'])
        : date('Y-m-d', strtotime($check_in . ' +1 day'));

    $IzzyQuery = "SELECT DISTINCT
        r.id_room_izzy, 
        r.name_izzy, 
        r.guest_capacity_izzy, 
        r.price_izzy, 
        r.room_status_izzy, 
        t.type_izzy
    FROM rooms_izzy r
    INNER JOIN room_type_izzy t ON r.id_type_izzy = t.id_type_izzy
    WHERE r.room_status_izzy = 'available'
    AND NOT EXISTS (
        SELECT 1 
        FROM transaction_izzy tr 
        WHERE tr.id_room_izzy = r.id_room_izzy
        AND tr.status_izzy IN ('upcoming', 'booked') 
        AND (
            (tr.checkin_izzy <= ? AND tr.checkout_izzy >= ?)
            OR (tr.checkin_izzy >= ? AND tr.checkin_izzy <= ?)
        )
    )";

    $filters = [];
    if (!empty($_GET['person_count'])) {
        $filters[] = "r.guest_capacity_izzy >= " . (int)$_GET['person_count'];
    }

    if (!empty($filters)) {
        $IzzyQuery .= " AND " . implode(' AND ', $filters);
    }

    $IzzyStmt = mysqli_prepare($con, $IzzyQuery);
    mysqli_stmt_bind_param($IzzyStmt, "ssss", 
        $check_out,
        $check_in,
        $check_in,   
        $check_out 
    );
    mysqli_stmt_execute($IzzyStmt);
    $IzzyResult = mysqli_stmt_get_result($IzzyStmt);
    ?>

    <div class="my-5 px-4">
        <h2 class="fw-bold h-font text-center">OUR ROOMS</h2>
        <div class="h-line bg-dark"></div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-lg-12 bg-white shadow p-4 rounded">
                <form action="" method="GET">
                    <div class="row align-items-end">
                        <div class="col-lg-3 col-md-6 mb-3">
                            <label class="form-label" style="font-weight: 500;">Check-in</label>
                            <input type="date" name="check_in" class="form-control shadow-none"
                                value="<?php echo isset($_GET['check_in']) ? $_GET['check_in'] : ''; ?>">
                        </div>
                        <div class="col-lg-3 col-md-6 mb-3">
                            <label class="form-label" style="font-weight: 500;">Check-out</label>
                            <input type="date" name="check_out" class="form-control shadow-none"
                                value="<?php echo isset($_GET['check_out']) ? $_GET['check_out'] : ''; ?>">
                        </div>
                        <div class="col-lg-3 col-md-6 mb-3">
                            <label class="form-label" style="font-weight: 500;">Number of Persons</label>
                            <input type="number" name="person_count" class="form-control shadow-none"
                                value="<?php echo isset($_GET['person_count']) ? $_GET['person_count'] : ''; ?>"
                                min="1">
                        </div>
                        <div class="col-lg-3 col-md-6 mb-3 text-end">
                            <button type="submit" class="btn text-white shadow-none custom-bg">Apply Filters</button>
                            <a href="<?php echo strtok($_SERVER["REQUEST_URI"], '?'); ?>"
                                class="btn btn-outline-dark shadow-none">Clear Filters</a>
                        </div>
                    </div>
                </form>
            </div>
            <?php
            if (mysqli_num_rows($IzzyResult) == 0) {
                echo "<div class='col-12 mt-4'><div class='alert alert-info text-center'>
                        <i class='bi bi-info-circle me-2'></i>
                        No available rooms found for the selected dates (" . htmlspecialchars($check_in) . " to " . htmlspecialchars($check_out) . ").
                        <br>Please try different dates or adjust your search criteria.
                      </div></div>";
            } else {
                while ($IzzyRow = mysqli_fetch_assoc($IzzyResult)) { ?>
            <div class=" col-lg-4 col-md-6 my-3">
                <div class="card border-0 shadow" style="max-width: 350px; margin: auto;">
                    <img src="images/rooms/1.jpg" class="card-img-top">
                    <div class="card-body">
                        <h5><?php echo $IzzyRow['name_izzy']; ?></h5>
                        <h6 class="mb-4">$<?php echo $IzzyRow['price_izzy']; ?> per night</h6>
                        <div class="features mb-4">
                            <h6 class="mb-1">Room Type</h6>
                            <span class="badge rounded-pill bg-light text-dark mb-3 text-wrap lh-base">
                                <?php echo $IzzyRow['type_izzy']; ?>
                            </span>
                        </div>
                        <div class="guest mb-4">
                            <h6 class="mb-1">Guest</h6>
                            <span class="badge rounded-pill bg-light text-dark mb-3 text-wrap lh-base">
                                <?php echo $IzzyRow['guest_capacity_izzy']; ?> Guests
                            </span>
                        </div>
                        <div class="d-flex justify-content-evenly mb-2">
                            <?php if (isset($_SESSION['user_id_izzy'])): ?>
                            <a href="booking_izzy.php?id=<?php echo $IzzyRow['id_room_izzy']; ?>&check_in=<?php echo $_GET['check_in'] ?? '' ?>&check_out=<?php echo $_GET['check_out'] ?? '' ?> "
                                class="btn btn-sm text-white custom-bg shadow-none ">Book Now</a>
                            <?php else: ?>
                            <button type="button" class="btn btn-sm text-white custom-bg shadow-none book-now-btn"
                                data-room-id="<?php echo $IzzyRow['id_room_izzy']; ?>">Book Now</button>
                            <?php endif; ?>
                            <a href="room_detail_izzy.php?id=<?php echo $IzzyRow['id_room_izzy']; ?>&check_in=<?php echo $_GET['check_in'] ?? '' ?>&check_out=<?php echo $_GET['check_out'] ?? '' ?> "
                                class="btn btn-sm btn-outline-dark shadow-none">More Details</a>
                        </div>

                    </div>
                </div>
            </div>
            <?php }
            } ?>
        </div>
    </div>

    <?php require_once('inc/footer_izzy.php'); ?>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        var bookNowButtons = document.querySelectorAll('.book-now-btn');
        bookNowButtons.forEach(function(btn) {
            btn.addEventListener('click', function() {
                var loginModal = new bootstrap.Modal(document.getElementById('login'));
                loginModal.show();
            });
        });
    });
    document.addEventListener("DOMContentLoaded", function() {
        const logoutLink = document.getElementById("logout-link");

        if (logoutLink) {
            logoutLink.addEventListener("click", function(event) {
                event.preventDefault();
                const userConfirmed = confirm("Are you sure you want to logout?");
                if (userConfirmed) {
                    window.location.href = logoutLink.href; 
                }
            });
        }
    });
    document.addEventListener("DOMContentLoaded", function() {
        const checkInInput = document.querySelector("input[name='check_in']");
        const checkOutInput = document.querySelector("input[name='check_out']");

  
        const today = new Date().toISOString().split("T")[0];
        checkInInput.setAttribute("min", today);

        checkOutInput.disabled = true;

        checkInInput.addEventListener("change", function() {
            const checkInDate = checkInInput.value;
            checkOutInput.disabled = false;
            checkOutInput.setAttribute("min", new Date(new Date(checkInDate).getTime() + 86400000)
                .toISOString().split("T")[0]); // +1 day
            checkOutInput.value = ""; 
        });
    });
    </script>

</body>

</html>