<?php
require('admin/inc/essentials_izzy.php');
require('inc/koneksi_db_izzy.php');
session_start();
if (!isset($_SESSION['user_id_izzy'])) {
    echo "<script>
            alert('You need to log in first!');
            window.location.href='index_izzy.php?show_register=true';
          </script>";
    exit;
}
$transaction_id = $_GET['id'];
$id_user = $_SESSION['user_id_izzy'];


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['confirm_payment'])) {
    $IzzyTransactionId = $_REQUEST['id'] ?? '';
    $IzzyUserName = $_REQUEST['user_name_izzy'] ?? '';
    $IzzyUserEmail = $_REQUEST['user_email_izzy'] ?? '';
    $IzzyCheckinDate = $_POST['checkin_izzy'] ?? '';
    $IzzyCheckoutDate = $_POST['checkout_izzy'] ?? '';
    $IzzyPersonq = $_POST['person_q_izzy'] ?? '';
    $IzzyType = $_REQUEST['type_izzy'] ?? '';
    $IzzyTotalPrice = (float)$_POST['total_price_izzy'] ?? 0;
    $IzzyStatus = $_POST['status_izzy'] ?? 'upcoming';
    $IzzyUserId = $_SESSION['user_id_izzy'] ?? '';
    $IzzyPrice = $_REQUEST['price_izzy'] ?? '';
    $IzzyRoomId = $_POST['room_id_izzy'] ?? '';
    $IzzyBasePrice = $_REQUEST['base_price_izzy'] ?? '';
    $IzzyRoomName = $_POST['name_izzy'] ?? ''; 
    $IzzyPerNightRate = $_POST['per_night_rate_izzy'] ?? '';
    $IzzyNightsCount = $_POST['nights_count_izzy'] ?? ''; 
    $IzzyRoomRateTotal = $_POST['room_rate_total_izzy'] ?? '';
    $IzzyExtraBedFee = $_POST['extra_bed_fee_izzy'] ?? '';
    $IzzyServiceFees = $_POST['service_fees_izzy'] ?? ''; 
    $IzzySubtotal = $_POST['subtotal_izzy'] ?? ''; 
    $IzzyTax = $_POST['tax_izzy'] ?? '';     $IzzyDiscount = $_POST['discount_izzy'] ?? ''; 
    $IzzyTotalPriceWithTax = $_POST['total_price_izzy'] ?? '';


    mysqli_stmt_bind_param(
        $IzzyStmt,
        "iiiddidssssssddd",
        $IzzyUserId,
        $IzzyRoomId,
        $IzzyPersonq,
        $totalPrice,
        $perNightRate,
        $nightsCount,
        $extraBedFee,
        $serviceFees,
        $IzzyCheckinDate,
        $IzzyCheckinTime,
        $IzzyCheckoutDate,
        $IzzyCheckoutTime,
        $IzzyStatus,
        $subtotal,
        $tax,
        $discount
    );

    if (mysqli_stmt_execute($IzzyStmt)) {
        $last_id = mysqli_insert_id($con);

        if (isset($_POST['selected_facilities_data']) && !empty($_POST['selected_facilities_data'])) {
            $_SESSION['selected_facilities_data'] = $_POST['selected_facilities_data'];
        }
        header("Location: Tconfirmation_izzy.php?id_transaction_izzy=$last_id");
        exit();
    } else {
        header("Location: " . $_SERVER['HTTP_REFERER']);
        exit();
    }


    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['next'])) {

        $IzzyBasePrice = $_POST['base_price_izzy'];

        $_SESSION['transaction_data'] = array(
            'base_price_izzy' => $IzzyBasePrice,
            'per_night_rate_izzy' => $_POST['per_night_rate_izzy'],
            'nights_count_izzy' => $_POST['nights_count_izzy'],
            'room_rate_total_izzy' => $_POST['room_rate_total_izzy'],
            'extra_bed_fee_izzy' => $_POST['extra_bed_fee_izzy'],
            'service_fees_izzy' => $_POST['service_fees_izzy'],
            'subtotal_izzy' => $_POST['subtotal_izzy'],
            'tax_izzy' => $_POST['tax_izzy'],
            'discount_izzy' => $_POST['discount_izzy'],
            'total_price_izzy' => $_POST['total_price_izzy']
        );
        $IzzyCheckin = $_POST['checkin_izzy'];
        $IzzyCheckout = $_POST['checkout_izzy'];
        $IzzyPersonq = $_POST['person_q_izzy'];
        $IzzyTotalPrice = $_POST['total_price_izzy'];
        $IzzyUserName = $_SESSION['user_name_izzy'];
        $IzzyUserEmail = $_POST['user_email_izzy'];
        $IzzyUserId = $_SESSION['user_id_izzy'];
        $IzzyRoomId = $_POST['room_id_izzy'];
        $IzzyRoomName = $_POST['name_izzy'];
        $IzzyType = $_POST['type_izzy'];
        $IzzyCheckQuery = "SELECT * FROM transaction_izzy
        WHERE id_room_izzy = ?
        AND status_izzy != 'canceled'
        AND (
            (? BETWEEN checkin_izzy AND checkout_izzy)
            OR
            (? BETWEEN checkin_izzy AND checkout_izzy)
            OR
            (checkin_izzy BETWEEN ? AND ?)
        )";

        $IzzyCheckStmt = mysqli_prepare($con, $IzzyCheckQuery);
        mysqli_stmt_bind_param(
            $IzzyCheckStmt,
            "issss",
            $IzzyRoomId,
            $IzzyCheckin,
            $IzzyCheckout,
            $IzzyCheckin,
            $IzzyCheckout
        );
        mysqli_stmt_execute($IzzyCheckStmt);
        $IzzyCheckResult = mysqli_stmt_get_result($IzzyCheckStmt);

        if (mysqli_num_rows($IzzyCheckResult) > 0) {
            echo "<script>
                alert('The selected dates are already booked. Please choose different dates.');
                window.location.href='booking_izzy.php?id=$IzzyRoomId';
              </script>";
            echo "tanggal sudah dibooking";
            exit;
        }
        $IzzyCapacityQuery = "SELECT guest_capacity_izzy FROM rooms_izzy WHERE id_room_izzy = ?";
        $IzzyCapacityStmt = mysqli_prepare($con, $IzzyCapacityQuery);
        mysqli_stmt_bind_param($IzzyCapacityStmt, "i", $IzzyRoomId);
        mysqli_stmt_execute($IzzyCapacityStmt);
        $IzzyCapacityResult = mysqli_stmt_get_result($IzzyCapacityStmt);
        $IzzyRoomCapacity = mysqli_fetch_assoc($IzzyCapacityResult)['guest_capacity_izzy'];
        $IzzyExtraBedRequired = $IzzyPersonq > $IzzyRoomCapacity;

        $hasServices = false;
        $selectedServices = array();

        if (isset($_POST['selected_facilities']) && is_array($_POST['selected_facilities'])) {
            $facilityIds = $_POST['selected_facilities'];

            if (!empty($facilityIds)) {
                $placeholders = str_repeat('?,', count($facilityIds) - 1) . '?';
                $servicesQuery = "SELECT * FROM add_facilities_izzy WHERE id_add_izzy IN ($placeholders)";
                $stmt = mysqli_prepare($con, $servicesQuery);

                $types = str_repeat('i', count($facilityIds));
                mysqli_stmt_bind_param($stmt, $types, ...$facilityIds);
                mysqli_stmt_execute($stmt);
                $servicesResult = mysqli_stmt_get_result($stmt);

                while ($service = mysqli_fetch_assoc($servicesResult)) {
                    $hasServices = true;
                    $selectedServices[] = array(
                        'name' => $service['add_name_izzy'],
                        'price' => $service['add_price_izzy']
                    );
                }
            }
        }
    }

    function getRandomPrice($basePrice, $date, $roomId)
    {
        $seed = crc32($date . $roomId);
        mt_srand($seed);

        // Generate a random percentage between -20% to +20%
        $randomPercentage = mt_rand(-20, 20);
        $priceAdjustment = $basePrice * ($randomPercentage / 100);
        $finalPrice = $basePrice + $priceAdjustment;

        // Reset the random seed
        mt_srand();

        return number_format($finalPrice, 2, '.', '');
    }
}

$stmt = $con->prepare("SELECT t.*, t.tax_izzy, t.subtotal_izzy, t.discount_izzy, t.total_price_izzy,
                       t.per_night_rate_izzy, t.nights_count_izzy, t.extra_bed_fee_izzy, t.service_fees_izzy,
                       r.name_izzy AS room_name, u.name_izzy AS user_name, 
                       r.guest_capacity_izzy, r.id_room_izzy 
                       FROM transaction_izzy t
                       JOIN user_izzy u ON t.id_izzy = u.id_izzy
                       JOIN rooms_izzy r ON t.id_room_izzy = r.id_room_izzy
                       WHERE t.id_transaction_izzy = ? AND t.id_izzy = ?");
$stmt->bind_param("ii", $transaction_id, $id_user);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<script>alert('Transaction not found!'); window.location.href='index_izzy.php';</script>";
    exit;
}

$data = $result->fetch_assoc();
$hasServices = false;
$selectedServices = [];

if (isset($_SESSION['selected_facilities_data'])) {
    $selectedServices = json_decode($_SESSION['selected_facilities_data'], true);
    $hasServices = !empty($selectedServices);
    unset($_SESSION['selected_facilities_data']);
}

// Proses upload proof pembayaran
if (isset($_POST['proof_izzy'])) {
    $fileName = $_FILES['proof']['name'];
    $tmpName = $_FILES['proof']['tmp_name'];
    $uploadDir = "uploads/";

    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $targetPath = $uploadDir . time() . "_" . basename($fileName);

    if (move_uploaded_file($tmpName, $targetPath)) {
        $stmtUpdate = $con->prepare("UPDATE transaction_izzy SET proof_izzy = ? WHERE id_transaction_izzy = ?");
        $stmtUpdate->bind_param("si", $targetPath, $transaction_id);
        $stmtUpdate->execute();

        $data['proof_payment'] = $targetPath;
        $success = "Proof of payment successfully sent!";
    } else {
        $error = "Failed to upload proof of payment.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Transaction Info</title>
    <?php require('inc/links_izzy.php') ?>
</head>

<body class="bg-light">
    <?php require('inc/header_izzy.php') ?>

    <div class="container mt-5 mb-5">
        <div class="card shadow-lg border-0">
            <div class="card-header text-white text-center py-4"
                style="background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);">
                <h2 class="fw-bold mb-0">Transaction Information</h2>
                <p class="mb-0 mt-2">Review your booking details and payment</p>
            </div>

            <div class="card-body p-4">
                <?php if (isset($success)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="bi bi-check-circle me-2"></i><?= $success ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if (isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-exclamation-circle me-2"></i><?= $error ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="booking-card">
                            <div class="card-header">
                                <i class="bi bi-info-circle fs-4"></i>
                                <h5>Booking Details</h5>
                            </div>
                            <div class="card-body">
                                <ul class="list-unstyled mb-0">
                                    <li class="mb-3">
                                        <span class="text-muted">Guest Name:</span>
                                        <div class="fw-bold"><?= htmlspecialchars($data['user_name']) ?></div>
                                    </li>
                                    <li class="mb-3">
                                        <span class="text-muted">Room:</span>
                                        <div class="fw-bold"><?= htmlspecialchars($data['room_name']) ?></div>
                                    </li>
                                    <li class="mb-3">
                                        <span class="text-muted">Number of Guests:</span>
                                        <div class="fw-bold">
                                            <?= $data['person_q_izzy'] ?> person(s)
                                            <?php if (
                                                isset($data['guest_capacity_izzy']) && isset($data['person_q_izzy']) &&
                                                $data['person_q_izzy'] > $data['guest_capacity_izzy']
                                            ): ?>
                                                <span class="badge bg-info">Extra Bed</span>
                                            <?php endif; ?>
                                        </div>
                                    </li>
                                    <li class="mb-3">
                                        <span class="text-muted">Check-in:</span>
                                        <div class="fw-bold"><?= $data['checkin_izzy'] ?>
                                    </li>
                                    <li class="mb-3">
                                        <span class="text-muted">Check-out:</span>
                                        <div class="fw-bold"><?= $data['checkout_izzy'] ?>
                                    </li>
                                    <?php if ($hasServices): ?>
                                        <li class="mb-3">
                                            <span class="text-muted">Additional Services:</span>
                                            <div class="mt-2">
                                                <?php foreach ($selectedServices as $service): ?>
                                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                                        <span><?= htmlspecialchars($service['name']); ?></span>
                                                        <span
                                                            class="badge bg-primary">$<?= number_format($service['price'], 2); ?></span>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        </li>
                                    <?php endif; ?>
                                    <li class="mb-3">
                                        <span class="text-muted">Booking Date:</span>
                                        <div class="fw-bold"><?= date('d M Y H:i', strtotime($data['create_at'])) ?>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="booking-card">
                            <div class="card-header">
                                <i class="bi bi-credit-card fs-4"></i>
                                <h5>Total Payment</h5>
                            </div>
                            <div class="card-body">
                                <div class="price-details p-3 bg-light rounded">
                                    <table class="table table-borderless">
                                        <tr>
                                            <?php
                                            if (!empty($data['service_fees_izzy'])) {
                                                $services = json_decode($data['service_fees_izzy'], true);
                                                foreach ($services as $service):
                                            ?>
                                        <tr>
                                            <td><?= htmlspecialchars($service['name']) ?></td>
                                            <td class="text-end">$<?= number_format($service['total'], 2) ?></td>
                                        </tr>
                                <?php
                                                endforeach;
                                            }
                                ?>
                                <tr>
                                    <td>Nights (x<?= $data['nights_count_izzy'] ?>)</td>
                                    <td class="text-end">$<?= number_format($data['per_night_rate_izzy'] * $data['nights_count_izzy'], 2) ?></td>
                                </tr>
                                <tr>
                                    <td>Extra Bed Fee</td>
                                    <td class="text-end">$<?= number_format($data['extra_bed_fee_izzy'], 2) ?></td>
                                </tr>
                                <tr>
                                    <td>Subtotal</td>
                                    <td class="text-end">$<?= number_format($data['subtotal_izzy'], 2) ?></td>
                                </tr>
                                <tr>
                                    <td>Tax</td>
                                    <td class="text-end">$<?= number_format($data['tax_izzy'], 2) ?></td>
                                </tr>
                                <tr>
                                    <td>Discount</td>
                                    <td class="text-end text-danger">- $<?= number_format($data['discount_izzy'], 2) ?></td>
                                </tr>

                                <tr>
                                    <td colspan="2">
                                        <hr>
                                    </td>
                                </tr>
                                <tr class="fw-bold">
                                    <td>Total Amount</td>
                                    <td class="text-end">$<?= number_format($data['total_price_izzy'], 2) ?></td>
                                </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if (empty($data['proof_payment'])): ?>
                    <div class="booking-card mt-4">
                        <div class="card-header">
                            <i class="bi bi-upload fs-4"></i>
                            <h5>Upload Payment Proof</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label class="form-label">Upload Proof of Payment</label>
                                    <input type="file" name="proof" class="form-control" required>
                                </div>
                                <button type="submit" name="proof_izzy" class="btn btn-primary">
                                    <i class="bi bi-cloud-upload me-2"></i>Upload Proof
                                </button>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="d-flex justify-content-center mt-3">
                        <button onclick="window.location.href='index_izzy.php'" class="btn btn-secondary me-2">Back</button>
                        <button onclick="window.location.href='reservation_izzy.php'" class="btn btn-primary me-2">My Reservation</button>
                        <button onclick="printPDF()" class="btn btn-success">Print PDF</button>
                    </div>

                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php require('inc/footer_izzy.php'); ?>

    <!-- jsPDF CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script>
        async function printPDF() {
            const {
                jsPDF
            } = window.jspdf;
            const doc = new jsPDF();

            const receiptElement = document.getElementById('receipt-content');
            const html = receiptElement.outerHTML;

            const canvas = await html2canvas(receiptElement);
            const imgData = canvas.toDataURL('image/png');

            const pageWidth = doc.internal.pageSize.getWidth();
            const imgProps = doc.getImageProperties(imgData);
            const imgHeight = (imgProps.height * pageWidth) / imgProps.width;

            doc.addImage(imgData, 'PNG', 0, 10, pageWidth, imgHeight);
            doc.save("Struk_Transaksi_IZZY.pdf");
        }

        document.addEventListener("DOMContentLoaded", function() {
            const navigationLinks = document.querySelectorAll("a[data-navigate]");

            navigationLinks.forEach(link => {
                link.addEventListener("click", function(event) {
                    event.preventDefault();
                    const targetUrl = link.getAttribute("data-navigate");

                    const userConfirmed = confirm(
                        "Are you sure you want to leave this page? Unsaved changes will be lost."
                    );
                    if (userConfirmed) {
                        window.location.href = targetUrl;
                    }
                });
            });
        });
        document.addEventListener("DOMContentLoaded", function() {
            const logoutLink = document.getElementById("logout-link");

            if (logoutLink) {
                logoutLink.addEventListener("click", function(event) {
                    event.preventDefault();
                    const userConfirmed = confirm("Are you sure you want to logout?");
                    if (userConfirmed) {
                        window.location.href = logoutLink.href;
                    }
                });
            }
        });
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>

    <style>
        .booking-card {
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: 15px;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .booking-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }

        .booking-card .card-header {
            background: #f8f9fa;
            padding: 1rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .price-details {
            background: rgba(25, 135, 84, 0.1);
            padding: 1.5rem;
            border-radius: 10px;
        }

        .btn {
            transition: all 0.3s ease;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.875rem;
        }
    </style>
</body>

</html>