<?php
require('inc/koneksi_db_izzy.php');
session_start();

if (!isset($_SESSION['user_id_izzy'])) {
    header('Location: index_izzy.php?show_register=true');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_SESSION['user_id_izzy'];
    $name = $_POST['name_izzy'];
    $email = $_POST['email_izzy'];
    $phone = $_POST['phone_izzy'];
    $pincode = $_POST['pincode_izzy'];
    $address = $_POST['address_izzy'];
    $password = $_POST['password_izzy'];

    $query = "UPDATE user_izzy SET 
                name_izzy = ?, 
                email_izzy = ?, 
                phone_izzy = ?, 
                pincode_izzy = ?, 
                address_izzy = ?, 
                password_izzy = ? 
              WHERE id_izzy = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, 'ssssssi', $name, $email, $phone, $pincode, $address, $password, $userId);

    if (mysqli_stmt_execute($stmt)) {
        header('Location: profile_izzy.php?success=update');
    } else {
        header('Location: profile_izzy.php?error=update');
    }
    exit;
}
?>