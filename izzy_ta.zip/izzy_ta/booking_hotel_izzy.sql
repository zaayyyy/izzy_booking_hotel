-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 15, 2025 at 11:12 AM
-- Server version: 8.4.3
-- PHP Version: 8.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `booking_hotel_izzy`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_facilities_izzy`
--

CREATE TABLE `add_facilities_izzy` (
  `id_add_izzy` int NOT NULL,
  `add_name_izzy` varchar(150) NOT NULL,
  `add_desc_izzy` text NOT NULL,
  `add_price_izzy` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_facilities_izzy`
--

INSERT INTO `add_facilities_izzy` (`id_add_izzy`, `add_name_izzy`, `add_desc_izzy`, `add_price_izzy`) VALUES
(1, 'breakfast', 'delicious breakfast', 5),
(2, 'spa', 'spa', 15),
(3, '3', '3', 10);

-- --------------------------------------------------------

--
-- Table structure for table `admin_izzy`
--

CREATE TABLE `admin_izzy` (
  `id_admin_izzy` int NOT NULL,
  `username_admin_izzy` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `password_admin_izzy` varchar(250) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_izzy`
--

INSERT INTO `admin_izzy` (`id_admin_izzy`, `username_admin_izzy`, `password_admin_izzy`) VALUES
(1, 'zay', '123');

-- --------------------------------------------------------

--
-- Table structure for table `cashier_izzy`
--

CREATE TABLE `cashier_izzy` (
  `id_cashier_izzy` int NOT NULL,
  `username_cashier_izzy` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `password_cashier_izzy` varchar(250) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cashier_izzy`
--

INSERT INTO `cashier_izzy` (`id_cashier_izzy`, `username_cashier_izzy`, `password_cashier_izzy`) VALUES
(1, 'zay', '123');

-- --------------------------------------------------------

--
-- Table structure for table `facilities_izzy`
--

CREATE TABLE `facilities_izzy` (
  `id_izzy` int NOT NULL,
  `name_izzy` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `description_izzy` text COLLATE utf8mb4_general_ci,
  `created_at_izzy` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `image_izzy` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `facilities_izzy`
--

INSERT INTO `facilities_izzy` (`id_izzy`, `name_izzy`, `description_izzy`, `created_at_izzy`, `image_izzy`) VALUES
(1, 'Wi-Fi', 'High-speed internet access', '2025-03-25 09:22:00', 'wifi.svg\r\n'),
(2, 'TV', 'Cable television with various channels', '2025-03-25 09:22:00', 'television.svg'),
(3, 'Fire Detector', 'Smoke and fire detection system', '2025-03-25 09:22:00', 'firedetector.svg'),
(4, 'Spa', 'Relaxing spa treatments and massages', '2025-03-25 09:22:00', 'spa.svg'),
(5, 'Air Conditioner', 'Air conditioning system for comfortable room temperature', '2025-03-25 09:22:00', 'ac.svg');

-- --------------------------------------------------------

--
-- Table structure for table `rooms_izzy`
--

CREATE TABLE `rooms_izzy` (
  `id_room_izzy` int NOT NULL,
  `name_izzy` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `id_type_izzy` int NOT NULL,
  `guest_capacity_izzy` int NOT NULL,
  `price_izzy` int NOT NULL,
  `room_status_izzy` enum('available','booked','clean') COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms_izzy`
--

INSERT INTO `rooms_izzy` (`id_room_izzy`, `name_izzy`, `id_type_izzy`, `guest_capacity_izzy`, `price_izzy`, `room_status_izzy`) VALUES
(1, 'Room 101', 2, 2, 50, 'available'),
(2, 'Room 102', 1, 1, 1, 'available'),
(3, 'Room 103', 2, 3, 65, 'available'),
(4, 'Room 104', 2, 3, 70, 'available'),
(5, 'Room 105', 2, 2, 5, 'available'),
(6, 'Room 106', 3, 4, 80, 'available'),
(7, 'Room 107', 3, 4, 85, 'available'),
(8, 'Room 108', 2, 3, 67, 'available'),
(9, 'Room 109', 1, 2, 53, 'available'),
(10, 'Room 110', 2, 3, 69, 'available'),
(11, 'Room 111', 2, 3, 11, 'available');

-- --------------------------------------------------------

--
-- Table structure for table `room_type_izzy`
--

CREATE TABLE `room_type_izzy` (
  `id_type_izzy` int NOT NULL,
  `type_izzy` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room_type_izzy`
--

INSERT INTO `room_type_izzy` (`id_type_izzy`, `type_izzy`) VALUES
(1, 'Premium'),
(2, 'Deluxe'),
(3, 'Twin Bed');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_izzy`
--

CREATE TABLE `transaction_izzy` (
  `id_transaction_izzy` int NOT NULL,
  `id_room_izzy` int NOT NULL,
  `id_izzy` int NOT NULL,
  `person_q_izzy` int NOT NULL,
  `total_price_izzy` float NOT NULL,
  `per_night_rate_izzy` decimal(10,2) DEFAULT NULL,
  `nights_count_izzy` int DEFAULT NULL,
  `extra_bed_fee_izzy` decimal(10,2) DEFAULT '0.00',
  `service_fees_izzy` text COLLATE utf8mb4_general_ci,
  `checkin_izzy` date NOT NULL,
  `checkin_time_izzy` time DEFAULT NULL,
  `checkout_izzy` date NOT NULL,
  `checkout_time_izzy` time DEFAULT NULL,
  `status_izzy` enum('upcoming','completed','canceled','pending') COLLATE utf8mb4_general_ci NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `proof_izzy` varchar(250) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `reschedule_status_izzy` enum('none','requested','approved','rejected') COLLATE utf8mb4_general_ci DEFAULT 'none',
  `reschedule_note` text COLLATE utf8mb4_general_ci,
  `new_checkin_izzy` date DEFAULT NULL,
  `new_checkout_izzy` date DEFAULT NULL,
  `new_checkin_time_izzy` time DEFAULT NULL,
  `new_checkout_time_izzy` time DEFAULT NULL,
  `subtotal_izzy` decimal(10,2) DEFAULT '0.00',
  `tax_izzy` decimal(10,2) DEFAULT '0.00',
  `discount_izzy` decimal(10,2) DEFAULT '0.00',
  `status_payment_izzy` enum('pending','paid','canceled') COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction_izzy`
--

INSERT INTO `transaction_izzy` (`id_transaction_izzy`, `id_room_izzy`, `id_izzy`, `person_q_izzy`, `total_price_izzy`, `per_night_rate_izzy`, `nights_count_izzy`, `extra_bed_fee_izzy`, `service_fees_izzy`, `checkin_izzy`, `checkin_time_izzy`, `checkout_izzy`, `checkout_time_izzy`, `status_izzy`, `create_at`, `proof_izzy`, `reschedule_status_izzy`, `reschedule_note`, `new_checkin_izzy`, `new_checkout_izzy`, `new_checkin_time_izzy`, `new_checkout_time_izzy`, `subtotal_izzy`, `tax_izzy`, `discount_izzy`, `status_payment_izzy`) VALUES
(304, 11, 1, 1, 30.05, 12.32, 1, 0.00, '[{\"id\":\"1\",\"name\":\"breakfast\",\"price\":5,\"total\":5},{\"id\":\"3\",\"name\":\"3\",\"price\":10,\"total\":10}]', '2025-05-06', '11:11:00', '2025-05-07', '11:01:00', 'upcoming', '2025-05-05 13:54:51', 'uploads/1746453305_Screenshot (25).png', 'none', NULL, NULL, NULL, NULL, NULL, 27.32, 2.73, 0.00, 'pending'),
(305, 4, 1, 4, 302.44, 73.50, 3, 25.00, '[{\"id\":\"1\",\"name\":\"breakfast\",\"price\":5,\"total\":15},{\"id\":\"2\",\"name\":\"spa\",\"price\":15,\"total\":45}]', '2025-05-08', '11:11:00', '2025-05-17', '11:11:00', 'upcoming', '2025-05-05 14:08:47', 'uploads/1746454199_Screenshot (25).png', 'approved', NULL, NULL, NULL, NULL, NULL, 305.50, 30.55, 33.61, 'pending'),
(306, 7, 1, 1, 103.34, 73.95, 1, 0.00, '[{\"id\":\"1\",\"name\":\"breakfast\",\"price\":5,\"total\":5},{\"id\":\"2\",\"name\":\"spa\",\"price\":15,\"total\":15}]', '2025-05-05', '11:11:00', '2025-05-06', '11:11:00', 'upcoming', '2025-05-05 15:57:13', 'uploads/1746460652_Screenshot (24).png', 'none', NULL, NULL, NULL, NULL, NULL, 93.95, 9.40, 0.00, 'pending'),
(307, 7, 1, 1, 134.92, 92.65, 1, 0.00, '[{\"id\":\"1\",\"name\":\"breakfast\",\"price\":5,\"total\":5},{\"id\":\"2\",\"name\":\"spa\",\"price\":15,\"total\":15},{\"id\":\"3\",\"name\":\"3\",\"price\":10,\"total\":10}]', '2025-05-14', '11:11:00', '2025-05-15', '11:11:00', 'upcoming', '2025-05-05 16:14:41', 'uploads/1746461695_Screenshot (25).png', 'approved', NULL, NULL, NULL, NULL, NULL, 122.65, 12.27, 0.00, 'pending'),
(308, 11, 1, 1, 34.95, 11.77, 1, 0.00, '[{\"id\":\"1\",\"name\":\"breakfast\",\"price\":5,\"total\":5},{\"id\":\"2\",\"name\":\"spa\",\"price\":15,\"total\":15}]', '2025-05-23', '11:11:00', '2025-05-24', '11:11:00', 'upcoming', '2025-05-05 16:43:02', 'uploads/1746463391_Screenshot (25).png', 'approved', NULL, NULL, NULL, NULL, NULL, 31.77, 3.18, 0.00, 'pending'),
(309, 3, 1, 3, 85.63, 57.85, 1, 0.00, '[{\"id\":\"1\",\"name\":\"breakfast\",\"price\":5,\"total\":5},{\"id\":\"2\",\"name\":\"spa\",\"price\":15,\"total\":15}]', '2025-05-28', '11:11:00', '2025-05-29', '11:11:00', 'upcoming', '2025-05-05 17:29:37', 'uploads/1746466194_Screenshot (25).png', 'requested', NULL, '2025-05-14', '2025-05-15', '11:11:00', '11:11:00', 77.85, 7.79, 0.00, 'pending'),
(310, 2, 1, 1, 6.68, 1.07, 1, 0.00, '[{\"id\":\"1\",\"name\":\"breakfast\",\"price\":5,\"total\":5}]', '2025-05-22', NULL, '2025-05-23', NULL, 'upcoming', '2025-05-15 05:23:27', 'uploads/1747286684_cek.png', 'none', NULL, NULL, NULL, NULL, NULL, 6.07, 0.61, 0.00, 'paid'),
(311, 2, 1, 1, 4.4, 1.00, 4, 0.00, '[]', '2025-05-15', NULL, '2025-05-19', NULL, 'upcoming', '2025-05-15 07:51:49', 'uploads/1747295518_cek.png', 'none', NULL, NULL, NULL, NULL, NULL, 4.00, 0.40, 0.00, 'pending'),
(312, 3, 1, 1, 65.06, 59.15, 1, 0.00, '[]', '2025-05-16', NULL, '2025-05-17', NULL, 'upcoming', '2025-05-15 08:42:17', 'uploads/1747298607_cek.png', 'none', NULL, NULL, NULL, NULL, NULL, 59.15, 5.92, 0.00, 'paid'),
(313, 11, 1, 1, 11.62, 10.56, 1, 0.00, '[]', '2025-05-16', NULL, '2025-05-17', NULL, 'upcoming', '2025-05-15 11:11:47', NULL, 'none', NULL, NULL, NULL, NULL, NULL, 10.56, 1.06, 0.00, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `user_izzy`
--

CREATE TABLE `user_izzy` (
  `id_izzy` int NOT NULL,
  `name_izzy` varchar(255) NOT NULL,
  `email_izzy` varchar(255) NOT NULL,
  `phone_izzy` varchar(15) NOT NULL,
  `pincode_izzy` varchar(10) NOT NULL,
  `address_izzy` text NOT NULL,
  `password_izzy` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status_izzy` enum('pending','active','inactive') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_izzy`
--

INSERT INTO `user_izzy` (`id_izzy`, `name_izzy`, `email_izzy`, `phone_izzy`, `pincode_izzy`, `address_izzy`, `password_izzy`, `created_at`, `status_izzy`) VALUES
(1, 'izzy', 'izzy123@gmail.com', '012839238', '123', 'cimahi', '123', '2025-02-17 10:52:49', 'active'),
(2, 'gavin', 'gavin123@gmail.com', '123123', '123', 'bandung', 'gavin123', '2025-02-23 12:09:41', 'active'),
(3, 'ggg', 'zzz123@gmail.com', '123123', '321', 'moscow', 'zzz', '2025-03-05 15:31:07', 'pending');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_facilities_izzy`
--
ALTER TABLE `add_facilities_izzy`
  ADD PRIMARY KEY (`id_add_izzy`);

--
-- Indexes for table `admin_izzy`
--
ALTER TABLE `admin_izzy`
  ADD PRIMARY KEY (`id_admin_izzy`);

--
-- Indexes for table `cashier_izzy`
--
ALTER TABLE `cashier_izzy`
  ADD PRIMARY KEY (`id_cashier_izzy`);

--
-- Indexes for table `facilities_izzy`
--
ALTER TABLE `facilities_izzy`
  ADD PRIMARY KEY (`id_izzy`);

--
-- Indexes for table `rooms_izzy`
--
ALTER TABLE `rooms_izzy`
  ADD PRIMARY KEY (`id_room_izzy`),
  ADD KEY `id_type_izzy` (`id_type_izzy`);

--
-- Indexes for table `room_type_izzy`
--
ALTER TABLE `room_type_izzy`
  ADD PRIMARY KEY (`id_type_izzy`);

--
-- Indexes for table `transaction_izzy`
--
ALTER TABLE `transaction_izzy`
  ADD PRIMARY KEY (`id_transaction_izzy`),
  ADD KEY `id_room_izzy` (`id_room_izzy`),
  ADD KEY `id_user_izzy` (`id_izzy`);

--
-- Indexes for table `user_izzy`
--
ALTER TABLE `user_izzy`
  ADD PRIMARY KEY (`id_izzy`),
  ADD UNIQUE KEY `email_izzy` (`email_izzy`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_facilities_izzy`
--
ALTER TABLE `add_facilities_izzy`
  MODIFY `id_add_izzy` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `admin_izzy`
--
ALTER TABLE `admin_izzy`
  MODIFY `id_admin_izzy` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cashier_izzy`
--
ALTER TABLE `cashier_izzy`
  MODIFY `id_cashier_izzy` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `facilities_izzy`
--
ALTER TABLE `facilities_izzy`
  MODIFY `id_izzy` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `rooms_izzy`
--
ALTER TABLE `rooms_izzy`
  MODIFY `id_room_izzy` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=224;

--
-- AUTO_INCREMENT for table `room_type_izzy`
--
ALTER TABLE `room_type_izzy`
  MODIFY `id_type_izzy` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `transaction_izzy`
--
ALTER TABLE `transaction_izzy`
  MODIFY `id_transaction_izzy` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=314;

--
-- AUTO_INCREMENT for table `user_izzy`
--
ALTER TABLE `user_izzy`
  MODIFY `id_izzy` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rooms_izzy`
--
ALTER TABLE `rooms_izzy`
  ADD CONSTRAINT `rooms_izzy_ibfk_2` FOREIGN KEY (`id_type_izzy`) REFERENCES `room_type_izzy` (`id_type_izzy`);

--
-- Constraints for table `transaction_izzy`
--
ALTER TABLE `transaction_izzy`
  ADD CONSTRAINT `transaction_izzy_ibfk_1` FOREIGN KEY (`id_room_izzy`) REFERENCES `rooms_izzy` (`id_room_izzy`),
  ADD CONSTRAINT `transaction_izzy_ibfk_2` FOREIGN KEY (`id_izzy`) REFERENCES `user_izzy` (`id_izzy`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
