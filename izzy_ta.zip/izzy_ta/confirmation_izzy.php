<?php
session_start();
require('inc/koneksi_db_izzy.php');

if (!isset($_SESSION['user_id_izzy'])) {
    header("Location: index_izzy.php?show_register=true");
    exit;
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['confirm_booking'])) {
    if (isset($_POST['next']) && $_POST['next'] === 'cancel') {
        $IzzyRoomId = $_POST['room_id_izzy'];
        header("Location: booking_izzy.php?id=$IzzyRoomId");
        exit();
    }
    $IzzyTransactionId = $_REQUEST['id'] ?? '';
    $IzzyUserName = $_REQUEST['user_name_izzy'] ?? '';
    $IzzyUserEmail = $_REQUEST['user_email_izzy'] ?? '';
    $IzzyCheckinDate = $_POST['checkin_izzy'] ?? '';
    $IzzyCheckoutDate = $_POST['checkout_izzy'] ?? '';
    $IzzyPersonq = $_POST['person_q_izzy'] ?? '';
    $IzzyType = $_REQUEST['type_izzy'] ?? '';
    $IzzyTotalPrice = (float)$_POST['total_price_izzy'] ?? 0;
    $IzzyStatus = $_POST['status_izzy'] ?? 'upcoming';
    $IzzyUserId = $_SESSION['user_id_izzy'] ?? '';
    $IzzyPrice = $_REQUEST['price_izzy'] ?? '';
    $IzzyRoomId = $_POST['room_id_izzy'] ?? '';
    $IzzyBasePrice = $_REQUEST['base_price_izzy'] ?? '';
    $IzzyRoomName = $_POST['name_izzy'] ?? ''; // Corresponds to name_izzy
    $IzzyPerNightRate = $_POST['per_night_rate_izzy'] ?? ''; // Corresponds to per_night_rate_izzy
    $IzzyNightsCount = $_POST['nights_count_izzy'] ?? ''; // Corresponds to nights_count_izzy
    $IzzyRoomRateTotal = $_POST['room_rate_total_izzy'] ?? ''; // Corresponds to room_rate_total_izzy
    $IzzyExtraBedFee = $_POST['extra_bed_fee_izzy'] ?? ''; // Corresponds to extra_bed_fee_izzy
    $IzzyServiceFees =$_POST['service_fees_izzy']; // Corresponds to service_fees_izzy
    $IzzySubtotal = $_POST['subtotal_izzy'] ?? ''; // Corresponds to subtotal_izzy
    $IzzyTax = $_POST['tax_izzy'] ?? ''; // Corresponds to tax_izzy
    $IzzyDiscount = $_POST['discount_izzy'] ?? ''; // Corresponds to discount_izzy
    $IzzyTotalPriceWithTax = $_POST['total_price_izzy'] ?? ''; // Corresponds to total_price_izzy
    $IzzyInsert = "INSERT INTO transaction_izzy (
        id_izzy,
        id_room_izzy,
        person_q_izzy,
        total_price_izzy,
        per_night_rate_izzy,
        nights_count_izzy,
        extra_bed_fee_izzy,
        service_fees_izzy,
        checkin_izzy,
        checkout_izzy,
        status_izzy,
        subtotal_izzy,
        tax_izzy,
        discount_izzy
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $IzzyStmt = mysqli_prepare($con, $IzzyInsert);


    mysqli_stmt_bind_param(
        $IzzyStmt,
        "iiiddidsssssss", // Data types
        $IzzyUserId,
        $IzzyRoomId,
        $IzzyPersonq,
        $IzzyTotalPrice,
        $IzzyPerNightRate,
        $IzzyNightsCount,
        $IzzyExtraBedFee,
        $IzzyServiceFees,
        $IzzyCheckinDate,
        $IzzyCheckoutDate,
        $IzzyStatus,
        $IzzySubtotal,
        $IzzyTax,
        $IzzyDiscount
    );

    if (mysqli_stmt_execute($IzzyStmt)) {
        $last_id = mysqli_insert_id($con);

        if (isset($_POST['selected_facilities_data']) && !empty($_POST['selected_facilities_data'])) {
            $_SESSION['selected_facilities_data'] = $_POST['selected_facilities_data'];
        }
        header("Location: Tconfirmation_izzy.php?id_transaction_izzy=$last_id");
        exit();
    } else {
        header("Location: " . $_SERVER['HTTP_REFERER']);
        exit();
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['next'])) {
    $IzzyBasePrice = $_POST['base_price_izzy'];
    $_SESSION['transaction_data'] = array(
        'base_price_izzy' => $IzzyBasePrice,
        'per_night_rate_izzy' => $_POST['per_night_rate_izzy'],
        'nights_count_izzy' => $_POST['nights_count_izzy'],
        'room_rate_total_izzy' => $_POST['room_rate_total_izzy'],
        'extra_bed_fee_izzy' => $_POST['extra_bed_fee_izzy'],
        'service_fees_izzy' => $_POST['service_fees_izzy'],
        'subtotal_izzy' => $_POST['subtotal_izzy'],
        'tax_izzy' => $_POST['tax_izzy'],
        'discount_izzy' => $_POST['discount_izzy'],
        'total_price_izzy' => $_POST['total_price_izzy']
    );

    $IzzyCheckin = $_POST['checkin_izzy'];
    $IzzyCheckout = $_POST['checkout_izzy'];
    $IzzyPersonq = $_POST['person_q_izzy'];
    $IzzyTotalPrice = $_POST['total_price_izzy'];
    $IzzyUserName = $_SESSION['user_name_izzy'];
    $IzzyUserEmail = $_POST['user_email_izzy'];
    $IzzyUserId = $_SESSION['user_id_izzy'];
    $IzzyRoomId = $_POST['room_id_izzy'];
    $IzzyRoomName = $_POST['name_izzy'];
    $IzzyStatus = $_POST['status_izzy'] ?? 'upcoming';
    $IzzyType = $_POST['type_izzy'];
    $IzzyCheckQuery = "SELECT * FROM transaction_izzy
        WHERE id_room_izzy = ?
        AND status_izzy != 'canceled'
        AND (
            (? BETWEEN checkin_izzy AND checkout_izzy)
            OR
            (? BETWEEN checkin_izzy AND checkout_izzy)
            OR
            (checkin_izzy BETWEEN ? AND ?)
        )";

    $IzzyCheckStmt = mysqli_prepare($con, $IzzyCheckQuery);
    mysqli_stmt_bind_param(
        $IzzyCheckStmt,
        "issss",
        $IzzyRoomId,
        $IzzyCheckin,
        $IzzyCheckout,
        $IzzyCheckin,
        $IzzyCheckout
    );
    mysqli_stmt_execute($IzzyCheckStmt);
    $IzzyCheckResult = mysqli_stmt_get_result($IzzyCheckStmt);

    if (mysqli_num_rows($IzzyCheckResult) > 0) {
        echo "<script>
                alert('The selected dates are already booked. Please choose different dates.');
                window.location.href='booking_izzy.php?id=$IzzyRoomId';
              </script>";
        echo "tanggal sudah dibooking";
        exit;
    }

    $IzzyCapacityQuery = "SELECT guest_capacity_izzy FROM rooms_izzy WHERE id_room_izzy = ?";
    $IzzyCapacityStmt = mysqli_prepare($con, $IzzyCapacityQuery);
    mysqli_stmt_bind_param($IzzyCapacityStmt, "i", $IzzyRoomId);
    mysqli_stmt_execute($IzzyCapacityStmt);
    $IzzyCapacityResult = mysqli_stmt_get_result($IzzyCapacityStmt);
    $IzzyRoomCapacity = mysqli_fetch_assoc($IzzyCapacityResult)['guest_capacity_izzy'];
    $IzzyExtraBedRequired = $IzzyPersonq > $IzzyRoomCapacity;

    $hasServices = false;
    $selectedServices = array();

    if (isset($_POST['selected_facilities']) && is_array($_POST['selected_facilities'])) {
        $facilityIds = $_POST['selected_facilities'];

        if (!empty($facilityIds)) {
            $placeholders = str_repeat('?,', count($facilityIds) - 1) . '?';
            $servicesQuery = "SELECT * FROM add_facilities_izzy WHERE id_add_izzy IN ($placeholders)";
            $stmt = mysqli_prepare($con, $servicesQuery);

            $types = str_repeat('i', count($facilityIds));
            mysqli_stmt_bind_param($stmt, $types, ...$facilityIds);
            mysqli_stmt_execute($stmt);
            $servicesResult = mysqli_stmt_get_result($stmt);

            while ($service = mysqli_fetch_assoc($servicesResult)) {
                $hasServices = true;
                $selectedServices[] = array(
                    'name' => $service['add_name_izzy'],
                    'price' => $service['add_price_izzy']
                );
            }
        }
    }
}

function getRandomPrice($basePrice, $date, $roomId)
{
    $seed = crc32($date . $roomId);
    mt_srand($seed);


    $randomPercentage = mt_rand(-20, 20);
    $priceAdjustment = $basePrice * ($randomPercentage / 100);
    $finalPrice = $basePrice + $priceAdjustment;

    mt_srand();

    return number_format($finalPrice, 2, '.', '');
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Confirmation</title>
    <?php require('inc/links_izzy.php'); ?>
</head>

<?php require('inc/header_izzy.php'); ?>

<body class="bg-light">
    <div class="container mt-5 mb-5">
        <div class="card shadow-lg border-0">
            <div class="card-header bg-gradient text-white text-center py-4"
                style="background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);">
                <h2 class="fw-bold mb-0">Booking Details</h2>
                <p class="mb-0 mt-2">Please review your booking information carefully</p>
            </div>

            <div class="card-body p-4">
                <div class="booking-progress mb-4">
                    <div class="progress" style="height: 4px;">
                        <div class="progress-bar bg-success" role="progressbar" style="width: 66%"></div>
                    </div>
                    <div class="d-flex justify-content-between mt-2">
                        <span class="badge bg-success">Room Selected</span>
                        <span class="badge bg-success">Details Confirmed</span>
                        <span class="badge bg-secondary">Payment</span>
                    </div>
                </div>

                <form action="" method="POST">
                    <input type="hidden" name="room_id_izzy" value="<?php echo $IzzyRoomId; ?>">
                    <input type="hidden" name="checkin_izzy" value="<?php echo $IzzyCheckin; ?>">
                    <input type="hidden" name="checkout_izzy" value="<?php echo $IzzyCheckout; ?>">
                    <input type="hidden" name="person_q_izzy" value="<?php echo $IzzyPersonq; ?>">
                    <input type="hidden" name="user_name_izzy" value="<?php echo $IzzyUserName; ?>">
                    <input type="hidden" name="user_email_izzy" value="<?php echo $IzzyUserEmail; ?>">
                    <input type="hidden" name="total_price_izzy"
                        value="<?php echo number_format((float)$IzzyTotalPrice, 2, '.', ''); ?>">
                    <input type="hidden" name="type_izzy" value="<?php echo $IzzyType; ?>">
                    <input type="hidden" name="status_izzy" value="<?php echo $IzzyStatus; ?>">
                    <input type="hidden" name="price_izzy" value="<?php echo $IzzyBasePrice; ?>">
                    <input type="hidden" name="base_price_izzy" value="<?php echo $IzzyBasePrice; ?>">
                    <input type="hidden" name="base_price_izzy" value="<?php echo htmlspecialchars($IzzyBasePrice); ?>">
                    <input type="hidden" name="per_night_rate_izzy" value="<?php echo htmlspecialchars($_POST['per_night_rate_izzy'] ?? ''); ?>">
                    <input type="hidden" name="nights_count_izzy" value="<?php echo htmlspecialchars($_POST['nights_count_izzy'] ?? ''); ?>">
                    <input type="hidden" name="room_rate_total_izzy" value="<?php echo htmlspecialchars($_POST['room_rate_total_izzy'] ?? ''); ?>">
                    <input type="hidden" name="extra_bed_fee_izzy" value="<?php echo htmlspecialchars($_POST['extra_bed_fee_izzy'] ?? ''); ?>">
                    <input type="hidden" name="service_fees_izzy" value="<?php echo htmlspecialchars($_POST['service_fees_izzy'] ?? ''); ?>">
                    <input type="hidden" name="subtotal_izzy" value="<?php echo htmlspecialchars($_POST['subtotal_izzy'] ?? ''); ?>">
                    <input type="hidden" name="tax_izzy" value="<?php echo htmlspecialchars($_POST['tax_izzy'] ?? ''); ?>">
                    <input type="hidden" name="discount_izzy" value="<?php echo htmlspecialchars($_POST['discount_izzy'] ?? ''); ?>">
                    <input type="hidden" name="total_price_izzy" value="<?php echo htmlspecialchars($_POST['total_price_izzy'] ?? ''); ?>">
                    <div class="row g-4">
                        <div class="col-md-6">
                            <div class="booking-card h-100">
                                <div class="card-header">
                                    <i class="bi bi-person-circle fs-4"></i>
                                    <h5>Guest Information</h5>
                                </div>
                                <div class="card-body">
                                    <ul class="list-unstyled mb-0">
                                        <li class="mb-3">
                                            <span class="text-muted">Full Name:</span>
                                            <div class="fw-bold"><?php echo htmlspecialchars($IzzyUserName) ?></div>
                                        </li>
                                        <li class="mb-3">
                                            <span class="text-muted">Email:</span>
                                            <div class="fw-bold"><?php echo htmlspecialchars($IzzyUserEmail) ?></div>
                                        </li>
                                        <li>
                                            <span class="text-muted">Number of Guests:</span>
                                            <div class="fw-bold">
                                                <?php echo htmlspecialchars($IzzyPersonq) ?> Person(s)
                                                <?php if ($IzzyExtraBedRequired): ?>
                                                    <span class="badge bg-info ms-2">Extra Bed Required</span>
                                                <?php endif; ?>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="booking-card h-100">
                                <div class="card-header">
                                    <i class="bi bi-house-door fs-4"></i>
                                    <h5>Room Information</h5>
                                </div>
                                <div class="card-body">
                                    <ul class="list-unstyled mb-0">
                                        <li class="mb-3">
                                            <span class="text-muted">Room Name:</span>
                                            <div class="fw-bold"><?php echo htmlspecialchars($IzzyRoomName) ?></div>
                                        </li>
                                        <li class="mb-3">
                                            <span class="text-muted">Room Type:</span>
                                            <div>
                                                <span
                                                    class="badge bg-primary"><?php echo htmlspecialchars($IzzyType) ?></span>
                                            </div>
                                        </li>
                                        <li>
                                            <span class="text-muted">Base Price:</span>
                                            <div class="fw-bold text-success">
                                                $<?php echo number_format((float)$IzzyBasePrice, 2) ?> per night
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="booking-card h-100">
                                <div class="card-header">
                                    <i class="bi bi-calendar-check fs-4"></i>
                                    <h5>Stay Details</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <div class="p-3 bg-light rounded">
                                                <small class="text-muted d-block">Check-in</small>
                                                <div class="fw-bold"><?php echo htmlspecialchars($IzzyCheckin) ?></div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="p-3 bg-light rounded">
                                                <small class="text-muted d-block">Check-out</small>
                                                <div class="fw-bold"><?php echo htmlspecialchars($IzzyCheckout) ?></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="booking-card h-100">
                                <div class="card-header">
                                    <i class="bi bi-credit-card fs-4"></i>
                                    <h5>Payment Summary</h5>
                                </div>
                                <div class="card-body">
                                    <div class="bg-light p-3 rounded">
                                        <div class="price-breakdown mb-4">
                                            <h6 class="fw-bold">Price Details</h6>
                                            <table class="table table-borderless">
                                                <tr>
                                                    <td>Room Rate (per night)</td>
                                                    <td class="text-end">
                                                        $<?= number_format((float)$_POST['per_night_rate_izzy'], 2) ?>
                                                    </td>
                                                </tr>

                                                <?php if (isset($_POST['service_fees_izzy']) && !empty($_POST['service_fees_izzy'])):
                                                    $serviceFees = json_decode($_POST['service_fees_izzy'], true);
                                                    foreach ($serviceFees as $service): ?>
                                                        <tr>
                                                            <td><?= htmlspecialchars($service['name']) ?></td>
                                                            <td class="text-end">$<?= number_format($service['total'], 2) ?>
                                                            </td>
                                                        </tr>
                                                <?php endforeach;
                                                endif; ?>

                                                <?php if ((float)$_POST['extra_bed_fee_izzy'] > 0): ?>
                                                    <tr>
                                                        <td>Extra Bed Fee</td>
                                                        <td class="text-end">
                                                            $<?= number_format((float)$_POST['extra_bed_fee_izzy'], 2) ?>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>

                                                <tr>
                                                    <td colspan="2">
                                                        <hr>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>Subtotal</td>
                                                    <td class="text-end">
                                                        $<?= number_format((float)$_POST['subtotal_izzy'], 2) ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Tax (10%)</td>
                                                    <td class="text-end">
                                                        $<?= number_format((float)$_POST['tax_izzy'], 2) ?></td>
                                                </tr>
                                                <tr class="fw-bold">
                                                    <td>Total Amount</td>
                                                    <td class="text-end">
                                                        $<?= number_format((float)$_POST['total_price_izzy'], 2) ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-center gap-3 mt-4">
                        <button type="button" class="btn btn-lg btn-outline-danger px-5" onclick="confirmCancel()">
                            <i class="bi bi-x-circle me-2"></i>Cancel Booking
                        </button>
                        <button type="submit" class="btn btn-lg btn-success px-5" name="confirm_booking">
                            <i class="bi bi-arrow-right-circle me-2"></i>Proceed to Payment
                        </button>
                        <input type="hidden" name="next" id="booking_action" value="proceed">
                    </div>
            </div>
            </form>
        </div>
    </div>
    </div>
    <style>
        .booking-card {
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: 15px;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .booking-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }

        .booking-card .card-header {
            background: #f8f9fa;
            padding: 1rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .booking-progress {
            padding: 1rem;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }

        .btn {
            transition: all 0.3s ease;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .card {
            border-radius: 15px;
            overflow: hidden;
        }

        .card-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%) !important;
            color: white;
        }

        .price-details {
            background: rgba(25, 135, 84, 0.1);
            padding: 1.5rem;
            border-radius: 10px;
        }

        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.875rem;
        }

        .booking-progress {
            margin-bottom: 2rem;
        }

        .btn-lg {
            padding: 1rem 2.5rem;
            font-size: 1.1rem;
            border-radius: 10px;
            min-width: 200px;
        }

        .btn-outline-danger {
            border-width: 2px;
        }

        .btn-outline-danger:hover {
            background-color: #dc3545;
            color: white;
            transform: translateY(-2px);
        }

        .btn-success {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            border: none;
        }

        .btn-success:hover {
            background: linear-gradient(135deg, #218838 0%, #1e7e34 100%);
            transform: translateY(-2px);
        }

        .gap-3 {
            gap: 1rem;
        }

        .additional-services {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }

        .form-check-label {
            width: 100%;
            cursor: pointer;
        }

        .service-item {
            padding: 8px;
            border-radius: 4px;
            background-color: white;
            margin-bottom: 4px;
        }
    </style>

    <script>
        function setStatus(status) {
            document.getElementById('transaction_status').value = status;
        }
        document.addEventListener("DOMContentLoaded", function() {
            const navigationLinks = document.querySelectorAll("a[data-navigate]");

            navigationLinks.forEach(link => {
                link.addEventListener("click", function(event) {
                    event.preventDefault();
                    const targetUrl = link.getAttribute("data-navigate");
                    const userConfirmed = confirm(
                        "Are you sure you want to leave this page? Unsaved changes will be lost."
                    );
                    if (userConfirmed) {
                        window.location.href = targetUrl;
                    }
                });
            });
        });
        document.addEventListener("DOMContentLoaded", function() {
            const logoutLink = document.getElementById("logout-link");

            if (logoutLink) {
                logoutLink.addEventListener("click", function(event) {
                    event.preventDefault();
                    const userConfirmed = confirm("Are you sure you want to logout?");
                    if (userConfirmed) {
                        window.location.href = logoutLink.href;
                    }
                });
            }
        });

        function confirmCancel() {
            if (confirm('Are you sure you want to cancel this booking? This action cannot be undone.')) {
                document.getElementById('booking_action').value = 'cancel';
                window.location.href = 'booking_izzy.php?id=' + document.querySelector('input[name="room_id_izzy"]').value;
                return false;
            }
            return false;
        }
    </script>

    <?php require('inc/footer_izzy.php'); ?>
</body>

</html>