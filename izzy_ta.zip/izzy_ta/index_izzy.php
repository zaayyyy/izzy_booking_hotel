<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php require('inc/links_izzy.php'); ?>
    <link rel="stylesheet" href="htttps://unpkg.com/swiper07/swiper-bundle.min.css">
    <style>
        .availibility-form {
            margin-top: -50px;
            z-index: 2;
            position: relative;
        }

        @media screen and (max-width: 575px) {
            .availibility-form {
                margin-top: 0px;
                padding: 0 35px;
            }
        }
    </style>
</head>

<body class="bg-light">
    <?php require('inc/header_izzy.php');
    ?>

    <!-- swiper -->
    <div class="continer-fluid">
        <div class="swiper swiper-container">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <img src="images/carousel/1.png" class="w-100 d-blok" />
                </div>
                <div class="swiper-slide">
                    <img src="images/carousel/2.png" class="w-100 d-blok" />
                </div>
                <div class="swiper-slide">
                    <img src="images/carousel/3.png" class="w-100 d-blok" />
                </div>
                <div class="swiper-slide">
                    <img src="images/carousel/4.png" class="w-100 d-blok" />
                </div>
                <div class="swiper-slide">
                    <img src="images/carousel/5.png" class="w-100 d-blok" />
                </div>
                <div class="swiper-slide">
                    <img src="images/carousel/6.png" class="w-100 d-blok" />
                </div>
            </div>
        </div>
    </div>

    <!-- Booking -->
    <div class="container availibility-form">
        <div class="row">
            <div class="col-lg-12 bg-white shadow p-4 rounded">
                <h5 class="mb-4">Check Booking Availability</h5>
                <form action="rooms_izzy.php" method="GET">
                    <div class="row align-items-end">
                        <div class="col-lg-3 mb-3">
                            <label class="form-label" style="font-weight: 500;">Check-in : 14:00 PM</label>
                            <input type="date" name="check_in" class="form-control shadow-none" required>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <label class="form-label" style="font-weight: 500;">Check-out : 12:00 PM</label>
                            <input type="date" name="check_out" class="form-control shadow-none" required>
                        </div>
                        <div class="col-lg-3 mb-3">
                            <label class="form-label" style="font-weight: 500;">Person</label>
                            <select name="person_count" class="form-select shadow-none">
                                <option value="" disabled selected>Select person count</option>
                                <option value="1">1 Person</option>
                                <option value="2">2 Persons</option>
                                <option value="3">3 Persons</option>
                                <option value="4">4 Persons</option>
                                <option value="5">5 Persons</option>
                            </select>
                        </div>
                        <div class="col-lg-1 mb-lg-3 mt-2">
                            <button type="submit" class="btn text-white shadow-none custom-bg">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- our rooms -->
    <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font">OUR ROOMS</h2>
    <div class="container">
        <div class="row">
            <?php
            $IzzyUserLoggedIn = isset($_SESSION['id_user_izzy']);
            $IzzyQuery = "SELECT 
                r.id_room_izzy, 
                r.name_izzy, 
                r.guest_capacity_izzy, 
                r.price_izzy, 
                r.room_status_izzy, 
                t.type_izzy
            FROM rooms_izzy r
            INNER JOIN room_type_izzy t ON r.id_type_izzy = t.id_type_izzy
            ";
            $IzzyResult = mysqli_query($con, $IzzyQuery);
            if (mysqli_num_rows($IzzyResult) == 0) {
                echo "<p class='text-center'>Room Not Found.</p>";
            } else {
                while ($IzzyRow = mysqli_fetch_assoc($IzzyResult)) { ?>
                    <div class=" col-lg-4 col-md-6 my-3">
                        <div class="card border-0 shadow" style="max-width: 350px; margin: auto;">
                            <img src="images/rooms/1.jpg" class="card-img-top">
                            <div class="card-body">
                                <h5><?php echo $IzzyRow['name_izzy']; ?></h5>
                                <h6 class="mb-4">$<?php echo $IzzyRow['price_izzy']; ?> per night</h6>
                                <div class="features mb-4">
                                    <h6 class="mb-1">Room Type</h6>
                                    <span class="badge rounded-pill bg-light text-dark mb-3 text-wrap lh-base">
                                        <?php echo $IzzyRow['type_izzy']; ?>
                                    </span>
                                </div>
                                <div class="guest mb-4">
                                    <h6 class="mb-1">Guest</h6>
                                    <span class="badge rounded-pill bg-light text-dark mb-3 text-wrap lh-base">
                                        <?php echo $IzzyRow['guest_capacity_izzy']; ?> Guests
                                    </span>
                                </div>
                                <?php if($IzzyRow['room_status_izzy'] == 'clean'): ?>
                                    <div class="alert alert-info mb-3">
                                        <i class="bi bi-info-circle me-2"></i>
                                        This room is currently under cleaning maintenance
                                    </div>
                                <?php endif; ?>
                                <div class="d-flex justify-content-evenly mb-2">
                                    <?php if (isset($_SESSION['user_id_izzy'])): ?>
                                        <a href="booking_izzy.php?id=<?php echo $IzzyRow['id_room_izzy']; ?>"
                                            class="btn btn-sm text-white custom-bg shadow-none ">Book Now</a>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-sm text-white custom-bg shadow-none book-now-btn"
                                            data-room-id="<?php echo $IzzyRow['id_room_izzy']; ?>">Book Now</button>
                                    <?php endif; ?>
                                    <a href="room_detail_izzy.php?id=<?php echo $IzzyRow['id_room_izzy']; ?>"
                                        class="btn btn-sm btn-outline-dark shadow-none">More Details</a>
                                </div>

                            </div>
                        </div>
                    </div>
            <?php }
            } ?>
            <div class="col-lg-12 text-center mt-5">
                <a href="rooms_izzy.php" class="btn btn-sm btn-outline-dark rounded-0 fw-bold shadow-none">More
                    Rooms>>></a>
            </div>
        </div>
    </div>

    <!-- Facilities -->
    <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font">OUR FACILITIES</h2>
    <div class="container">
        <div class="row justify-content-evenly px-lg-0 px-md-0 px-5">
            <?php
            $IzzyFacilitiesQuery = "SELECT * FROM facilities_izzy ORDER BY id_izzy LIMIT 5";
            $IzzyFacilitiesResult = mysqli_query($con, $IzzyFacilitiesQuery);

            if (mysqli_num_rows($IzzyFacilitiesResult) > 0) {
                while ($IzzyFacility = mysqli_fetch_assoc($IzzyFacilitiesResult)) {
                    $image_path = !empty($IzzyFacility['image_izzy']) ? 'images/facilities/' . $IzzyFacility['image_izzy'] : 'images/facilities/wifi.svg';
            ?>
                    <div class="col-lg-2 col-md-2 text-center bg-white rounded shadow py-4 my-3"
                        style="height: 200px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
                        <img src="<?php echo $image_path; ?>" width="80px" height="80px" style="object-fit: contain;"
                            alt="<?php echo $IzzyFacility['name_izzy']; ?>">
                        <h5 class="mt-3"><?php echo $IzzyFacility['name_izzy']; ?></h5>
                    </div>
            <?php
                }
            } else {
                echo '<div class="col-12 text-center"><p>No facilities found!</p></div>';
            }
            ?>
            <div class="col-lg-12 text-center mt-5">
                <a href="facilities_izzy.php" class="btn btn-sm btn-outline-dark rounded-0 fw-bold shadow-none">More
                    Facilities>>></a>
            </div>
        </div>
    </div>

    <!-- Testimonials -->
    <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font">TESTIMONIALS</h2>
    <div class="container mb-5">
        <div class="swiper swiper-testimonials">
            <div class="swiper-wrapper mt-5">

                <div class="swiper-slide bg-white p-4">
                    <div class="profile d-flex align-items-center mb-3">
                        <img src="images/features/star.cvg" width="30px">
                        <h6 class="m-0 mb-2">Pasha Afghani Sidampoy</h6>
                    </div>
                    <p>
                        Menu breakfastnya enak, pelayanannya ramah, dan tempatnya bersih. Sangat
                        direkomendasikan untuk menginap di hotel ini. Kamar yang luas dan nyaman.⭐
                    </p>
                    <div class="rating">
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                    </div>
                </div>
                <div class="swiper-slide bg-white p-4">
                    <div class="profile d-flex align-items-center mb-3">
                        <img src="images/features/star.cvg" width="30px">
                        <h6 class="m-0 mb-2">Aqell Razza Haffiz</h6>
                    </div>
                    <p>
                        Hotel ini memiliki fasilitas yang sangat baik. Kolam renangnya bersih dan nyaman.
                        Pelayanan dari stafnya juga sangat memuaskan. Sangat direkomendasikan untuk menginap di hotel ini.
                    </p>
                    <div class="rating">
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                    </div>
                </div>
                <div class="swiper-slide bg-white p-4">
                    <div class="profile d-flex align-items-center mb-3">
                        <img src="images/features/star.cvg" width="30px">
                        <h6 class="m-0 mb-2">Amellya Nugraha</h6>
                    </div>
                    <p>
                        Kamar yang saya tempati sangat bersih dan nyaman. Pelayanan dari stafnya juga sangat baik.
                        Saya merasa sangat puas menginap di hotel ini. Sangat direkomendasikan untuk menginap di hotel ini.
                    </p>
                    <div class="rating">
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                    </div>
                </div>
            </div>
            <div class="swiper-pagination"></div>
        </div>
        <div class="col-lg-12 text-center mt-5">
            <a href="" class="btn btn-sm btn-outline-dark rounded-0 fw-bold shadow-none">Know More>>></a>
        </div>
    </div>

    <!-- Reach us -->
    <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font">REACH US</h2>
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 p-4 mb-lg-0 mb-3 bg-white rounded">
                <iframe class="w-100" height="320px"
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d126755.95286184853!2d107.53859397141112!3d-6.875800267703981!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e68e4732a4213a1%3A0x477ac5214225cf2c!2sSMK%20Negeri%202%20Cimahi!5e0!3m2!1sid!2sid!4v1739451301248!5m2!1sid!2sid"
                    loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
            <div class="col-lg-4 col-md-4">
                <div class="bg-white p-4 rounded mb-4">
                    <h5>Call us</h5>
                    <a href="tel: +620971879592" class="d-inline-block mb-2 text-decoration-none text-dark"><i
                            class="bi bi-telephone-fill"></i>+620971879592
                    </a>

                </div>
                <div class="bg-white p-4 rounded mb-4">
                    <h5>Follow us</h5>
                    <a href="tel: +62091011091" class="d-inline-block mb-3">
                        <span class="badge bg-light text-dark fs-6 ps-2">
                            <i class="bi bi-twitter-x me-1"></i>Twitter
                        </span>
                    </a>
                    <br>
                    <a href="tel: +62091011091" class="d-inline-block mb-3">
                        <span class="badge bg-light text-dark fs-6 ps-2">
                            <i class="bi bi-facebook me-1"></i>Facebook
                        </span>
                    </a>
                    <br>
                    <a href="tel: +62091011091" class="d-inline-block">
                        <span class="badge bg-light text-dark fs-6 ps-2">
                            <i class="bi bi-instagram me-1"></i>Instagram
                        </span>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <?php require('inc/footer_izzy.php'); ?>

    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const checkInInput = document.querySelector("input[name='check_in']");
            const checkOutInput = document.querySelector("input[name='check_out']");

            // Set the minimum date for check-in to today
            const today = new Date().toISOString().split("T")[0];
            checkInInput.setAttribute("min", today);

            // Disable check-out until check-in is selected
            checkOutInput.disabled = true;

            // Update the minimum date for check-out based on check-in
            checkInInput.addEventListener("change", function () {
                const checkInDate = checkInInput.value;
                checkOutInput.disabled = false;
                checkOutInput.setAttribute("min", new Date(new Date(checkInDate).getTime() + 86400000).toISOString().split("T")[0]); // +1 day
                checkOutInput.value = ""; // Clear check-out if it doesn't meet the new condition
            });
        });

        document.addEventListener("DOMContentLoaded", function() {
            var bookNowButtons = document.querySelectorAll('.book-now-btn');
            bookNowButtons.forEach(function(btn) {
                btn.addEventListener('click', function() {
                    var loginModal = new bootstrap.Modal(document.getElementById('login'));
                    loginModal.show();
                });
            });
        });

        var swiper = new Swiper(".swiper-container", {
            spaceBetween: 30,
            effect: "fade",
            loop: true,
            autoplay: {
                delay: 3500,
                disableOnInteraction: false,
            }
        });

        var swiper = new Swiper(".swiper-testimonials", {
            effect: "coverflow",
            grabCursor: true,
            centeredSlides: true,
            slidesPerView: "auto",
            slidesPerView: "3",
            loop: true,
            coverflowEffect: {
                rotate: 50,
                stretch: 0,
                depth: 100,
                modifier: 1,
                slideShadows: false,
            },
            pagination: {
                el: ".swiper-pagination",
            },
            breakpoints: {
                320: {
                    slidesPerView: 1,
                },
                640: {
                    slidesPerView: 1,
                },
                768: {
                    slidesPerView: 2,
                },
                1024: {
                    slidesPerView: 3,
                },
            }
        });
        document.addEventListener("DOMContentLoaded", function() {
            const logoutLink = document.getElementById("logout-link");

            if (logoutLink) {
                logoutLink.addEventListener("click", function(event) {
                    event.preventDefault(); // Mencegah navigasi langsung
                    const userConfirmed = confirm("Are you sure you want to logout?");
                    if (userConfirmed) {
                        window.location.href = logoutLink.href; // Navigasi ke halaman logout
                    }
                });
            }
        });
    </script>
</body>

</html>