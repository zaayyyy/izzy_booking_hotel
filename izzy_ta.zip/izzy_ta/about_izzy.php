<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <?php require('inc/links_izzy.php'); ?>
    <style>
        .box {
            border-top-color: var(--teal) !important;
        }
    </style>
</head>

<body class="bg-light">

    <?php require('inc/header_izzy.php'); ?>

    <div class="my-5 px-4">
        <h2 class="fw-bold h-font text-center"> ABOUT US</h2>
        <div class="h-line bg-dark"></div>
        <p class="text-center mt-3">
            Welcome to our hotel, where comfort meets luxury. We pride ourselves on offering exceptional hospitality
            and top-notch services to <br> ensure your stay is unforgettable. With a variety of rooms, modern amenities,
            and a dedicated team, we strive to create <br> a relaxing and enjoyable experience for all our guests.
        </p>
    </div>

    <div class="container mt-5">
        <div class="row justify-content-between align-items-center">
            <div class="col-lg-6 col-md-5 mb-4 order-lg-1 order-md-1 order-2">
                <h3 class="mb-3">Izzy Sandrianna Rakhman</h3>
                <p>
                    A student of SMKN 2 Cimahi majoring in Software and Game Development (PPLG) with an interest in
                    web development and design. Possesses technical skills in HTML, PHP, Java,
                    MySQL, and Figma, as well as adaptive and communicative abilities.
                </p>
            </div>
            <div class="col-lg-5 col-md-5 mb-4 order-lg-2 order-md-2 order-1">
                <img src="images/about/izzy1.jpeg" class="w-100">

            </div>
        </div>
    </div>

    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-3 col-md-6 mb-4 px-4">
                <div class="bg-white rounded shadow p-4 border-top border-4 text-center box">
                    <img src="images/about/hotel.svg" width="70px">
                    <h4 class="mt-3"><?php 
                        $room_count = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) as count FROM rooms_izzy"))['count'];
                        echo $room_count; ?> Rooms</h4>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4 px-4">
                <div class="bg-white rounded shadow p-4 border-top border-4 text-center box">
                    <img src="images/about/customers.svg" width="70px">
                    <h4 class="mt-3"><?php 
                        $user_count = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) as count FROM user_izzy"))['count'];
                        echo $user_count; ?> Customers</h4>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4 px-4">
                <div class="bg-white rounded shadow p-4 border-top border-4 text-center box">
                    <img src="images/about/rating.svg" width="70px">
                    <h4 class="mt-3"><?php 
                        $booking_count = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) as count FROM transaction_izzy"))['count'];
                        echo $booking_count; ?> Bookings</h4>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4 px-4">
                <div class="bg-white rounded shadow p-4 border-top border-4 text-center box">
                    <img src="images/about/staff.svg" width="70px">
                    <h4 class="mt-3">24/7 Staff</h4>
                </div>
            </div>
        </div>
    </div>

    <?php require('inc/footer_izzy.php'); ?>

    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <script>
        var swiper = new Swiper(".mySwiper", {
            slidesPerView: 4,
            spaceBetween: 40,
            pagination: {
                el: ".swiper-pagination",
            },
            breakpoints: {
                320: {
                    slidesPerView: 1,
                },
                640: {
                    slidesPerView: 1,
                },
                768: {
                    slidesPerView: 2,
                },
                1024: {
                    slidesPerView: 3,
                },
            }
        });
        document.addEventListener("DOMContentLoaded", function() {
            const logoutLink = document.getElementById("logout-link");

            if (logoutLink) {
                logoutLink.addEventListener("click", function(event) {
                    event.preventDefault(); // Mencegah navigasi langsung
                    const userConfirmed = confirm("Are you sure you want to logout?");
                    if (userConfirmed) {
                        window.location.href = logoutLink.href; // Navigasi ke halaman logout
                    }
                });
            }
        });
    </script>
</body>

</html>