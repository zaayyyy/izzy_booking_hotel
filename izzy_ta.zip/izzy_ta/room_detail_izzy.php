<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">
    <?php require('inc/links_izzy.php'); ?>
    <title>Room Details - Izzy Hotel</title>
</head>
<?php
require('inc/header_izzy.php');

if (isset($_POST['login'])) {
    $email = $_POST['email_izzy'];
    $password = $_POST['password_izzy'];

    $query = "SELECT * FROM users_izzy WHERE email_izzy = ? AND password_izzy = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param("ss", $email, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        $_SESSION['user_id_izzy'] = $user['id_user_izzy'];

        if (!empty($_POST['id_room_izzy'])) {
            $_SESSION['id_room_izzy'] = $_POST['id_room_izzy'];
        }

        if (isset($_SESSION['id_room_izzy'])) {
            header("Location: " . $_SERVER['PHP_SELF'] . $_SESSION['id_room_izzy']);
        } else {
            header("Location: index.php");
        }
        exit();
    } else {
        echo "<script>alert('Login Failed! Check your email and password.');</script>";
    }
}


if (isset($_GET['id'])) {
    $_SESSION['id_room_izzy'] = $_GET['id'];
}

if (!isset($_GET['id']) && isset($_SESSION['id_room_izzy'])) {
    $_GET['id'] = $_SESSION['id_room_izzy'];
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("<h3 class='text-center text-danger'>Invalid Room ID.</h3>");
}

$id_room_izzy = intval($_GET['id']);
$today = date('Y-m-d');

$IzzyQuery = "SELECT 
                r.id_room_izzy, 
                r.name_izzy, 
                r.guest_capacity_izzy, 
                r.price_izzy, 
                r.room_status_izzy, 
                t.type_izzy, 
                (
                    SELECT GROUP_CONCAT(CONCAT(checkin_izzy, ' to ', checkout_izzy) SEPARATOR '; ')
                    FROM transaction_izzy
                    WHERE id_room_izzy = r.id_room_izzy 
                    AND status_izzy = 'completed'
                    AND checkout_izzy >= ?  
                ) AS booked_dates
              FROM rooms_izzy r
              INNER JOIN room_type_izzy t ON r.id_type_izzy = t.id_type_izzy
              WHERE r.id_room_izzy = ?";

$stmt = $con->prepare($IzzyQuery);
$stmt->bind_param("si", $today, $id_room_izzy);
$stmt->execute();
$result = $stmt->get_result();
$room = $result->fetch_assoc();

if (!$room) {
    die("<h3 class='text-center text-danger'>Room Not Found.</h3>");
}
?>

<body class="bg-light">
    <div class="modal fade" id="login" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="">
                    <div class="modal-header">
                        <h5 class="modal-title d-flex align-items-center">
                            <i class="bi bi-person fs-3 me-2"></i>
                            User Login
                        </h5>
                        <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Email address</label>
                            <input type="email" class="form-control shadow-none" name="email_izzy" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" class="form-control shadow-none" name="login_password" required>
                        </div>
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <button type="submit" name="login" class="btn btn-dark shadow-none">LOGIN</button>
                            <a href="javascript:void(0)" class="text-secondary text-decoration-none">Forget
                                Password?</a>
                        </div>
                        <input type="hidden" name="id_room_izzy" value="<?php echo $_GET['id_room_izzy'] ?? ''; ?>">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="my-5 px-4">
        <h2 class="fw-bold h-font text-center">ROOM DETAILS</h2>
        <div class="h-line bg-dark"></div>
    </div>

    <div class="container">
        <div class="row">
            <div class="card mb-4 border-0 shadow">
                <div class="row g-0 p-3 align-items-center">
                    <div class="col-md-5 mb-lg-0 mb-md-0 mb-3">
                        <img src="images/rooms/<?php echo isset($room['image_field']) ? $room['image_field'] : '1.jpg'; ?>"
                            class="img-fluid rounded-start" alt="Room Image">
                    </div>
                    <div class="col-md-5 px-lg-3 px-md-3 px-0">
                        <h5><?php echo $room['name_izzy']; ?></h5>
                        <div class="features mb-3">
                            <h6 class="mb-1">Room Type</h6>
                            <span class="badge rounded-pill bg-light text-dark mb-3 text-wrap lh-base">
                                <?php echo $room['type_izzy']; ?>
                            </span>
                        </div>
                        <div class="guest mb-3">
                            <h6 class="mb-1">Guest</h6>
                            <span class="badge rounded-pill bg-light text-dark mb-3 text-wrap lh-base">
                                <?php echo $room['guest_capacity_izzy']; ?> Guests
                            </span>
                        </div>
                        <div class="booked-dates mb-3">
                            <h6 class="mb-1">Booked Dates</h6>
                            <div class="bg-light p-2 rounded">
                                <?php
                                if (!empty($room['booked_dates'])) {
                                    $dates = explode(';', $room['booked_dates']);
                                    foreach ($dates as $date) {
                                        echo '<span class="badge bg-warning text-dark mb-1 me-1">' . trim($date) . '</span>';
                                    }
                                } else {
                                    echo '<span class="badge bg-success text-white">All dates available</span>';
                                }
                                ?>
                            </div>
                        </div>
                        <div class="status">
                            <h6 class="mb-1">Status</h6>
                            <span class="badge rounded-pill bg-light text-dark mb-3 text-wrap lh-base">
                                <?php echo $room['room_status_izzy']; ?>
                            </span>
                        </div>
                    </div>
                    <div class="col-md-2 mt-lg-0 mt-md-0 mt-4 text-center">
                        <h6 class="mb-4">$<?php echo $room['price_izzy']; ?> per night</h6>
                        <?php if(isset($_SESSION['user_id_izzy'])): ?>
                        <a href="booking_izzy.php?id=<?php echo $room['id_room_izzy']; ?>&check_in=<?php echo $_GET['check_in'] ?? '' ?>&check_out=<?php echo $_GET['check_out'] ?? '' ?> "
                            class="btn btn-sm w-100 text-white custom-bg shadow-none mb-2">Book Now</a>
                        <?php else: ?>
                        <button type="button"
                            class="btn btn-sm w-100 text-white custom-bg shadow-none mb-2 book-now-btn"
                            data-room-id="<?php echo $room['id_room_izzy']; ?>">Book Now</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        var bookNowButtons = document.querySelectorAll('.book-now-btn');
        bookNowButtons.forEach(function(btn) {
            btn.addEventListener('click', function() {
                var loginModal = new bootstrap.Modal(document.getElementById('login'));
                loginModal.show();
            });
        });
    });
    document.addEventListener("DOMContentLoaded", function() {
        const logoutLink = document.getElementById("logout-link");

        if (logoutLink) {
            logoutLink.addEventListener("click", function(event) {
                event.preventDefault(); 
                const userConfirmed = confirm("Are you sure you want to logout?");
                if (userConfirmed) {
                    window.location.href = logoutLink.href;
                }
            });
        }
    });
    </script>

    <?php require('inc/footer_izzy.php'); ?>

</body>

</html>