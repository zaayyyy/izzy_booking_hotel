<?php

    function adminLogin() {
        if (!isset($_SESSION)) {
            session_start();
        }
        if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
            session_destroy();
            header("Location: index_admin_izzy.php");
            exit;
        }
    }

    function redirect($url) {
        header("Location: $url");
        exit;
    }

    function preventBack() {
        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
    }

    function alert($type,$msg){

        $bs_class = ($type == "success") ? "alert-success" : "alert-danger";
        
    echo <<<alert
    <div class="alert $bs_class alert-dismissible fade show custom-alert" role="alert">
        <strong class="me-3">$msg!</strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    alert;
    }
?>