<!-- Required Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    const toggleBtn = document.querySelector('.toggle-sidebar');
    
    // Initialize from localStorage
    const isCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
    
    if (isCollapsed) {
        sidebar.classList.add('collapsed');
        if (mainContent) mainContent.classList.add('expanded');
        if (toggleBtn) toggleBtn.classList.add('collapsed');
    }

    // Handle window resize
    const handleResize = () => {
        if (window.innerWidth <= 768) {
            sidebar.classList.add('collapsed');
            if (mainContent) mainContent.classList.add('expanded');
            if (toggleBtn) toggleBtn.classList.add('collapsed');
        } else if (!isCollapsed) {
            sidebar.classList.remove('collapsed');
            if (mainContent) mainContent.classList.remove('expanded');
            if (toggleBtn) toggleBtn.classList.remove('collapsed');
        }
    };

    window.addEventListener('resize', handleResize);
    handleResize();
});

function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    const toggleBtn = document.querySelector('.toggle-sidebar');
    
    sidebar.classList.toggle('collapsed');
    if (mainContent) mainContent.classList.toggle('expanded');
    if (toggleBtn) toggleBtn.classList.toggle('collapsed');

    localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
}
</script>

<style>
.toggle-sidebar {
    position: fixed;
    left: 250px;
    top: 20px;
    background: var(--primary-color);
    color: white;
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    z-index: 1001;
    box-shadow: 0 2px 6px rgba(0,0,0,0.15);
}

.toggle-sidebar:hover {
    transform: scale(1.1);
}

.toggle-sidebar.collapsed {
    left: 70px;
}

@media (max-width: 768px) {
    .toggle-sidebar {
        left: 70px;
    }
}
</style>