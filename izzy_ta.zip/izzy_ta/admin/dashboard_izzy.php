<?php
require('../inc/koneksi_db_izzy.php');
require('inc/essentials_izzy.php');
session_start();
adminLogin();
preventBack();

if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    session_destroy();
    header("Location: index_admin_izzy.php");
    exit;
}

// Get statistics from database
$room_count = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) as count FROM rooms_izzy"))['count'];
$user_count = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) as count FROM user_izzy"))['count'];
$booking_count = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) as count FROM transaction_izzy"))['count'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <?php require('inc/links_izzy.php') ?>
    <style>
    :root {
        --primary-color: #4e73df;
        --secondary-color: #858796;
        --success-color: #1cc88a;
    }

    .sidebar {
        height: 100vh;
        width: 250px;
        position: fixed;
        top: 0;
        left: 0;
        background: linear-gradient(180deg, var(--primary-color) 0%, #224abe 100%);
        padding-top: 20px;
        transition: all 0.3s ease;
        z-index: 1000;
    }

    .sidebar.collapsed {
        width: 70px;
    }

    .sidebar a {
        color: rgba(255, 255, 255, 0.8);
        transition: all 0.3s;
    }

    .sidebar a:hover {
        background-color: rgba(255, 255, 255, 0.1);
        color: #ffffff;
    }

    .main-content {
        margin-left: 250px;
        padding: 20px;
        transition: all 0.3s ease;
    }

    .main-content.expanded {
        margin-left: 70px;
    }

    .card {
        border: none;
        border-radius: 10px;
        box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        transition: all 0.3s ease;
    }

    .card:hover {
        transform: translateY(-2px);
        box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.25);
    }

    .toggle-sidebar {
        position: fixed;
        left: 250px;
        top: 20px;
        background: var(--primary-color);
        color: white;
        border: none;
        border-radius: 50%;
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s ease;
        z-index: 1001;
    }

    .toggle-sidebar.collapsed {
        left: 70px;
    }

    .dashboard-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-top: 20px;
    }

    .stat-card {
        background: white;
        padding: 20px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .stat-card i {
        font-size: 2rem;
        opacity: 0.7;
    }

    .welcome-section {
        background: linear-gradient(45deg, var(--primary-color), #224abe);
        color: white;
        padding: 30px;
        border-radius: 10px;
        margin-bottom: 20px;
    }
    </style>
</head>

<body class="bg-light">
    <?php require('sidebar_admin_izzy.php') ?>

    <div class="main-content">
        <div class="container-fluid">
            <div class="welcome-section">
                <h3 class="mb-2">Welcome to Admin Dashboard</h3>
                <p class="mb-0">Manage your hotel system efficiently</p>
            </div>

            <div class="dashboard-stats">
                <div class="stat-card">
                    <div>
                        <h4>Rooms</h4>
                        <h2><?= $room_count ?></h2>
                    </div>
                    <i class="bi bi-house-door text-primary"></i>
                </div>
                <div class="stat-card">
                    <div>
                        <h4>Users</h4>
                        <h2><?= $user_count ?></h2>
                    </div>
                    <i class="bi bi-people text-success"></i>
                </div>
                <div class="stat-card">
                    <div>
                        <h4>Bookings</h4>
                        <h2><?= $booking_count ?></h2>
                    </div>
                    <i class="bi bi-calendar2-check text-warning"></i>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col-12">
                    <h4 class="mb-4">Quick Actions</h4>
                    <div class="d-flex gap-4">
                        <a href="rooms/manage_rooms_izzy.php" class="btn btn-primary">Manage Rooms</a>
                        <a href="user/manage_users_izzy.php" class="btn btn-primary">Manage Users</a>
                        <a href="facilities/manage_facilities_izzy.php" class="btn btn-primary">View Facilities</a>
                        <a href="transaction/manage_transactions_izzy.php" class="btn btn-primary">View Bookings</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php require('inc/script_izzy.php') ?>
</body>

</html>