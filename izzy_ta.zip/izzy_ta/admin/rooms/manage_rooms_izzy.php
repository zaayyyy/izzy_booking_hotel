<?php
require('../../inc/koneksi_db_izzy.php');
require('../inc/essentials_izzy.php');

$search = $_GET['search'] ?? '';
$type_filter = $_GET['type'] ?? '';
$status_filter = $_GET['status'] ?? '';

// Modify the query to include reschedule counts
$query = "SELECT r.*, t.type_izzy,
          (SELECT COUNT(*) FROM transaction_izzy tr 
           WHERE tr.id_room_izzy = r.id_room_izzy 
           AND tr.reschedule_status_izzy = 'requested') as reschedule_requests,
          (SELECT COUNT(*) FROM transaction_izzy tr 
           WHERE tr.id_room_izzy = r.id_room_izzy 
           AND tr.reschedule_status_izzy = 'rescheduled') as approved_reschedules  
          FROM rooms_izzy r
          INNER JOIN room_type_izzy t ON r.id_type_izzy = t.id_type_izzy 
          WHERE 1=1";

if (!empty($search)) {
    $query .= " AND (r.name_izzy LIKE '%$search%')";
}
if (!empty($type_filter)) {
    $query .= " AND r.id_type_izzy = '$type_filter'";
}
if (!empty($status_filter)) {
    $query .= " AND r.room_status_izzy = '$status_filter'";
}

$result = $con->query($query);

// Handle delete room
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['delete_room'])) {
        $id = $_POST['room_id'];
        $query = "DELETE FROM rooms_izzy WHERE id_room_izzy = ?";
        $stmt = $con->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        header('Location: manage_rooms_izzy.php?success=delete');
        exit;
    }
}

// Handle update room
if (isset($_POST['update_room'])) {
    $id = $_POST['id_room_izzy'];
    $name = $_POST['name_izzy'];
    $capacity = $_POST['guest_capacity_izzy'];
    $price = $_POST['price_izzy'];
    $type = $_POST['type_izzy'];
    $status = $_POST['room_status_izzy'];

    $typeQuery = "SELECT id_type_izzy FROM room_type_izzy WHERE id_type_izzy = ?";
    $typeStmt = $con->prepare($typeQuery);
    $typeStmt->bind_param('i', $type);
    $typeStmt->execute();
    $typeStmt->store_result();

    if ($typeStmt->num_rows > 0) {
        $query = "UPDATE rooms_izzy SET
                    name_izzy = ?,
                    guest_capacity_izzy = ?,
                    price_izzy = ?,
                    id_type_izzy = ?,
                    room_status_izzy = ?
                  WHERE id_room_izzy = ?";
        $stmt = $con->prepare($query);
        $stmt->bind_param('siiisi', $name, $capacity, $price, $type, $status, $id);

        if ($stmt->execute()) {
            header('Location: manage_rooms_izzy.php?success=update');
            exit;
        } else {
            header('Location: manage_rooms_izzy.php?error=update');
            exit;
        }
    } else {
        header('Location: manage_rooms_izzy.php?error=invalid_type');
        exit;
    }
}

// Handle add room
if (isset($_POST['add_room'])) {
    $name = $_POST['name_izzy'];
    $capacity = $_POST['guest_capacity_izzy'];
    $price = $_POST['price_izzy'];
    $type = $_POST['type_izzy'];
    $status = 'Available';

    $typeQuery = "SELECT id_type_izzy FROM room_type_izzy WHERE id_type_izzy = ?";
    $typeStmt = $con->prepare($typeQuery);
    $typeStmt->bind_param('i', $type);
    $typeStmt->execute();
    $typeStmt->store_result();

    if ($typeStmt->num_rows > 0) {
        $query = "INSERT INTO rooms_izzy (name_izzy, guest_capacity_izzy, price_izzy, id_type_izzy, room_status_izzy) VALUES (?, ?, ?, ?, ?)";
        $stmt = $con->prepare($query);
        $stmt->bind_param('sidis', $name, $capacity, $price, $type, $status);

        if ($stmt->execute()) {
            header('Location: manage_rooms_izzy.php?success=add');
            exit;
        } else {
            header('Location: manage_rooms_izzy.php?error=add');
            exit;
        }
    } else {
        header('Location: manage_rooms_izzy.php?error=invalid_type');
        exit;
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Rooms</title>
    <?php require('../inc/links_izzy.php') ?>
    <style>
        .room-card {
            transition: transform 0.2s;
        }

        .room-card:hover {
            transform: translateY(-5px);
        }

        .room-status {
            position: absolute;
            top: 10px;
            right: 10px;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }

        .status-available {
            background: rgba(28, 200, 138, 0.1);
            color: var(--success-color);
        }

        .status-booked {
            background: rgba(231, 74, 59, 0.1);
            color: var(--danger-color);
        }

        .status-clean {
            background: rgba(78, 115, 223, 0.1);
            color: var(--primary-color);
        }

        .room-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            padding: 20px;
        }

        .add-room-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(45deg, var(--primary-color), #224abe);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .add-room-btn:hover {
            transform: scale(1.1);
            color: white;
        }

        .room-info {
            padding: 15px;
        }

        .room-type {
            font-size: 0.9rem;
            color: var(--secondary-color);
            margin-bottom: 10px;
        }

        .room-price {
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--primary-color);
        }

        .room-capacity {
            font-size: 0.9rem;
            color: var(--secondary-color);
        }

        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }

        /* Enhanced Animations */
        .room-card {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            animation: fadeIn 0.5s ease-out;
        }

        .room-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.12);
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal.fade .modal-dialog {
            transform: scale(0.95);
            transition: transform 0.3s ease-out;
        }

        .modal.show .modal-dialog {
            transform: scale(1);
        }

        .btn {
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .btn:active {
            transform: scale(0.95);
        }

        .add-room-btn {
            animation: float 3s ease-in-out infinite;
        }

        @keyframes float {
            0% {
                transform: translateY(0px);
            }
            50% {
                transform: translateY(-10px);
            }
            100% {
                transform: translateY(0px);
            }
        }

        .room-status {
            animation: slideIn 0.3s ease-out;
        }

        @keyframes slideIn {
            from {
                transform: translateX(20px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        .action-buttons button {
            transition: all 0.2s ease;
        }

        .action-buttons button:hover {
            transform: translateY(-2px);
        }

        .form-control,
        .form-select {
            transition: all 0.2s ease;
        }

        .form-control:focus,
        .form-select:focus {
            transform: translateY(-1px);
        }

        .alert {
            animation: slideDown 0.3s ease-out;
        }

        @keyframes slideDown {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .toggle-sidebar {
            position: fixed;
            top: 20px;
            left: 20px;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .toggle-sidebar:hover {
            transform: scale(1.1);
        }
    </style>
</head>

<body class="bg-light">

    <?php require('../sidebar_admin_izzy.php') ?>
    <div class="main-content">
        <div class="container-fluid mt-5">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3>Manage Rooms</h3>
            </div>

            <div class="filter-section bg-white p-4 rounded shadow-sm mb-4">
                <form method="GET" class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Search Room</label>
                        <input type="text" name="search" class="form-control" placeholder="Search by name..." 
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Room Type</label>
                        <select name="type" class="form-select">
                            <option value="">All Types</option>
                            <?php 
                            $types = $con->query("SELECT * FROM room_type_izzy");
                            while($type = $types->fetch_assoc()):
                            ?>
                            <option value="<?= $type['id_type_izzy'] ?>" 
                                <?= ($type_filter == $type['id_type_izzy']) ? 'selected' : '' ?>>
                                <?= $type['type_izzy'] ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="">All Status</option>
                            <option value="Available" <?= ($status_filter == 'Available') ? 'selected' : '' ?>>Available</option>
                            <option value="Booked" <?= ($status_filter == 'Booked') ? 'selected' : '' ?>>Booked</option>
                            <option value="Clean" <?= ($status_filter == 'Clean') ? 'selected' : '' ?>>Clean</option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-search me-1"></i> Search
                        </button>
                    </div>
                </form>
            </div>

            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <?php if(mysqli_num_rows($result) == 0): ?>
                        <div class="text-center py-5">
                            <h4 class="text-muted">No Rooms Data Available</h4>
                            <p class="text-muted">There are currently no rooms to display.</p>
                        </div>
                    <?php else: ?>
                        <div class="room-grid">
                            <?php while ($row = $result->fetch_assoc()) : ?>
                                <div class="card room-card">
                                    <div class="position-relative">
                                        <img src="../../images/rooms/1.jpg" class="card-img-top" alt="Room Image" style="height: 200px; object-fit: cover;">
                                        <span class="room-status status-<?= strtolower($row['room_status_izzy']) ?>">
                                            <?= ucfirst($row['room_status_izzy']) ?>
                                        </span>
                                    </div>
                                    <div class="room-info">
                                        <h5 class="card-title mb-1"><?= $row['name_izzy'] ?></h5>
                                        <div class="room-type"><?= $row['type_izzy'] ?></div>
                                        <div class="room-price">$<?= number_format($row['price_izzy'], 2) ?></div>
                                        <div class="room-capacity">
                                            <i class="bi bi-people"></i> <?= $row['guest_capacity_izzy'] ?> Guests
                                        </div>
                                        <div class="action-buttons">
                                            
                                            <button type="button" class="btn btn-sm btn-warning edit-btn"
                                                data-id="<?= $row['id_room_izzy'] ?>"
                                                data-name="<?= htmlspecialchars($row['name_izzy']) ?>"
                                                data-capacity="<?= htmlspecialchars($row['guest_capacity_izzy']) ?>"
                                                data-price="<?= htmlspecialchars($row['price_izzy']) ?>"
                                                data-type="<?= htmlspecialchars($row['id_type_izzy']) ?>"
                                                data-status="<?= htmlspecialchars($row['room_status_izzy']) ?>"
                                                data-bs-toggle="modal" data-bs-target="#editRoomModal">
                                                <i class="bi bi-pencil-square"></i> Edit
                                            </button>
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="room_id" value="<?= $row['id_room_izzy'] ?>">
                                                <button type="submit" name="delete_room" class="btn btn-sm btn-danger"
                                                    onclick="return confirm('Are you sure you want to delete this room?');">
                                                    <i class="bi bi-trash"></i> Delete
                                                </button>
                                            </form>
                                        </div>
                                        <div class="mt-2">
                                            <a href="../transaction/manage_transactions_izzy.php?room=<?= $row['name_izzy'] ?>" 
                                               class="btn btn-sm btn-info">
                                               <i class="bi bi-calendar-check"></i> View Reschedules
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <a href="#" class="add-room-btn" data-bs-toggle="modal" data-bs-target="#addRoomModal">
                <i class="bi bi-plus-lg"></i>
            </a>
        </div>
    </div>

    <!-- Edit Modal -->
    <div class="modal fade" id="editRoomModal" data-bs-backdrop="static" data-bs-keyboard="true" tabindex="-1"
        aria-labelledby="editRoomModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <form method="POST" action="">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editRoomModalLabel">
                            <i class="bi bi-pencil-square me-2"></i>Edit Room
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body p-4">
                        <input type="hidden" name="id_room_izzy" id="edit-id">
                        <div class="row g-3">
                            <div class="col-12">
                                <div class="form-floating">
                                    <input type="text" name="name_izzy" id="edit-name" class="form-control" required>
                                    <label>Room Name</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="number" name="guest_capacity_izzy" id="edit-capacity" class="form-control" required>
                                    <label>Guest Capacity</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="number" name="price_izzy" id="edit-price" class="form-control" required>
                                    <label>Price per Night</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <select name="type_izzy" id="edit-type" class="form-select" required>
                                        <?php
                                        $typeQuery = "SELECT * FROM room_type_izzy";
                                        $types = $con->query($typeQuery);
                                        while ($type = $types->fetch_assoc()) :
                                        ?>
                                            <option value="<?= $type['id_type_izzy'] ?>"><?= $type['type_izzy'] ?></option>
                                        <?php endwhile; ?>
                                    </select>
                                    <label>Room Type</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <select name="room_status_izzy" id="edit-status" class="form-select" required>
                                        <option value="Available">Available</option>
                                        <option value="Booked">Booked</option>
                                        <option value="Clean">Clean</option>
                                    </select>
                                    <label>Room Status</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="bi bi-x-lg me-1"></i>Cancel
                        </button>
                        <button type="submit" name="update_room" class="btn btn-primary">
                            <i class="bi bi-save me-1"></i>Save Changes
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Add Modal -->
    <div class="modal fade" id="addRoomModal" data-bs-backdrop="static" data-bs-keyboard="true" tabindex="-1"
        aria-labelledby="addRoomModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <form method="POST" action="">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addRoomModalLabel">
                            <i class="bi bi-plus-lg me-2"></i>Add New Room
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body p-4">
                        <div class="row g-3">
                            <div class="col-12">
                                <div class="form-floating">
                                    <input type="text" name="name_izzy" class="form-control" required>
                                    <label>Room Name</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="number" name="guest_capacity_izzy" class="form-control" required>
                                    <label>Guest Capacity</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="number" name="price_izzy" class="form-control" required>
                                    <label>Price per Night</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <select name="type_izzy" class="form-select" required>
                                        <?php
                                        $typeQuery = "SELECT * FROM room_type_izzy";
                                        $types = $con->query($typeQuery);
                                        while ($type = $types->fetch_assoc()) :
                                        ?>
                                            <option value="<?= $type['id_type_izzy'] ?>"><?= $type['type_izzy'] ?></option>
                                        <?php endwhile; ?>
                                    </select>
                                    <label>Room Type</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="bi bi-x-lg me-1"></i>Cancel
                        </button>
                        <button type="submit" name="add_room" class="btn btn-primary">
                            <i class="bi bi-plus-lg me-1"></i>Add Room
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php require('../inc/script_izzy.php') ?>
    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('collapsed');
        }

        document.addEventListener('DOMContentLoaded', function() {
            const editButtons = document.querySelectorAll('.edit-btn');
            const modal = document.querySelector('#editRoomModal');
            const idInput = modal.querySelector('#edit-id');
            const nameInput = modal.querySelector('#edit-name');
            const capacityInput = modal.querySelector('#edit-capacity');
            const priceInput = modal.querySelector('#edit-price');
            const typeInput = modal.querySelector('#edit-type');
            const statusInput = modal.querySelector('#edit-status');

            editButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const id = this.getAttribute('data-id');
                    const name = this.getAttribute('data-name');
                    const capacity = this.getAttribute('data-capacity');
                    const price = this.getAttribute('data-price');
                    const type = this.getAttribute('data-type');
                    const status = this.getAttribute('data-status');

                    // Set basic input values
                    idInput.value = id;
                    nameInput.value = name;
                    capacityInput.value = capacity;
                    priceInput.value = price;

                    // Set room type dropdown
                    Array.from(typeInput.options).forEach(option => {
                        option.selected = option.value === type;
                    });

                    // Set status dropdown
                    Array.from(statusInput.options).forEach(option => {
                        option.selected = option.value === status;
                    });
                });
            });

            // Add success message handling
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('success')) {
                const action = urlParams.get('success');
                let message = '';
                switch(action) {
                    case 'add':
                        message = 'Room added successfully!';
                        break;
                    case 'update':
                        message = 'Room updated successfully!';
                        break;
                    case 'delete':
                        message = 'Room deleted successfully!';
                        break;
                }
                if (message) {
                    const alert = document.createElement('div');
                    alert.className = 'alert alert-success alert-dismissible fade show';
                    alert.innerHTML = `
                        ${message}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    `;
                    document.querySelector('.container-fluid').insertBefore(alert, document.querySelector('.room-grid'));
                    
                    // Auto-dismiss alert after 3 seconds
                    setTimeout(() => {
                        const bsAlert = new bootstrap.Alert(alert);
                        bsAlert.close();
                    }, 3000);
                }
            }
        });
    </script>
</body>

</html>