<?php
$base_url = $_SERVER['DOCUMENT_ROOT'] . '/izzy_ta/admin/';
?>

<div class="sidebar" id="sidebar">
    <h4 class="text-white text-center mb-4">Admin Panel</h4>
    <div class="d-flex flex-column">
        <div class="nav flex-column">
            <a href="/izzy_ta/admin/dashboard_izzy.php" class="nav-link text-white">
                <i class="bi bi-speedometer2 me-2"></i>
                <span class="nav-text">Dashboard</span>
            </a>
            <a href="/izzy_ta/admin/rooms/manage_rooms_izzy.php" class="nav-link text-white">
                <i class="bi bi-house-door me-2"></i>
                <span class="nav-text">Rooms</span>
            </a>
            <a href="/izzy_ta/admin/user/manage_users_izzy.php" class="nav-link text-white">
                <i class="bi bi-people me-2"></i>
                <span class="nav-text">Users</span>
            </a>
            <a href="/izzy_ta/admin/facility/manage_facilities_izzy.php" class="nav-link text-white">
                <i class="bi bi-grid me-2"></i>
                <span class="nav-text">Facilities</span>
            </a>
            <a href="/izzy_ta/admin/transaction/manage_transactions_izzy.php" class="nav-link text-white">
                <i class="bi bi-currency-dollar me-2"></i>
                <span class="nav-text">Transactions</span>
            </a>
            <a href="/izzy_ta/admin/daily_report_izzy.php" class="nav-link text-white">
                <i class="bi bi-currency-dollar me-2"></i>
                <span class="nav-text">Daily Report</span>
            </a>
            <div class="mt-auto">
                <a href="/izzy_ta/admin/logout_izzy.php" class="nav-link text-white" id="logout-link-admin">
                    <i class="bi bi-box-arrow-right me-2"></i>
                    <span class="nav-text">Logout</span>
                </a>
            </div>
        </div>
    </div>
</div>

<style>
.sidebar {
    height: 100vh;
    width: 250px;
    position: fixed;
    top: 0;
    left: 0;
    background: linear-gradient(180deg, var(--primary-color) 0%, #224abe 100%);
    padding-top: 20px;
    transition: all 0.3s ease;
    z-index: 1000;
}

.nav-link {
    color: rgba(255, 255, 255, 0.8) !important;
    border-radius: 8px;
    margin: 2px 10px;
    transition: all 0.2s;
}

.nav-link:hover,
.nav-link.active {
    background: rgba(255, 255, 255, 0.1);
    color: white !important;
    transform: translateX(5px);
}

.sidebar.collapsed {
    width: 70px;
}

.sidebar.collapsed .nav-text,
.sidebar.collapsed .small {
    display: none;
}

.sidebar.collapsed .nav-link {
    text-align: center;
    padding: 0.5rem !important;
}

.sidebar.collapsed .nav-link i {
    margin: 0 !important;
    font-size: 1.2rem;
}

@media (max-width: 768px) {
    .sidebar {
        width: 70px;
    }

    .nav-text,
    .small {
        display: none;
    }

    .nav-link {
        text-align: center;
        padding: 0.5rem !important;
    }

    .nav-link i {
        margin: 0 !important;
        font-size: 1.2rem;
    }
}
</style>
<script>
document.addEventListener("DOMContentLoaded", function() {
    const logoutLink = document.getElementById("logout-link-admin");

    if (logoutLink) {
        logoutLink.addEventListener("click", function(event) {
            event.preventDefault();
            if (confirm("Are you sure you want to logout?")) {
                window.location.href = this.href;
            }
        });
    }
});
</script>