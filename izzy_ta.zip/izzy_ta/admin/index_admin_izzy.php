<?php
require('../inc/koneksi_db_izzy.php');
session_start();
require('inc/essentials_izzy.php');

if(isset($_SESSION['adminLogin']) && $_SESSION['adminLogin'] == true){
    header("Location: dashboard_izzy.php");
    exit;
}

if(isset($_POST['login'])){
    $frm_data = filteration($_POST);
    $query = "SELECT * FROM admin_izzy Where username_admin_izzy=? AND password_admin_izzy = ?";
    $values = [$frm_data['admin_name'],$frm_data['admin_pass']];
    
    $res = select($query,$values,"ss");
    if ($res->num_rows==1){
        $row = mysqli_fetch_assoc($res);
        session_regenerate_id(true);
        $_SESSION['adminLogin'] = true;
        $_SESSION['adminId'] = $row['id_admin_izzy'];
        header("Location: dashboard_izzy.php");
        exit;
    }
    else{
        $login_error = "Login failed - Invalid Invalid Username or Password";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <?php require('inc/links_izzy.php'); ?>
    <style>
    div.login-form {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 400px;
    }

    .login-container {
        min-height: 100vh;
        background: linear-gradient(45deg, var(--primary-color), #224abe);
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .login-card {
        width: 400px;
        padding: 3rem;
        background: white;
        border-radius: 15px;
        box-shadow: 0 0 40px rgba(0, 0, 0, 0.1);
        animation: slideUp 0.5s ease-out;
    }

    @keyframes slideUp {
        from {
            transform: translateY(20px);
            opacity: 0;
        }

        to {
            transform: translateY(0);
            opacity: 1;
        }
    }

    .login-header {
        text-align: center;
        margin-bottom: 2rem;
    }

    .login-header i {
        font-size: 3rem;
        color: var(--primary-color);
        margin-bottom: 1rem;
    }

    .login-header h2 {
        color: var(--primary-color);
        font-weight: 600;
        margin: 0;
    }

    .form-floating {
        margin-bottom: 1rem;
    }

    .form-floating input {
        border-radius: 8px;
        border: 1px solid #e3e6f0;
    }

    .login-btn {
        width: 100%;
        padding: 0.8rem;
        font-size: 1.1rem;
        border-radius: 8px;
        background: linear-gradient(45deg, var(--primary-color), #224abe);
        border: none;
        color: white;
        font-weight: 500;
        margin-top: 1rem;
        transition: transform 0.2s;
    }

    .login-btn:hover {
        transform: translateY(-2px);
    }

    .alert {
        animation: shake 0.5s ease-in-out;
    }

    @keyframes shake {

        0%,
        100% {
            transform: translateX(0);
        }

        25% {
            transform: translateX(-10px);
        }

        75% {
            transform: translateX(10px);
        }
    }
    </style>
</head>

<body class="bg-light">
    <div class="login-container">
        <div class="login-card">
            <?php 
            if(isset($login_error)){
                echo "<div class='alert alert-danger'>$login_error</div>";
            }
            ?>
            <div class="login-header">
                <i class="bi bi-person-circle"></i>
                <h2>Admin Login</h2>
            </div>

            <form method="POST">
                <div class="form-floating">
                    <input name="admin_name" type="text" class="form-control" id="username" placeholder="Username"
                        required>
                    <label for="username">Username</label>
                </div>
                <div class="form-floating">
                    <input name="admin_pass" type="password" class="form-control" id="password" placeholder="Password"
                        required>
                    <label for="password">Password</label>
                </div>
                <button type="submit" class="login-btn" name="login">
                    Login <i class="bi bi-box-arrow-in-right ms-2"></i>
                </button>
            </form>
        </div>
    </div>
    <?php require('inc/script_izzy.php'); ?>
</body>

</html>