<?php
require('../../inc/koneksi_db_izzy.php');
require('../inc/essentials_izzy.php');

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


// Check if not logged in
if(!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location: ../../admin/index_admin_izzy.php");
    exit;
}
// Add adminLogin() for verification
adminLogin();

// Add search functionality
$search = $_GET['search'] ?? '';
$query = "SELECT * FROM facilities_izzy WHERE 1=1";
if (!empty($search)) {
    $query .= " AND (name_izzy LIKE '%$search%' OR description_izzy LIKE '%$search%')";
}
$result = mysqli_query($con, $query);

// Create facilities directory if it doesn't exist
$upload_dir = "images/facilities";
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// Modify the getImagePath function
function getImagePath($imageName) {
    return !empty($imageName) ? 'images/facilities/' . $imageName : '../../images/facilities/ac.svg';
}

// Handle add facility
if (isset($_POST['add_facility'])) {
    $name = $_POST['name_izzy'];
    $description = $_POST['description_izzy'];
    
    // Image validation
    $allowed = array('gif', 'png', 'jpg', 'jpeg');
    $filename = $_FILES['image_izzy']['name'];
    $ext = pathinfo($filename, PATHINFO_EXTENSION);
    
    if (!in_array($ext, $allowed)) {
        header('Location: manage_facilities_izzy.php?error=invalid_image');
        exit;
    }

    // Generate unique filename
    $image = 'FAC_' . time() . '.' . $ext;
    $target = $upload_dir . "/" . $image;

    $query = "INSERT INTO facilities_izzy (name_izzy, description_izzy, image_izzy) VALUES (?, ?, ?)";
    $stmt = $con->prepare($query);
    $stmt->bind_param('sss', $name, $description, $image);

    if ($stmt->execute() && move_uploaded_file($_FILES['image_izzy']['tmp_name'], $target)) {
        header('Location: manage_facilities_izzy.php?success=add');
        exit;
    } else {
        header('Location: manage_facilities_izzy.php?error=add');
        exit;
    }
}

// Handle update facility
if (isset($_POST['update_facility'])) {
    $id = $_POST['id_izzy'];
    $name = $_POST['name_izzy'];
    $description = $_POST['description_izzy'];
    
    if (!empty($_FILES['image_izzy']['name'])) {
        // Image validation
        $allowed = array('gif', 'png', 'jpg', 'jpeg');
        $filename = $_FILES['image_izzy']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        
        if (!in_array($ext, $allowed)) {
            header('Location: manage_facilities_izzy.php?error=invalid_image');
            exit;
        }

        // Delete old image
        $old_image = "SELECT image_izzy FROM facilities_izzy WHERE id_izzy = ?";
        $stmt = $con->prepare($old_image);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $old_img = $result->fetch_assoc()['image_izzy'];
        if ($old_img && file_exists($upload_dir.'/'.$old_img)) {
            unlink($upload_dir.'/'.$old_img);
        }

        // Upload new image
        $image = 'FAC_' . time() . '.' . $ext;
        $target = $upload_dir . "/" . $image;

        $query = "UPDATE facilities_izzy SET name_izzy = ?, description_izzy = ?, image_izzy = ? WHERE id_izzy = ?";
        $stmt = $con->prepare($query);
        $stmt->bind_param('sssi', $name, $description, $image, $id);
        
        if ($stmt->execute() && move_uploaded_file($_FILES['image_izzy']['tmp_name'], $target)) {
            header('Location: manage_facilities_izzy.php?success=update');
        } else {
            header('Location: manage_facilities_izzy.php?error=update');
        }
    } else {
        $query = "UPDATE facilities_izzy SET name_izzy = ?, description_izzy = ? WHERE id_izzy = ?";
        $stmt = $con->prepare($query);
        $stmt->bind_param('ssi', $name, $description, $id);
        
        if ($stmt->execute()) {
            header('Location: manage_facilities_izzy.php?success=update');
        } else {
            header('Location: manage_facilities_izzy.php?error=update');
        }
    }
    exit;
}

// Handle delete facility
if (isset($_POST['delete_facility'])) {
    $id = $_POST['facility_id'];
    
    // Delete image file first
    $query = "SELECT image_izzy FROM facilities_izzy WHERE id_izzy = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $image = $result->fetch_assoc()['image_izzy'];
    
    if ($image && file_exists($upload_dir.'/'.$image)) {
        unlink($upload_dir.'/'.$image);
    }

    // Delete database record
    $query = "DELETE FROM facilities_izzy WHERE id_izzy = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param('i', $id);
    
    if ($stmt->execute()) {
        header('Location: manage_facilities_izzy.php?success=delete');
    } else {
        header('Location: manage_facilities_izzy.php?error=delete');
    }
    exit;
}

// Fetch facilities data
$query = "SELECT id_izzy, name_izzy, description_izzy, image_izzy FROM facilities_izzy";
$result = $con->query($query);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Facilities</title>
    <?php require('../inc/links_izzy.php') ?>
    <style>
        .facility-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            padding: 20px;
        }

        .facility-card {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            animation: fadeIn 0.5s ease-out;
        }

        .facility-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.12);
        }

        .facility-card .card-img-wrapper {
            height: 200px;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f8f9fa;
        }

        .facility-card .card-img-top {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 10px;
        }

        .facility-info {
            padding: 15px;
        }

        .facility-description {
            font-size: 0.9rem;
            color: var(--secondary-color);
            margin-bottom: 15px;
            display: -webkit-box;
            overflow: hidden;
        }

        .add-facility-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(45deg, var(--primary-color), #224abe);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .add-facility-btn:hover {
            transform: scale(1.1);
            color: white;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>

<body class="bg-light">

    <?php require('../sidebar_admin_izzy.php') ?>
    <div class="main-content">
        <div class="container-fluid mt-5">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3>Manage Facilities</h3>
            </div>

            <div class="filter-section bg-white p-4 rounded shadow-sm mb-4">
                <form method="GET" class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Search Facility</label>
                        <input type="text" name="search" class="form-control" placeholder="Search by name or description..." 
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-search me-1"></i> Search
                        </button>
                    </div>
                </form>
            </div>

            <div class="facility-grid">
                <?php 
                $query = "SELECT * FROM facilities_izzy";
                $result = mysqli_query($con, $query);

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $image_path = getImagePath($row['image_izzy']);
                ?>
                    <div class="card facility-card">
                        <div class="card-img-wrapper">
                            <img src="<?= $image_path ?>" 
                                class="card-img-top" 
                                alt="<?= htmlspecialchars($row['name_izzy']) ?>">
                        </div>
                        <div class="facility-info">
                            <h5 class="card-title mb-2"><?= $row['name_izzy'] ?></h5>
                            <div class="facility-description"><?= $row['description_izzy'] ?></div>
                            <div class="d-flex gap-2">
                                <button type="button" class="btn btn-sm btn-warning edit-btn"
                                    data-id="<?= $row['id_izzy'] ?>"
                                    data-name="<?= htmlspecialchars($row['name_izzy']) ?>"
                                    data-description="<?= htmlspecialchars($row['description_izzy']) ?>"
                                    data-image="<?= htmlspecialchars($row['image_izzy']) ?>"
                                    data-bs-toggle="modal" 
                                    data-bs-target="#editFacilityModal">
                                    <i class="bi bi-pencil-square"></i> Edit
                                </button>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="facility_id" value="<?= $row['id_izzy'] ?>">
                                    <button type="submit" name="delete_facility" class="btn btn-sm btn-danger"
                                        onclick="return confirm('Are you sure you want to delete this facility?');">
                                        <i class="bi bi-trash"></i> Delete
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php 
                    }
                } else {
                    echo '<div class="col-12 text-center"><p>No facilities found!</p></div>';
                }
                ?>
            </div>

            <a href="#" class="add-facility-btn" data-bs-toggle="modal" data-bs-target="#addFacilityModal">
                <i class="bi bi-plus-lg"></i>
            </a>
        </div>
    </div>

    <!-- Add Modal -->
    <div class="modal fade" id="addFacilityModal" data-bs-backdrop="static" data-bs-keyboard="true" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Add New Facility</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body p-4">
                        <div class="row g-3">
                            <div class="col-12">
                                <div class="form-floating">
                                    <input type="text" name="name_izzy" class="form-control" required>
                                    <label>Facility Name</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <textarea name="description_izzy" class="form-control" style="height: 100px" required></textarea>
                                    <label>Description</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-bold">Image</label>
                                <input type="file" name="image_izzy" accept=".jpg,.png,.jpeg,.gif" class="form-control shadow-none" required>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="add_facility" class="btn btn-primary">Add Facility</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Modal -->
    <div class="modal fade" id="editFacilityModal" data-bs-backdrop="static" data-bs-keyboard="true" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Facility</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body p-4">
                        <div class="row g-3">
                            <div class="col-12">
                                <input type="hidden" name="id_izzy" id="edit-id">
                                <div class="form-floating">
                                    <input type="text" name="name_izzy" id="edit-name" class="form-control" required>
                                    <label>Facility Name</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <textarea name="description_izzy" id="edit-description" class="form-control" style="height: 100px" required></textarea>
                                    <label>Description</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-bold">Current Image</label>
                                <div id="current-image" class="mb-2"></div>
                                <label class="form-label fw-bold">Change Image</label>
                                <input type="file" name="image_izzy" accept=".jpg,.png,.jpeg,.gif" class="form-control shadow-none">
                                <small class="text-muted">Leave empty to keep current image</small>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="update_facility" class="btn btn-primary">Save Changes</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php require('../inc/script_izzy.php') ?>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const editButtons = document.querySelectorAll('.edit-btn');
        const modal = document.querySelector('#editFacilityModal');
        const idInput = modal.querySelector('#edit-id');
        const nameInput = modal.querySelector('#edit-name');
        const descriptionInput = modal.querySelector('#edit-description');
        const currentImageDiv = modal.querySelector('#current-image');

        editButtons.forEach(button => {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const name = this.getAttribute('data-name');
                const description = this.getAttribute('data-description');
                const image = this.getAttribute('data-image');

                idInput.value = id;
                nameInput.value = name;
                descriptionInput.value = description;
                
                if (currentImageDiv && image) {
                    currentImageDiv.innerHTML = `<img src="images/facilities/${image}" class="img-fluid mb-2" style="max-height: 200px;">`;
                }
            });
        });

        // Auto-dismiss alerts after 3 seconds
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            setTimeout(() => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }, 3000);
        });
    });
    </script>
</body>

</html>