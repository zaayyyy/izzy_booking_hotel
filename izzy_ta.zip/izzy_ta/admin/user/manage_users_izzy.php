<?php
require('../../inc/koneksi_db_izzy.php');
require('../inc/essentials_izzy.php');
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if not logged in
if(!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location: ../../admin/index_admin_izzy.php");
    exit;
}
// Add adminLogin() for verification
adminLogin();


$search = $_GET['search'] ?? '';
$date_filter = $_GET['date'] ?? '';

$selected_columns = $_GET['columns'] ?? ['id', 'name', 'email', 'phone', 'password', 'pincode', 'address', 'created'];

function is_checked($value, $array) {
    return in_array($value, $array) ? 'checked' : '';
}

$query = "SELECT * FROM user_izzy WHERE 1=1";

if (!empty($search)) {
    $query .= " AND (name_izzy LIKE '%$search%' OR email_izzy LIKE '%$search%' OR phone_izzy LIKE '%$search%')";
}
if (!empty($date_filter)) {
    $query .= " AND DATE(created_at) = '$date_filter'";
}

$result = $con->query($query);

// Handle form submission for updating user
if (isset($_POST['update_user'])) {
    $id = $_POST['id_izzy'];
    $name = $_POST['name_izzy'];
    $email = $_POST['email_izzy'];
    $password = $_POST['password_izzy'];
    $pincode = $_POST['pincode_izzy'];
    $address = $_POST['address_izzy'];

    $query = "UPDATE user_izzy SET
                name_izzy = ?,
                email_izzy = ?,
                password_izzy = ?,
                pincode_izzy = ?,
                address_izzy = ?
              WHERE id_izzy = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param('sssssi', $name, $email, $password, $pincode, $address, $id);

    if ($stmt->execute()) {
        header('Location: manage_users_izzy.php?success=1');
        exit;
    } else {
        echo '<div class="alert alert-danger">Failed to update user.</div>';
    }
}

// Handle delete user action
if (isset($_GET['delete']) && isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "DELETE FROM user_izzy WHERE id_izzy = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param('i', $id);

    if ($stmt->execute()) {
        header('Location: manage_users_izzy.php?delete_success=1');
        exit;
    } else {
        echo '<div class="alert alert-danger">Failed to delete user.</div>';
    }
}

// Update handler for account activation
if (isset($_POST['activate_user'])) {
    $id = $_POST['user_id'];
    $status = $_POST['status'];
    $action = ($status == 'active') ? 'activated' : (($status == 'inactive') ? 'deactivated' : 'reactivated');
    
    $query = "UPDATE user_izzy SET status_izzy = ? WHERE id_izzy = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param('si', $status, $id);
    
    if ($stmt->execute()) {
        header("Location: manage_users_izzy.php?status_update=1&action=$action");
        exit;
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <?php require('../inc/links_izzy.php') ?>
</head>

<body class="bg-light">

    <?php require('../sidebar_admin_izzy.php') ?><div class="main-content">
        <div class="container mt-5">
            <h3 class="mb-4">Manage Users</h3>

            <!-- Display success message -->
            <?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                User updated successfully.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <!-- Display delete success message -->
            <?php if (isset($_GET['delete_success']) && $_GET['delete_success'] == 1): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                User deleted successfully.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <!-- Display status update message -->
            <?php if (isset($_GET['status_update']) && $_GET['status_update'] == 1): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                User account has been <?= htmlspecialchars($_GET['action']) ?> successfully.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <div class="filter-section bg-white p-4 rounded shadow-sm mb-4">
                <form method="GET" class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Search User</label>
                        <input type="text" name="search" class="form-control"
                            placeholder="Search by name, email or phone..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Registration Date</label>
                        <input type="date" name="date" class="form-control"
                            value="<?= htmlspecialchars($date_filter) ?>">
                    </div>
                    <div class="col-md-4 d-flex align-items-end gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-search me-1"></i> Search
                        </button>
                        <button type="button" class="btn btn-info text-white" data-bs-toggle="modal"
                            data-bs-target="#columnsModal">
                            <i class="bi bi-funnel me-1"></i> Filter Columns
                        </button>
                    </div>
                </form>
            </div>

            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <table class="table table-bordered" id="userTable">
                        <thead>
                            <tr>
                                <?php if (in_array('id', $selected_columns)) echo '<th>ID</th>'; ?>
                                <?php if (in_array('name', $selected_columns)) echo '<th>Name</th>'; ?>
                                <?php if (in_array('email', $selected_columns)) echo '<th>Email</th>'; ?>
                                <?php if (in_array('phone', $selected_columns)) echo '<th>Phone</th>'; ?>
                                <?php if (in_array('password', $selected_columns)) echo '<th>Password</th>'; ?>
                                <?php if (in_array('pincode', $selected_columns)) echo '<th>Pincode</th>'; ?>
                                <?php if (in_array('address', $selected_columns)) echo '<th>Address</th>'; ?>
                                <?php if (in_array('created', $selected_columns)) echo '<th>Created At</th>'; ?>
                                <th class="action-column">Actions</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $result->fetch_assoc()) : ?>
                            <tr>
                                <?php if (in_array('id', $selected_columns)) echo '<td>' . $row['id_izzy'] . '</td>'; ?>
                                <?php if (in_array('name', $selected_columns)) echo '<td>' . $row['name_izzy'] . '</td>'; ?>
                                <?php if (in_array('email', $selected_columns)) echo '<td>' . $row['email_izzy'] . '</td>'; ?>
                                <?php if (in_array('phone', $selected_columns)) echo '<td>' . $row['phone_izzy'] . '</td>'; ?>
                                <?php if (in_array('password', $selected_columns)) echo '<td>' . $row['password_izzy'] . '</td>'; ?>
                                <?php if (in_array('pincode', $selected_columns)) echo '<td>' . $row['pincode_izzy'] . '</td>'; ?>
                                <?php if (in_array('address', $selected_columns)) echo '<td>' . $row['address_izzy'] . '</td>'; ?>
                                <?php if (in_array('created', $selected_columns)) echo '<td>' . $row['created_at'] . '</td>'; ?>
                                <td>
                                    <button type="button" class="btn btn-sm btn-warning edit-btn"
                                        data-id="<?= $row['id_izzy'] ?>"
                                        data-name="<?= htmlspecialchars($row['name_izzy']) ?>"
                                        data-email="<?= htmlspecialchars($row['email_izzy']) ?>"
                                        data-number="<?= htmlspecialchars($row['phone_izzy']) ?>"
                                        data-password="<?= htmlspecialchars($row['password_izzy']) ?>"
                                        data-pincode="<?= htmlspecialchars($row['pincode_izzy']) ?>"
                                        data-address="<?= htmlspecialchars($row['address_izzy']) ?>"
                                        data-bs-toggle="modal" data-bs-target="#editUserModal">
                                        Edit
                                    </button>
                                    <a href="manage_users_izzy.php?delete=1&id=<?= $row['id_izzy'] ?>"
                                        class="btn btn-sm btn-danger"
                                        onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                                </td>
                                <td>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="user_id" value="<?= $row['id_izzy'] ?>">
                                        <?php if ($row['status_izzy'] == 'pending'): ?>
                                            <input type="hidden" name="status" value="active">
                                            <button type="submit" name="activate_user" class="btn btn-sm btn-success">
                                                Activate
                                            </button>
                                        <?php elseif ($row['status_izzy'] == 'active'): ?>
                                            <input type="hidden" name="status" value="inactive">
                                            <button type="submit" name="activate_user" class="btn btn-sm btn-danger">
                                                Deactivate
                                            </button>
                                        <?php else: ?>
                                            <input type="hidden" name="status" value="active">
                                            <button type="submit" name="activate_user" class="btn btn-sm btn-warning">
                                                Reactivate
                                            </button>
                                        <?php endif; ?>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>

                    <!-- Add Print Button -->
                    <div class="mt-3">
                        <button type="button" class="btn btn-primary" onclick="printTable()">Print PDF</button>
                    </div>
                </div>
            </div>

            <!-- Add Columns Filter Modal -->
            <div class="modal fade" id="columnsModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-scrollable">
                    <div class="modal-content">
                        <form method="GET">
                            <div class="modal-header">
                                <h5 class="modal-title">Choose Columns</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="search" value="<?= htmlspecialchars($search) ?>">
                                <input type="hidden" name="date" value="<?= htmlspecialchars($date_filter) ?>">

                                <?php
                                $columns = [
                                    'id' => 'ID',
                                    'name' => 'Name',
                                    'email' => 'Email',
                                    'phone' => 'Phone',
                                    'password' => 'Password',
                                    'pincode' => 'Pincode',
                                    'address' => 'Address',
                                    'created' => 'Created At'
                                ];
                                foreach ($columns as $key => $label) {
                                    echo "<div class='form-check'>
                                            <input class='form-check-input' type='checkbox' name='columns[]' 
                                                   value='$key' ". is_checked($key, $selected_columns) .">
                                            <label class='form-check-label'>$label</label>
                                          </div>";
                                }
                                ?>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Apply</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Edit Modal -->
            <div class="modal fade" id="editUserModal" data-bs-backdrop="static" data-bs-keyboard="true" tabindex="-1">
                <div class="modal-dialog modal-dialog-centered">
                    <form method="POST" action="">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">
                                    <i class="bi bi-pencil-square me-2"></i>Edit User
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body p-4">
                                <div class="row g-3">
                                    <input type="hidden" name="id_izzy" id="edit-id">
                                    <div class="col-md-6">
                                        <div class="form-floating">
                                            <input type="text" name="name_izzy" id="edit-name"
                                                class="form-control shadow-none" required>
                                            <label>Full Name</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-floating">
                                            <input type="email" name="email_izzy" id="edit-email"
                                                class="form-control shadow-none" required>
                                            <label>Email</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-floating">
                                            <input type="text" name="phone_izzy" id="edit-number"
                                                class="form-control shadow-none" required>
                                            <label>Phone Number</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-floating">
                                            <input type="text" name="pincode_izzy" id="edit-pincode"
                                                class="form-control shadow-none" required>
                                            <label>Pincode</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-floating">
                                            <textarea name="address_izzy" id="edit-address"
                                                class="form-control shadow-none" style="height: 100px"
                                                required></textarea>
                                            <label>Address</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-floating">
                                            <input type="password" name="password_izzy" id="edit-password"
                                                class="form-control shadow-none">
                                            <label>New Password (leave empty to keep current)</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                    <i class="bi bi-x-lg me-1"></i>Cancel
                                </button>
                                <button type="submit" name="update_user" class="btn btn-primary">
                                    <i class="bi bi-save me-1"></i>Save Changes
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php require('../inc/script_izzy.php') ?>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const editButtons = document.querySelectorAll('.edit-btn');
        const modal = document.querySelector('#editUserModal');
        const idInput = modal.querySelector('#edit-id');
        const nameInput = modal.querySelector('#edit-name');
        const emailInput = modal.querySelector('#edit-email');
        const numberInput = modal.querySelector('#edit-number');
        const passwordInput = modal.querySelector('#edit-password');
        const pincodeInput = modal.querySelector('#edit-pincode');
        const addressInput = modal.querySelector('#edit-address');

        editButtons.forEach(button => {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const name = this.getAttribute('data-name');
                const email = this.getAttribute('data-email');
                const number = this.getAttribute('data-number');
                const password = this.getAttribute('data-password');
                const pincode = this.getAttribute('data-pincode');
                const address = this.getAttribute('data-address');

                idInput.value = id;
                nameInput.value = name;
                emailInput.value = email;
                numberInput.value = number;
                passwordInput.value = password;
                pincodeInput.value = pincode;
                addressInput.value = address;
            });
        });
    });

    function printTable() {
        // Hide action column
        const actionColumns = document.querySelectorAll('.action-column');
        actionColumns.forEach(column => column.style.display = 'none');

        // Get table HTML
        const table = document.querySelector('#userTable').outerHTML;

        // Create print window
        const printWindow = window.open('', '', 'width=800,height=600');
        printWindow.document.write(`
                <html>
                <head>
                    <title>Print Users</title>
                    <style>
                        table { width: 100%; border-collapse: collapse; }
                        table, th, td { border: 1px solid black; }
                        th, td { padding: 8px; text-align: left; }
                    </style>
                </head>
                <body>
                    <h3>Manage Users</h3>
                    ${table}
                </body>
                </html>
            `);

        printWindow.document.close();
        printWindow.print();
        printWindow.close();

        // Show action column again
        actionColumns.forEach(column => column.style.display = '');
    }
    </script>
</body>

</html>