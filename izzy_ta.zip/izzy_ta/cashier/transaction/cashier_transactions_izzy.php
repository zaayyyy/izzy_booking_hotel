<?php
require('../inc/essentials_izzy.php');
require('../..//inc/koneksi_db_izzy.php');
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if not logged in
if(!isset($_SESSION['cashierLogin']) || $_SESSION['cashierLogin'] !== true) {
    header("Location: ../../cashier/index_cashier_izzy.php");
    exit;
}
// Add cashierLogin() for verification
cashierLogin();

$user_filter = $_GET['user'] ?? '';
$room_filter = $_GET['room'] ?? '';
$status_filter = $_GET['status'] ?? '';
$selected_columns = $_GET['columns'] ?? ['id', 'user', 'room', 'checkin', 'checkout', 'status', 'total', 'proof', 'created'];

// Fungsi helper untuk mengecek checkbox
function is_checked($value, $array)
{
    return in_array($value, $array) ? 'checked' : '';
}

// Handle delete transaction action
if (isset($_GET['delete']) && isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "DELETE FROM transaction_izzy WHERE id_transaction_izzy = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param('i', $id);

    if ($stmt->execute()) {
        header('Location: cashier_transactions_izzy.php?delete_status=success');
        exit;
    } else {
        header('Location: cashier_transactions_izzy.php?delete_status=failed');
        exit;
    }
}

// Modify the approval handling
if (isset($_GET['approve_reschedule']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Update only the dates and reschedule status, keep original status_izzy
    $update_query = "UPDATE transaction_izzy SET 
                    checkin_izzy = new_checkin_izzy,
                    checkout_izzy = new_checkout_izzy,
                    reschedule_status_izzy = 'approved'
                    WHERE id_transaction_izzy = ?";
                    
    $stmt = $con->prepare($update_query);
    $stmt->bind_param('i', $id);
    
    if ($stmt->execute()) {
        header('Location: cashier_transactions_izzy.php?reschedule_status=approved');
        exit;
    }
}

// Query dasar
$query = "SELECT t.id_transaction_izzy, 
          u.name_izzy AS user_name, r.name_izzy AS room_name,
          t.checkin_izzy, t.checkout_izzy, t.status_izzy, t.total_price_izzy,t.status_payment_izzy, 
          t.create_at, t.proof_izzy, t.reschedule_status_izzy,t.new_checkin_izzy, t.new_checkout_izzy
          FROM transaction_izzy t
          INNER JOIN user_izzy u ON t.id_izzy = u.id_izzy
          INNER JOIN rooms_izzy r ON t.id_room_izzy = r.id_room_izzy
          WHERE 1=1";

// Tambahkan filter jika ada
if (!empty($user_filter)) {
    $query .= " AND u.name_izzy LIKE '%$user_filter%'";
}
if (!empty($room_filter)) {
    $query .= " AND r.name_izzy LIKE '%$room_filter%'";
}
if (!empty($status_filter)) {
    $query .= " AND t.status_izzy = '$status_filter'";
}

$result = $con->query($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>cashier Transactions</title>
    <?php require('../inc/links_izzy.php') ?>
</head>
<style>
.filter-section {
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
    margin-bottom: 20px;
}

.filter-section .form-control,
.filter-section .form-select {
    border-radius: 8px;
    border: 1px solid #e3e6f0;
}

.filter-buttons {
    display: flex;
    gap: 10px;
}

.table-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 20px 0;
}

.status-badge {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 500;
}

.status-upcoming {
    background: rgba(78, 115, 223, 0.1);
    color: var(--primary-color);
}

.status-completed {
    background: rgba(28, 200, 138, 0.1);
    color: var(--success-color);
}

.status-canceled {
    background: rgba(231, 74, 59, 0.1);
    color: var(--danger-color);
}

.status-pending {
    background: rgba(246, 194, 62, 0.1);
    color: var(--warning-color);
}

.modal-body .form-check {
    padding: 10px;
    border-radius: 8px;
    transition: all 0.2s;
}

.modal-body .form-check:hover {
    background: rgba(78, 115, 223, 0.05);
}

.toggle-sidebar {
    position: fixed;
    top: 20px;
    left: 20px;
    background: #007bff;
    color: white;
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
}
</style>

<body class="bg-light">

    <?php require('../sidebar_cashier_izzy.php') ?>
    <div class="main-content">

        <?php if (isset($_GET['delete_status']) && $_GET['delete_status'] == 'success'): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            Transaction deleted successfully.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php elseif (isset($_GET['delete_status']) && $_GET['delete_status'] == 'failed'): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            Failed to delete the transaction.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if (isset($_GET['reschedule_status']) && $_GET['reschedule_status'] == 'approved'): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            Reschedule request approved successfully.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <div class="container mt-5">
            <h3 class="mb-4">Cashier Transactions</h3>

            <div class="filter-section">
                <form method="GET" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">User Name</label>
                        <input type="text" name="user" class="form-control" placeholder="Search by user..."
                            value="<?= htmlspecialchars($user_filter) ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Room Name</label>
                        <input type="text" name="room" class="form-control" placeholder="Search by room..."
                            value="<?= htmlspecialchars($room_filter) ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="">All Status</option>
                            <option value="upcoming" <?= $status_filter == 'upcoming' ? 'selected' : '' ?>>Upcoming
                            </option>
                            <option value="completed" <?= $status_filter == 'completed' ? 'selected' : '' ?>>Completed
                            </option>
                            <option value="canceled" <?= $status_filter == 'canceled' ? 'selected' : '' ?>>Canceled
                            </option>
                        </select>
                    </div>
                    <div class="col-md-3 d-flex align-items-end">
                        <div class="filter-buttons">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-search me-1"></i> Search
                            </button>
                            <button type="button" class="btn btn-info text-white" data-bs-toggle="modal"
                                data-bs-target="#columnsModal">
                                <i class="bi bi-funnel me-1"></i> Filter Columns
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Modal Pilih Kolom -->
            <div class="modal fade" id="columnsModal" tabindex="-1" aria-labelledby="columnsModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-scrollable">
                    <div class="modal-content">
                        <form method="GET">
                            <div class="modal-header">
                                <h5 class="modal-title">Choose Column</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="user" value="<?= htmlspecialchars($user_filter) ?>">
                                <input type="hidden" name="room" value="<?= htmlspecialchars($room_filter) ?>">
                                <input type="hidden" name="status" value="<?= htmlspecialchars($status_filter) ?>">

                                <?php
                                $columns = [
                                    'id' => 'ID',
                                    'user' => 'User',
                                    'room' => 'Room',
                                    'checkin' => 'Check-in',
                                    'checkout' => 'Check-out',
                                    'status' => 'Status',
                                    'total' => 'Total Price',
                                    'proof' => 'Payment Proof',
                                    'created' => 'Created At'
                                ];
                                foreach ($columns as $key => $label) {
                                    echo "<div class='form-check'>
                                            <input class='form-check-input' type='checkbox' name='columns[]' value='$key' ". is_checked($key, $selected_columns) .">
                                            <label class='form-check-label'>$label</label>
                                          </div>";
                                }
                                ?>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Add</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Tabel cashier Transactions -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <?php if(mysqli_num_rows($result) == 0): ?>
                    <div class="text-center py-5">
                        <h4 class="text-muted">No Transaction Data Available</h4>
                        <p class="text-muted">There are currently no transactions to display.</p>
                    </div>
                    <?php else: ?>
                    <table id="transactionTable" class="table table-bordered mt-4">
                        <thead>
                            <tr>
                                <?php if (in_array('id', $selected_columns)) echo '<th>ID</th>'; ?>
                                <?php if (in_array('user', $selected_columns)) echo '<th>User</th>'; ?>
                                <?php if (in_array('room', $selected_columns)) echo '<th>Room</th>'; ?>
                                <?php if (in_array('checkin', $selected_columns)) echo '<th>Check-in</th>'; ?>
                                <?php if (in_array('checkout', $selected_columns)) echo '<th>Check-out</th>'; ?>
                                <?php if (in_array('status', $selected_columns)) echo '<th>Status</th>'; ?>
                                <?php if (in_array('total', $selected_columns)) echo '<th>Total Price</th>'; ?>
                                <?php if (in_array('proof', $selected_columns)) echo '<th>Payment Proof</th>'; ?>
                                <?php if (in_array('created', $selected_columns)) echo '<th>Created At</th>'; ?>
                                <th>Reschedule Info</th>
                                <th class="action-column">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $result->fetch_assoc()) : ?>
                            <tr>
                                <?php if (in_array('id', $selected_columns)) echo '<td>' . $row['id_transaction_izzy'] . '</td>'; ?>
                                <?php if (in_array('user', $selected_columns)) echo '<td>' . $row['user_name'] . '</td>'; ?>
                                <?php if (in_array('room', $selected_columns)) echo '<td>' . $row['room_name'] . '</td>'; ?>
                                <?php if (in_array('checkin', $selected_columns)) echo '<td>' . $row['checkin_izzy'] .' <br> <small class="text-muted">' . '</small></td>'; ?>
                                <?php if (in_array('checkout', $selected_columns)) echo '<td>' . $row['checkout_izzy'] .' <br> <small class="text-muted">' . '</small></td>'; ?>
                                <?php if (in_array('status', $selected_columns)): ?>
                                <td>
                                    <span class="status-badge status-<?= strtolower($row['status_izzy']) ?>">
                                        <?= ucfirst($row['status_izzy']) ?>
                                    </span>
                                </td>
                                <?php endif; ?>
                                <?php if (in_array('total', $selected_columns)) echo '<td>$' . number_format($row['total_price_izzy'], 2) . '</td>'; ?>
                                <?php if (in_array('proof', $selected_columns)): ?>
                                <td>
                                    <?php if ($row['proof_izzy']): ?>
                                    <a href="../../<?= $row['proof_izzy'] ?>" target="_blank"
                                        class="btn btn-sm btn-info">
                                        View Proof
                                    </a>
                                    <?php else: ?>
                                    <span class="text-muted">No proof uploaded</span>
                                    <?php endif; ?>
                                </td>
                                <?php endif; ?>
                                <?php if (in_array('created', $selected_columns)) echo '<td><small>' . $row['create_at'] . '</small></td>'; ?>
                                <td>
                                    <?php 
                                        switch($row['reschedule_status_izzy']) {
                                            case 'requested':
                                                echo '<span class="badge bg-warning">Request: '.$row['new_checkin_izzy'].' to '.$row['new_checkout_izzy'].'</span>';
                                                echo '<div class="mt-2">';
                                                echo '<a href="?approve_reschedule=1&id='.$row['id_transaction_izzy'].'" 
                                                        class="btn btn-sm btn-success"
                                                        onclick="return confirm(\'Approve reschedule request?\')">
                                                        Approve Request
                                                    </a>';
                                                echo '</div>';
                                                break;
                                            case 'approved': 
                                                echo '<span class="badge bg-success">Reschedule approved</span>';
                                                break;
                                            default:
                                                echo '<span class="badge bg-secondary">None</span>';
                                        }
                                        ?>
                                </td>

                                <td>
                                    <a href="../accept_izzy.php?id=<?= $row['id_transaction_izzy'] ?>"
                                        class="btn btn-sm btn-success mb-1 <?= ($row['status_izzy'] == 'completed') ? 'disabled' : '' ?>"
                                        onclick="return <?= ($row['status_izzy'] != 'completed') ? 'confirm(\'Are you sure you want to accept this transaction?\')' : 'false' ?>">
                                        <i class="bi bi-check-lg"> </i>approve booking
                                    </a>
                                    <a href="../accept_payment_izzy.php?id=<?= $row['id_transaction_izzy'] ?>"
                                        class="btn btn-sm btn-warning <?= ($row['status_payment_izzy'] == 'paid') ? 'disabled' : '' ?>"
                                        onclick="return <?= ($row['status_payment_izzy'] != 'paid') ? 'confirm(\'Are you sure you want to accept this payment?\')' : 'false' ?>">
                                        <i class="bi bi-check-lg"> </i>approve payment
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <?php endif; ?>

                    <!-- Tombol Print PDF -->
                    <div class="mt-3">
                        <button type="button" class="btn btn-primary" onclick="printTable()">Print PDF</button>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <?php require('../inc/script_izzy.php') ?>
    <script>
    function setTransactionId(transactionId) {
        document.getElementById('transaction_id').value = transactionId;
    }

    function printTable() {
        // Clone the table to avoid modifying the original
        const tableClone = document.querySelector('#transactionTable').cloneNode(true);

        // Remove action column header
        const headers = tableClone.querySelectorAll('th');
        const lastHeader = headers[headers.length - 1];
        if (lastHeader.classList.contains('action-column')) {
            lastHeader.remove();
        }

        // Remove action column cells
        const rows = tableClone.querySelectorAll('tbody tr');
        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            const lastCell = cells[cells.length - 1];
            if (lastCell) {
                lastCell.remove();
            }
        });

        // Buat jendela cetak sementara
        const printWindow = window.open('', '', 'width=800,height=600');
        printWindow.document.write(`
            <html>
            <head>
                <title>Print Transactions</title>
                <style>
                    table { width: 100%; border-collapse: collapse; }
                    table, th, td { border: 1px solid black; }
                    th, td { padding: 8px; text-align: left; }
                </style>
            </head>
            <body>
                <h3>Cashier Transactions</h3>
                ${tableClone.outerHTML}
            </body>
            </html>
        `);

        printWindow.document.close();
        printWindow.print();
        printWindow.close();
    }
    </script>
</body>

</html>