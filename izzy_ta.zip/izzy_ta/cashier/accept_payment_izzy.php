<?php
require('inc/essentials_izzy.php');
cashierLogin();
require('inc/koneksi_db_izzy.php');

if (isset($_GET['id'])) {
    $transaction_id = $_GET['id'];
    
    $query = "UPDATE transaction_izzy SET status_payment_izzy='paid' WHERE id_transaction_izzy= ? ";
    $stmt = $con->prepare($query);
    $stmt->bind_param("i", $transaction_id);
    $stmt->execute();
}

header("Location: transaction/cashier_transactions_izzy.php");
exit;
?>
