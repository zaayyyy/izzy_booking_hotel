<?php
require('../inc/essentials_izzy.php');
require('../..//inc/koneksi_db_izzy.php');
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if not logged in
if(!isset($_SESSION['cashierLogin']) || $_SESSION['cashierLogin'] !== true) {
    header("Location: ../../cashier/index_cashier_izzy.php");
    exit;
}
// Add cashierLogin() for verification
cashierLogin();

$search = $_GET['search'] ?? '';
$type_filter = $_GET['type'] ?? '';
$status_filter = $_GET['status'] ?? '';

// Modify the query to include reschedule information
$query = "SELECT r.*, t.type_izzy,
          (SELECT COUNT(*) FROM transaction_izzy tr 
           WHERE tr.id_room_izzy = r.id_room_izzy 
           AND tr.reschedule_status_izzy = 'requested') as reschedule_requests,
          (SELECT COUNT(*) FROM transaction_izzy tr 
           WHERE tr.id_room_izzy = r.id_room_izzy 
           AND tr.reschedule_status_izzy = 'rescheduled') as approved_reschedules,
          (SELECT t.reschedule_status_izzy 
           FROM transaction_izzy t 
           WHERE t.id_room_izzy = r.id_room_izzy 
           ORDER BY t.id_transaction_izzy DESC 
           LIMIT 1) as reschedule_status  
          FROM rooms_izzy r
          INNER JOIN room_type_izzy t ON r.id_type_izzy = t.id_type_izzy 
          WHERE 1=1";

if (!empty($search)) {
    $query .= " AND (r.name_izzy LIKE '%$search%')";
}
if (!empty($type_filter)) {
    $query .= " AND r.id_type_izzy = '$type_filter'";
}
if (!empty($status_filter)) {
    $query .= " AND r.room_status_izzy = '$status_filter'";
}

$result = $con->query($query);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Rooms</title>
    <?php require('../inc/links_izzy.php') ?>
    <style>
    .room-card {
        transition: transform 0.2s;
    }

    .room-card:hover {
        transform: translateY(-5px);
    }

    .room-status {
        position: absolute;
        top: 10px;
        right: 10px;
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 500;
    }

    .status-available {
        background: rgba(28, 200, 138, 0.1);
        color: var(--success-color);
    }

    .status-booked {
        background: rgba(231, 74, 59, 0.1);
        color: var(--danger-color);
    }

    .status-clean {
        background: rgba(78, 115, 223, 0.1);
        color: var(--primary-color);
    }

    .room-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 20px;
        padding: 20px;
    }

    .add-room-btn {
        position: fixed;
        bottom: 30px;
        right: 30px;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background: linear-gradient(45deg, var(--primary-color), #224abe);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
    }

    .add-room-btn:hover {
        transform: scale(1.1);
        color: white;
    }

    .room-info {
        padding: 15px;
    }

    .room-type {
        font-size: 0.9rem;
        color: var(--secondary-color);
        margin-bottom: 10px;
    }

    .room-price {
        font-size: 1.2rem;
        font-weight: 600;
        color: var(--primary-color);
    }

    .room-capacity {
        font-size: 0.9rem;
        color: var(--secondary-color);
    }

    .action-buttons {
        display: flex;
        gap: 10px;
        margin-top: 15px;
    }

    /* Enhanced Animations */
    .room-card {
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        animation: fadeIn 0.5s ease-out;
    }

    .room-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.12);
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .modal.fade .modal-dialog {
        transform: scale(0.95);
        transition: transform 0.3s ease-out;
    }

    .modal.show .modal-dialog {
        transform: scale(1);
    }

    .btn {
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .btn:active {
        transform: scale(0.95);
    }

    .add-room-btn {
        animation: float 3s ease-in-out infinite;
    }

    @keyframes float {
        0% {
            transform: translateY(0px);
        }

        50% {
            transform: translateY(-10px);
        }

        100% {
            transform: translateY(0px);
        }
    }

    .room-status {
        animation: slideIn 0.3s ease-out;
    }

    @keyframes slideIn {
        from {
            transform: translateX(20px);
            opacity: 0;
        }

        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    .action-buttons button {
        transition: all 0.2s ease;
    }

    .action-buttons button:hover {
        transform: translateY(-2px);
    }

    .form-control,
    .form-select {
        transition: all 0.2s ease;
    }

    .form-control:focus,
    .form-select:focus {
        transform: translateY(-1px);
    }

    .alert {
        animation: slideDown 0.3s ease-out;
    }

    @keyframes slideDown {
        from {
            transform: translateY(-20px);
            opacity: 0;
        }

        to {
            transform: translateY(0);
            opacity: 1;
        }
    }

    .toggle-sidebar {
        position: fixed;
        top: 20px;
        left: 20px;
        background: var(--primary-color);
        color: white;
        border: none;
        border-radius: 50%;
        width: 50px;
        height: 50px;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .toggle-sidebar:hover {
        transform: scale(1.1);
    }
    </style>
</head>

<body class="bg-light">

    <?php require('../sidebar_cashier_izzy.php') ?>
    <div class="main-content">
        <div class="container-fluid mt-5">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3>View Rooms</h3>
            </div>

            <div class="filter-section bg-white p-4 rounded shadow-sm mb-4">
                <form method="GET" class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Search Room</label>
                        <input type="text" name="search" class="form-control" placeholder="Search by name..."
                            value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Room Type</label>
                        <select name="type" class="form-select">
                            <option value="">All Types</option>
                            <?php 
                            $types = $con->query("SELECT * FROM room_type_izzy");
                            while($type = $types->fetch_assoc()):
                            ?>
                            <option value="<?= $type['id_type_izzy'] ?>"
                                <?= ($type_filter == $type['id_type_izzy']) ? 'selected' : '' ?>>
                                <?= $type['type_izzy'] ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="">All Status</option>
                            <option value="Available" <?= ($status_filter == 'Available') ? 'selected' : '' ?>>Available
                            </option>
                            <option value="Booked" <?= ($status_filter == 'Booked') ? 'selected' : '' ?>>Booked</option>
                            <option value="Clean" <?= ($status_filter == 'Clean') ? 'selected' : '' ?>>Clean</option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-search me-1"></i> Search
                        </button>
                    </div>
                </form>
            </div>

            <div class="room-grid">
                <?php while ($row = $result->fetch_assoc()) : ?>
                <div class="card room-card">
                    <div class="position-relative">
                        <img src="../../images/rooms/1.jpg" class="card-img-top" alt="Room Image"
                            style="height: 200px; object-fit: cover;">
                        <span class="room-status status-<?= strtolower($row['room_status_izzy']) ?>">
                            <?= ucfirst($row['room_status_izzy']) ?>
                        </span>
                    </div>
                    <div class="room-info">
                        <h5 class="card-title mb-1"><?= $row['name_izzy'] ?></h5>
                        <div class="room-type"><?= $row['type_izzy'] ?></div>
                        <div class="room-price">$<?= number_format($row['price_izzy'], 2) ?></div>
                        <div class="room-capacity">
                            <i class="bi bi-people"></i> <?= $row['guest_capacity_izzy'] ?> Guests
                        </div>
  

                        <div class="mt-2">
                            <?php 
                            if ($row['reschedule_requests'] > 0 || $row['approved_reschedules'] > 0): ?>
                                <div class="d-flex align-items-center gap-2">
                                    <a href="../transaction/cashier_transactions_izzy.php?room=<?= $row['name_izzy'] ?>" 
                                       class="btn btn-sm btn-primary">
                                        <i class="bi bi-eye"></i> View Reschedules
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>

    <?php require('../inc/script_izzy.php') ?>
    <script>
    function toggleSidebar() {
        const sidebar = document.querySelector('.sidebar');
        sidebar.classList.toggle('collapsed');
    }
    if (message) {
        const alert = document.createElement('div');
        alert.className = 'alert alert-success alert-dismissible fade show';
        alert.innerHTML = `
                        ${message}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    `;
        document.querySelector('.container-fluid').insertBefore(alert, document.querySelector('.room-grid'));

        // Auto-dismiss alert after 3 seconds
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 3000);
    }
    </script>
</body>

</html>