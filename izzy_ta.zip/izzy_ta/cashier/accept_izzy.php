<?php
require('inc/essentials_izzy.php');
cashierLogin();
require('inc/koneksi_db_izzy.php');

if (isset($_GET['id'])) {
    $transaction_id = $_GET['id'];

    $query = "SELECT id_room_izzy FROM transaction_izzy WHERE id_transaction_izzy = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param("i", $transaction_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $id_room = $row['id_room_izzy'];

        $updateTrans = "UPDATE transaction_izzy SET status_izzy = 'completed' WHERE id_transaction_izzy = ?";
        $stmtTrans = $con->prepare($updateTrans);
        $stmtTrans->bind_param("i", $transaction_id);
        $stmtTrans->execute();
    }
}
if (isset($_GET['id'])) {
    $transaction_id = $_GET['id'];
    
    $query = "UPDATE transaction_izzy SET status_payment_izzy='paid' WHERE id_transaction_izzy= ? ";
    $stmt = $con->prepare($query);
    $stmt->bind_param("i", $transaction_id);
    $stmt->execute();
}
header("Location: transaction/cashier_transactions_izzy.php");
exit;
?>