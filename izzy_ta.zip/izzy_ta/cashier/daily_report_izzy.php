<?php
require('../inc/koneksi_db_izzy.php');
require('inc/essentials_izzy.php');
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if not logged in
if(!isset($_SESSION['cashierLogin']) || $_SESSION['cashierLogin'] !== true) {
    header("Location: ../cashier/index_cashier_izzy.php");
    exit;
}
// Add cashierLogin() for verification
cashierLogin();

// Update date handling to support range
$start_date = $_GET['start_date'] ?? date('Y-m-d');
$end_date = $_GET['end_date'] ?? date('Y-m-d');

// Validate dates
if (strtotime($end_date) < strtotime($start_date)) {
    $end_date = $start_date;
}

// Query to get daily transaction data
$query = "SELECT t.id_transaction_izzy, 
          u.name_izzy AS user_name, r.name_izzy AS room_name,
          t.checkin_izzy, t.checkout_izzy, t.status_izzy, t.total_price_izzy,
          t.create_at, t.proof_izzy, t.status_payment_izzy, t.subtotal_izzy, t.tax_izzy, t.discount_izzy,
          t.service_fees_izzy, t.nights_count_izzy, t.per_night_rate_izzy, t.extra_bed_fee_izzy
          FROM transaction_izzy t
          INNER JOIN user_izzy u ON t.id_izzy = u.id_izzy
          INNER JOIN rooms_izzy r ON t.id_room_izzy = r.id_room_izzy
          WHERE DATE(t.create_at) BETWEEN ? AND ?";

$stmt = $con->prepare($query);
$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$result = $stmt->get_result();

// Calculate daily summary
$total_income = 0;
$paid_transactions = 0;
$pending_transactions = 0;
$canceled_transactions = 0;
$total_tax = 0;
$total_discount = 0;
$total_subtotal = 0;
$total_service_fees = 0;
$total_room_charges = 0;
$total_extra_bed_fees = 0;

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $total_income += $row['total_price_izzy'];
        $total_tax += $row['tax_izzy'];
        $total_discount += $row['discount_izzy'];
        $total_subtotal += $row['subtotal_izzy'];
        $total_extra_bed_fees += $row['extra_bed_fee_izzy'];
        
        // Calculate room charges
        $total_room_charges += ($row['per_night_rate_izzy'] * $row['nights_count_izzy']);
        
        // Parse and sum service fees
        if ($row['service_fees_izzy']) {
            $services = json_decode($row['service_fees_izzy'], true);
            if (is_array($services)) {
                foreach ($services as $service) {
                    $total_service_fees += isset($service['total']) ? $service['total'] : 0;
                }
            }
        }
        
        // Count transaction by status
        if ($row['status_payment_izzy'] == 'paid') {
            $paid_transactions++;
        } elseif ($row['status_payment_izzy'] == 'pending') {
            $pending_transactions++;
        } elseif ($row['status_payment_izzy'] == 'canceled') {
            $canceled_transactions++;
        }
    }
    // Reset result pointer
    $result->data_seek(0);
}

// Get cashier name
$cashier_id = $_SESSION['cashierId'];
$cashier_query = "SELECT username_cashier_izzy FROM cashier_izzy WHERE id_cashier_izzy = ?";
$stmt_cashier = $con->prepare($cashier_query);
$stmt_cashier->bind_param("i", $cashier_id);
$stmt_cashier->execute();
$cashier_result = $stmt_cashier->get_result();
$cashier_name = $cashier_result->fetch_assoc()['username_cashier_izzy'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daily Income Report</title>
    <?php require('../inc/links_izzy.php') ?>
    <style>
    :root {
        --primary-color: #4e73df;
    }
    .main-content {
        margin-left: 250px;
        width: calc(100% - 250px);
        padding: 20px;
    }
    .sidebar {
        background: linear-gradient(180deg, var(--primary-color) 0%, #224abe 100%) !important;
    }

    body {
        display: flex;
        min-height: 100vh;
    }
    .filter-section {
        background: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        margin-bottom: 20px;
    }

    .filter-section .form-control,
    .filter-section .form-select {
        border-radius: 8px;
        border: 1px solid #e3e6f0;
    }

    .summary-card {
        background-color: white;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
    }

    .summary-card h4 {
        color: #4e73df;
        margin-bottom: 15px;
        border-bottom: 1px solid #e3e6f0;
        padding-bottom: 10px;
    }

    .summary-card .row {
        margin-bottom: 10px;
    }

    .summary-item {
        display: flex;
        justify-content: space-between;
        margin-bottom: 8px;
        padding-bottom: 8px;
        border-bottom: 1px dashed #e3e6f0;
    }

    .summary-item:last-child {
        border-bottom: none;
    }

    .summary-total {
        font-weight: bold;
        font-size: 1.1rem;
        border-top: 2px solid #e3e6f0;
        padding-top: 10px;
        margin-top: 10px;
    }

    .status-badge {
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 500;
    }

    .status-paid {
        background: rgba(28, 200, 138, 0.1);
        color: #1cc88a;
    }

    .status-pending {
        background: rgba(246, 194, 62, 0.1);
        color: #f6c23e;
    }

    .status-canceled {
        background: rgba(231, 74, 59, 0.1);
        color: #e74a3b;
    }

    .chart-container {
        position: relative;
        height: 300px;
        margin-bottom: 20px;
    }

    @media print {
        .no-print, .sidebar {
            display: none !important;
        }

        body {
            padding: 0;
            margin: 0;
        }

        .main-content {
            margin-left: 0 !important;
            width: 100% !important;
            padding: 0 !important;
        }

        .container {
            width: 100%;
            max-width: 100%;
        }

        .card {
            border: none !important;
            box-shadow: none !important;
        }

        /* Hide all elements except what we want to print */
        .container > *:not(.letterhead):not(.print-content) {
            display: none !important;
        }

        /* Letterhead styles */
        .letterhead {
            text-align: center;
            padding: 20px 0;
            border-bottom: 2px solid #000;
            margin-bottom: 20px;
        }

        .print-content {
            padding: 20px;
        }

        .print-info {
            margin: 20px 0;
        }

        .signature-area {
            margin-top: 50px;
            page-break-inside: avoid;
        }
    }
    </style>
</head>

<body class="bg-light">

    <?php require('sidebar_cashier_izzy.php') ?>

    <div class="main-content">
        <div class="container mt-5">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3>Daily Income Report</h3>
                <div class="no-print">
                    <button type="button" class="btn btn-primary" onclick="printReport()">
                        <i class="bi bi-printer"></i> Print Report
                    </button>
                </div>
            </div>

            <!-- Date Filter Section -->
            <div class="filter-section no-print">
                <form method="GET" class="row g-3" id="reportForm">
                    <div class="col-md-4">
                        <label class="form-label">Start Date</label>
                        <input type="date" name="start_date" id="start_date" class="form-control" 
                            value="<?= htmlspecialchars($start_date) ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">End Date</label>
                        <input type="date" name="end_date" id="end_date" class="form-control" 
                            value="<?= htmlspecialchars($end_date) ?>" required>
                    </div>
                    <div class="col-md-3 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-search me-1"></i> Generate Report
                        </button>
                    </div>
                </form>
            </div>

            <!-- Summary Cards -->
            <div class="row">
                <!-- Overall Summary -->
                <div class="col-md-6">
                    <div class="summary-card">
                        <h4>Financial Summary for <?= date('F d', strtotime($start_date)) ?> 
                            <?= $start_date !== $end_date ? ' - '.date('F d', strtotime($end_date)) : '' ?>, 
                            <?= date('Y', strtotime($end_date)) ?>
                        </h4>

                        <div class="summary-item">
                            <span>Total Room Charges:</span>
                            <span>$<?= number_format($total_room_charges, 2) ?></span>
                        </div>
                        <div class="summary-item">
                            <span>Total Service Fees:</span>
                            <span>$<?= number_format($total_service_fees, 2) ?></span>
                        </div>
                        <div class="summary-item">
                            <span>Total Extra Bed Fees:</span>
                            <span>$<?= number_format($total_extra_bed_fees, 2) ?></span>
                        </div>
                        <div class="summary-item">
                            <span>Subtotal:</span>
                            <span>$<?= number_format($total_subtotal, 2) ?></span>
                        </div>
                        <div class="summary-item">
                            <span>Total Tax:</span>
                            <span>$<?= number_format($total_tax, 2) ?></span>
                        </div>
                        <div class="summary-item">
                            <span>Total Discounts:</span>
                            <span>$<?= number_format($total_discount, 2) ?></span>
                        </div>
                        <div class="summary-total">
                            <span>Total Income:</span>
                            <span>$<?= number_format($total_income, 2) ?></span>
                        </div>
                    </div>
                </div>

                <!-- Transaction Summary -->
                <div class="col-md-6">
                    <div class="summary-card">
                        <h4>Transaction Summary</h4>

                        <div class="summary-item">
                            <span>Paid Transactions:</span>
                            <span><?= $paid_transactions ?></span>
                        </div>
                        <div class="summary-item">
                            <span>Pending Transactions:</span>
                            <span><?= $pending_transactions ?></span>
                        </div>
                        <div class="summary-item">
                            <span>Canceled Transactions:</span>
                            <span><?= $canceled_transactions ?></span>
                        </div>
                        <div class="summary-total">
                            <span>Total Transactions:</span>
                            <span><?= $paid_transactions + $pending_transactions + $canceled_transactions ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Detailed Transaction Table -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <h4 class="card-title mb-4">Transaction Details</h4>

                    <?php if($result->num_rows == 0): ?>
                    <div class="text-center py-5">
                        <h4 class="text-muted">No Transaction Data Available</h4>
                        <p class="text-muted">There are no transactions recorded for
                            <?= date('F d, Y', strtotime($selected_date)) ?>.</p>
                    </div>
                    <?php else: ?>
                    <div class="table-responsive">
                        <table id="reportTable" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>User</th>
                                    <th>Room</th>
                                    <th>Check-in</th>
                                    <th>Check-out</th>
                                    <th>Nights</th>
                                    <th>Room Rate</th>
                                    <th>Services</th>
                                    <th>Subtotal</th>
                                    <th>Tax</th>
                                    <th>Discount</th>
                                    <th>Total</th>
                                    <th>Payment Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $result->fetch_assoc()) : 
                                    // Calculate services total
                                    $services_total = 0;
                                    $services_list = [];
                                    if ($row['service_fees_izzy']) {
                                        $services = json_decode($row['service_fees_izzy'], true);
                                        if (is_array($services)) {
                                            foreach ($services as $service) {
                                                $services_total += isset($service['total']) ? $service['total'] : 0;
                                                if (isset($service['name']) && isset($service['price'])) {
                                                    $services_list[] = $service['name'] . " ($" . $service['price'] . ")";
                                                }
                                            }
                                        }
                                    }
                                    $services_text = implode(", ", $services_list);
                                ?>
                                <tr>
                                    <td><?= $row['id_transaction_izzy'] ?></td>
                                    <td><?= $row['user_name'] ?></td>
                                    <td><?= $row['room_name'] ?></td>
                                    <td><?= $row['checkin_izzy'] ?></td>
                                    <td><?= $row['checkout_izzy'] ?></td>
                                    <td><?= $row['nights_count_izzy'] ?></td>
                                    <td>$<?= number_format($row['per_night_rate_izzy'], 2) ?></td>
                                    <td title="<?= htmlspecialchars($services_text) ?>">
                                        $<?= number_format($services_total, 2) ?>
                                        <?php if (!empty($services_list)): ?>
                                        <i class="bi bi-info-circle text-muted small"></i>
                                        <?php endif; ?>
                                    </td>
                                    <td>$<?= number_format($row['subtotal_izzy'], 2) ?></td>
                                    <td>$<?= number_format($row['tax_izzy'], 2) ?></td>
                                    <td>$<?= number_format($row['discount_izzy'], 2) ?></td>
                                    <td>$<?= number_format($row['total_price_izzy'], 2) ?></td>
                                    <td>
                                        <?php 
                                        switch($row['status_payment_izzy']) {
                                            case 'paid':
                                                echo '<span class="status-badge status-paid">Paid</span>';
                                                break;
                                            case 'pending':
                                                echo '<span class="status-badge status-pending">Pending</span>';
                                                break;
                                            case 'canceled':
                                                echo '<span class="status-badge status-canceled">Canceled</span>';
                                                break;
                                            default:
                                                echo '<span class="badge bg-secondary">None</span>';
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Letterhead - Only visible when printing -->
            <div class="letterhead d-none d-print-block">
                <h2>IZZY HOTEL</h2>
                <p>Jalan Kamarung No.69, RT.2/RW.5, Citeureup, Cimahi Utara, Citeureup, Kec. Cimahi Utara, Kota Cimahi, Jawa Barat 40512</p>
            </div>

            <!-- Print Content - Only visible when printing -->
            <div class="print-content d-none d-print-block">
                <div class="print-info">
                    <h3>Transaction Report</h3>
                    <p>Period: <?= date('F d, Y', strtotime($start_date)) ?> - <?= date('F d, Y', strtotime($end_date)) ?></p>
                    <p>Printed by: <?= htmlspecialchars($cashier_name) ?> (cashier ID: <?= $_SESSION['cashierId'] ?>)</p>
                    <p>Print Date: <?= date('F d, Y h:i A') ?></p>
                    <p class="fw-bold">Total Income for this Period: $<?= number_format($total_income, 2) ?></p>
                </div>

                <!-- Transaction Table -->
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User</th>
                                <th>Room</th>
                                <th>Check-in</th>
                                <th>Check-out</th>
                                <th>Total</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $result->data_seek(0);
                            while ($row = $result->fetch_assoc()) : ?>
                            <tr>
                                <td><?= $row['id_transaction_izzy'] ?></td>
                                <td><?= $row['user_name'] ?></td>
                                <td><?= $row['room_name'] ?></td>
                                <td><?= date('d/m/Y', strtotime($row['checkin_izzy'])) ?></td>
                                <td><?= date('d/m/Y', strtotime($row['checkout_izzy'])) ?></td>
                                <td>$<?= number_format($row['total_price_izzy'], 2) ?></td>
                                <td><?= ucfirst($row['status_payment_izzy']) ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Signature Section - Only visible when printing -->
            <div class="row mt-5 d-none" id="signature-section">
                <div class="col-md-6 offset-md-6">
                    <div class="mb-5">
                        <p>Generated on: <?= date('F d, Y h:i A') ?></p>
                    </div>
                    <div class="mt-5 pt-5">
                        <div style="border-top: 1px solid #000; width: 250px; margin-bottom: 10px;"></div>
                        <p>cashieristrator Signature</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php require('inc/script_izzy.php') ?>
    <script>
    function printReport() {
        // Show the signature section before printing
        document.getElementById('signature-section').classList.remove('d-none');

        // Print the document
        window.print();

        // Hide the signature section after printing
        setTimeout(function() {
            document.getElementById('signature-section').classList.add('d-none');
        }, 100);
    }

    document.addEventListener('DOMContentLoaded', function() {
        // Add DataTables for better table functionality
        if (document.getElementById('reportTable')) {
            $('#reportTable').DataTable({
                paging: false,
                searching: false,
                info: false
            });
        }
    });
    
    // Add date validation
    document.getElementById('start_date').addEventListener('change', validateDates);
    document.getElementById('end_date').addEventListener('change', validateDates);
    
    function validateDates() {
        const startDate = document.getElementById('start_date').value;
        const endDate = document.getElementById('end_date').value;
        
        if(startDate && endDate && new Date(endDate) < new Date(startDate)) {
            alert('End date cannot be earlier than start date');
            document.getElementById('end_date').value = startDate;
        }
    }
    
    document.getElementById('reportForm').addEventListener('submit', function(e) {
        const startDate = document.getElementById('start_date').value;
        const endDate = document.getElementById('end_date').value;
        
        if(new Date(endDate) < new Date(startDate)) {
            e.preventDefault();
            alert('End date cannot be earlier than start date');
            document.getElementById('end_date').value = startDate;
        }
    });
    </script>
</body>

</html>