<?php
require('../inc/essentials_izzy.php');
require('../..//inc/koneksi_db_izzy.php');
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if not logged in
if(!isset($_SESSION['cashierLogin']) || $_SESSION['cashierLogin'] !== true) {
    header("Location: ../../cashier/index_cashier_izzy.php");
    exit;
}
// Add cashierLogin() for verification
cashierLogin();


// Add search functionality
$search = $_GET['search'] ?? '';
$query = "SELECT * FROM facilities_izzy WHERE 1=1";
if (!empty($search)) {
    $query .= " AND (name_izzy LIKE '%$search%' OR description_izzy LIKE '%$search%')";
}
$result = mysqli_query($con, $query);

// Create facilities directory if it doesn't exist
$upload_dir = "images/facilities";
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// Modify the getImagePath function
function getImagePath($imageName) {
    return !empty($imageName) ? 'images/facilities/' . $imageName : '../../images/facilities/ac(1).svg';
}

// Fetch facilities data
$query = "SELECT id_izzy, name_izzy, description_izzy, image_izzy FROM facilities_izzy";
$result = $con->query($query);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Facilities</title>
    <?php require('../inc/links_izzy.php') ?>
    <style>
    .facility-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 20px;
        padding: 20px;
    }

    .facility-card {
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        animation: fadeIn 0.5s ease-out;
    }

    .facility-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.12);
    }

    .facility-card .card-img-wrapper {
        height: 200px;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: #f8f9fa;
    }

    .facility-card .card-img-top {
        width: 100%;
        height: 100%;
        object-fit: contain;
        padding: 10px;
    }

    .facility-info {
        padding: 15px;
    }

    .facility-description {
        font-size: 0.9rem;
        color: var(--secondary-color);
        margin-bottom: 15px;
        overflow: hidden;
    }

    .add-facility-btn {
        position: fixed;
        bottom: 30px;
        right: 30px;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background: linear-gradient(45deg, var(--primary-color), #224abe);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
        z-index: 1000;
    }

    .add-facility-btn:hover {
        transform: scale(1.1);
        color: white;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    </style>
</head>

<body class="bg-light">

    <?php require('../sidebar_cashier_izzy.php') ?>
    <div class="main-content">
        <div class="container-fluid mt-5">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3>View Facilities</h3>
            </div>

            <div class="filter-section bg-white p-4 rounded shadow-sm mb-4">
                <form method="GET" class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Search Facility</label>
                        <input type="text" name="search" class="form-control"
                            placeholder="Search by name or description..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-search me-1"></i> Search
                        </button>
                    </div>
                </form>
            </div>

            <div class="facility-grid">
                <?php 
                $query = "SELECT * FROM facilities_izzy";
                $result = mysqli_query($con, $query);

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $image_path = getImagePath($row['image_izzy']);
                ?>
                <div class="card facility-card">
                    <div class="card-img-wrapper">
                        <img src="<?= $image_path ?>" class="card-img-top"
                            alt="<?= htmlspecialchars($row['name_izzy']) ?>">
                    </div>
                    <div class="facility-info">
                        <h5 class="card-title mb-2"><?= $row['name_izzy'] ?></h5>
                        <div class="facility-description"><?= $row['description_izzy'] ?></div>

                    </div>
                </div>
                <?php 
                    }
                } else {
                    echo '<div class="col-12 text-center"><p>No facilities found!</p></div>';
                }
                ?>
        </div>
    </div>

    <?php require('../inc/script_izzy.php') ?>

</body>

</html>