<?php

require('../inc/essentials_izzy.php');
require('../../inc/koneksi_db_izzy.php');
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if not logged in
if(!isset($_SESSION['cashierLogin']) || $_SESSION['cashierLogin'] !== true) {
    header("Location: ../../cashier/index_cashier_izzy.php");
    exit;
}
// Add cashierLogin() for verification
cashierLogin();

$search = $_GET['search'] ?? '';
$date_filter = $_GET['date'] ?? '';

$selected_columns = $_GET['columns'] ?? ['id', 'name', 'email', 'phone', 'password', 'pincode', 'address', 'created'];

function is_checked($value, $array) {
    return in_array($value, $array) ? 'checked' : '';
}

$query = "SELECT * FROM user_izzy WHERE 1=1";

if (!empty($search)) {
    $query .= " AND (name_izzy LIKE '%$search%' OR email_izzy LIKE '%$search%' OR phone_izzy LIKE '%$search%')";
}
if (!empty($date_filter)) {
    $query .= " AND DATE(created_at) = '$date_filter'";
}

$result = $con->query($query);

// Handle form submission for updating user
if (isset($_POST['update_user'])) {
    $id = $_POST['id_izzy'];
    $name = $_POST['name_izzy'];
    $email = $_POST['email_izzy'];
    $password = $_POST['password_izzy'];
    $pincode = $_POST['pincode_izzy'];
    $address = $_POST['address_izzy'];

    $query = "UPDATE user_izzy SET
                name_izzy = ?,
                email_izzy = ?,
                password_izzy = ?,
                pincode_izzy = ?,
                address_izzy = ?
              WHERE id_izzy = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param('sssssi', $name, $email, $password, $pincode, $address, $id);

    if ($stmt->execute()) {
        header('Location: cashier_users_izzy.php?success=1');
        exit;
    } else {
        echo '<div class="alert alert-danger">Failed to update user.</div>';
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Users</title>
    <?php require('../inc/links_izzy.php') ?>
</head>

<body class="bg-light">

    <?php require('../sidebar_cashier_izzy.php') ?><div class="main-content">
        <div class="container mt-5">
            <h3 class="mb-4">View Users</h3>

            <div class="filter-section bg-white p-4 rounded shadow-sm mb-4">
                <form method="GET" class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Search User</label>
                        <input type="text" name="search" class="form-control"
                            placeholder="Search by name, email or phone..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Registration Date</label>
                        <input type="date" name="date" class="form-control"
                            value="<?= htmlspecialchars($date_filter) ?>">
                    </div>
                    <div class="col-md-4 d-flex align-items-end gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-search me-1"></i> Search
                        </button>
                        <button type="button" class="btn btn-info text-white" data-bs-toggle="modal"
                            data-bs-target="#columnsModal">
                            <i class="bi bi-funnel me-1"></i> Filter Columns
                        </button>
                    </div>
                </form>
            </div>

            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <table class="table table-bordered" id="userTable">
                        <thead>
                            <tr>
                                <?php if (in_array('id', $selected_columns)) echo '<th>ID</th>'; ?>
                                <?php if (in_array('name', $selected_columns)) echo '<th>Name</th>'; ?>
                                <?php if (in_array('email', $selected_columns)) echo '<th>Email</th>'; ?>
                                <?php if (in_array('phone', $selected_columns)) echo '<th>Phone</th>'; ?>
                                <?php if (in_array('password', $selected_columns)) echo '<th>Password</th>'; ?>
                                <?php if (in_array('pincode', $selected_columns)) echo '<th>Pincode</th>'; ?>
                                <?php if (in_array('address', $selected_columns)) echo '<th>Address</th>'; ?>
                                <?php if (in_array('created', $selected_columns)) echo '<th>Created At</th>'; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $result->fetch_assoc()) : ?>
                            <tr>
                                <?php if (in_array('id', $selected_columns)) echo '<td>' . $row['id_izzy'] . '</td>'; ?>
                                <?php if (in_array('name', $selected_columns)) echo '<td>' . $row['name_izzy'] . '</td>'; ?>
                                <?php if (in_array('email', $selected_columns)) echo '<td>' . $row['email_izzy'] . '</td>'; ?>
                                <?php if (in_array('phone', $selected_columns)) echo '<td>' . $row['phone_izzy'] . '</td>'; ?>
                                <?php if (in_array('password', $selected_columns)) echo '<td>' . $row['password_izzy'] . '</td>'; ?>
                                <?php if (in_array('pincode', $selected_columns)) echo '<td>' . $row['pincode_izzy'] . '</td>'; ?>
                                <?php if (in_array('address', $selected_columns)) echo '<td>' . $row['address_izzy'] . '</td>'; ?>
                                <?php if (in_array('created', $selected_columns)) echo '<td>' . $row['created_at'] . '</td>'; ?>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>

                    <!-- Add Print Button -->
                    <div class="mt-3">
                        <button type="button" class="btn btn-primary" onclick="printTable()">Print PDF</button>
                    </div>
                </div>
            </div>

            <!-- Add Columns Filter Modal -->
            <div class="modal fade" id="columnsModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-scrollable">
                    <div class="modal-content">
                        <form method="GET">
                            <div class="modal-header">
                                <h5 class="modal-title">Choose Columns</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="search" value="<?= htmlspecialchars($search) ?>">
                                <input type="hidden" name="date" value="<?= htmlspecialchars($date_filter) ?>">

                                <?php
                                $columns = [
                                    'id' => 'ID',
                                    'name' => 'Name',
                                    'email' => 'Email',
                                    'phone' => 'Phone',
                                    'password' => 'Password',
                                    'pincode' => 'Pincode',
                                    'address' => 'Address',
                                    'created' => 'Created At'
                                ];
                                foreach ($columns as $key => $label) {
                                    echo "<div class='form-check'>
                                            <input class='form-check-input' type='checkbox' name='columns[]' 
                                                   value='$key' ". is_checked($key, $selected_columns) .">
                                            <label class='form-check-label'>$label</label>
                                          </div>";
                                }
                                ?>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Apply</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php require('../inc/script_izzy.php') ?>
    <script>
    function printTable() {
        // Hide action column
        const actionColumns = document.querySelectorAll('.action-column');
        actionColumns.forEach(column => column.style.display = 'none');

        // Get table HTML
        const table = document.querySelector('#userTable').outerHTML;

        // Create print window
        const printWindow = window.open('', '', 'width=800,height=600');
        printWindow.document.write(`
                <html>
                <head>
                    <title>Print Users</title>
                    <style>
                        table { width: 100%; border-collapse: collapse; }
                        table, th, td { border: 1px solid black; }
                        th, td { padding: 8px; text-align: left; }
                    </style>
                </head>
                <body>
                    <h3>Users</h3>
                    ${table}
                </body>
                </html>
            `);

        printWindow.document.close();
        printWindow.print();
        printWindow.close();

        // Show action column again
        actionColumns.forEach(column => column.style.display = '');
    }
    </script>
</body>

</html>