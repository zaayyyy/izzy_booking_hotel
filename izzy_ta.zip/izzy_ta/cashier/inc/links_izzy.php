<?php
$base_url = $_SERVER['DOCUMENT_ROOT'] . '/izzy_try/admin/';
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css" rel="stylesheet">

<style>
:root {
    --primary-color: #4e73df;
    --secondary-color: #858796;
    --success-color: #1cc88a;
    --info-color: #36b9cc;
    --warning-color: #f6c23e;
    --danger-color: #e74a3b;
}

/* Global Styles */
.sidebar {
    height: 100vh;
    width: 250px;
    position: fixed;
    top: 0;
    left: 0;
    background: linear-gradient(180deg, var(--primary-color) 0%, #224abe 100%);
    padding-top: 20px;
    transition: all 0.3s ease;
    z-index: 1000;
}

.main-content {
    margin-left: 250px;
    padding: 20px;
    transition: all 0.3s ease;
}

.main-content.expanded {
    margin-left: 70px;
}

/* Sidebar States */
.sidebar.collapsed {
    width: 70px;
}

.sidebar.collapsed .nav-text,
.sidebar.collapsed .small {
    display: none;
}

/* Card Styles */
.card {
    border: none;
    border-radius: 10px;
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
    transition: all 0.3s ease;
}

.card:hover {
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.25);
}

.card-header {
    background: linear-gradient(45deg, var(--primary-color), #224abe);
    color: white;
    border: none;
    padding: 1rem 1.5rem;
}

/* Form Styles */
.form-control, .form-select {
    border-radius: 8px;
    border: 1px solid #e3e6f0;
    padding: 0.75rem 1rem;
    transition: all 0.2s ease;
}

.form-control:focus, .form-select:focus {
    border-color: var(--primary-color);
    box-shadow: 0 0 0 0.25rem rgba(78, 115, 223, 0.25);
}

/* Button Styles */
.btn {
    border-radius: 8px;
    padding: 0.5rem 1rem;
    font-weight: 500;
    transition: all 0.2s ease;
}

.btn-primary {
    background: linear-gradient(45deg, var(--primary-color), #224abe);
    border: none;
}

.btn-primary:hover {
    background: linear-gradient(45deg, #224abe, var(--primary-color));
    transform: translateY(-1px);
}

/* Table Styles */
.table {
    background: white;
    border-radius: 8px;
    overflow: hidden;
}

.table thead {
    background: linear-gradient(45deg, var(--primary-color), #224abe);
    color: white;
}

.table th {
    font-weight: 500;
    border: none !important;
}

.table td {
    vertical-align: middle;
}

/* Toggle Button Styles */
.toggle-sidebar {
    position: fixed;
    left: 250px;
    top: 20px;
    background: var(--primary-color);
    color: white;
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    z-index: 1001;
    box-shadow: 0 2px 6px rgba(0,0,0,0.15);
}

.toggle-sidebar:hover {
    transform: scale(1.1);
    background: linear-gradient(45deg, var(--primary-color), #224abe);
}

.toggle-sidebar.collapsed {
    left: 70px;
}

@media (max-width: 768px) {
    .sidebar {
        width: 70px;
    }
    .main-content {
        margin-left: 70px;
    }
    .nav-text,
    .small {
        display: none;
    }
    .toggle-sidebar {
        left: 70px;
    }
}
</style>