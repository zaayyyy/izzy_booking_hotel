<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/swiper07/swiper-bundle.min.css">
    <?php require('inc/links_izzy.php'); ?>
    <style>
    .pop:hover {
        border-top-color: var(--teal) !important;
        transform: scale(1.03);
        transition: all 0.3s;
    }

    .facility-card {
        height: 100%;
        display: flex;
        flex-direction: column;
    }

    .facility-img {
        width: 40px;
        height: 40px;
        object-fit: contain;
    }

    .facility-content {
        flex-grow: 1;
        display: flex;
        flex-direction: column;
    }

    .facility-title {
        margin-bottom: 10px;
    }

    .facility-desc {
        flex-grow: 1;
        overflow: hidden;
        display: -webkit-box;
        -webkit-line-clamp: 5;
        -webkit-box-orient: vertical;
    }
    </style>
</head>

<body class="bg-light">

    <?php require('inc/header_izzy.php'); ?>

    <div class="my-5 px-4">
        <h2 class="fw-bold h-font text-center"> OUR FACILITIES</h2>
        <div class="h-line bg-dark"></div>
        <p class="text-center mt-3">
            Discover the exceptional amenities we offer to enhance your stay and provide comfort and convenience.
        </p>
    </div>

    <div class="container">
        <div class="row g-4">
            <?php

            $query = "SELECT * FROM facilities_izzy";
            $result = mysqli_query($con, $query);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $image_path = !empty($row['image_izzy']) ? $row['image_izzy'] : 'images/facilities/wifi.svg';
            ?>
            <div class="col-lg-4 col-md-6">
                <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop facility-card">
                    <div class="d-flex align-items-center mb-3">
                        <img src="<?php echo 'images/facilities/' . $row['image_izzy']; ?>"
                            alt="<?php echo $row['name_izzy']; ?>" class="facility-img">
                        <h5 class="m-0 ms-3 facility-title"><?php echo $row['name_izzy']; ?></h5>
                    </div>
                    <div class="facility-content">
                        <p class="facility-desc">
                            <?php echo $row['description_izzy']; ?>
                        </p>
                    </div>
                </div>
            </div>
            <?php
                }
            } else {
                echo '<div class="col-12 text-center"><p>No facilities found!</p></div>';
            }
            ?>
        </div>
    </div>

    <?php require('inc/footer_izzy.php'); ?>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const logoutLink = document.getElementById("logout-link");

        if (logoutLink) {
            logoutLink.addEventListener("click", function(event) {
                event.preventDefault(); // Mencegah navigasi langsung
                const userConfirmed = confirm("Are you sure you want to logout?");
                if (userConfirmed) {
                    window.location.href = logoutLink.href; // Navigasi ke halaman logout
                }
            });
        }
    });
    </script>
</body>

</html>